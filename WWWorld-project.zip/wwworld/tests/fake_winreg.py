"""In-memory stand-in for the parts of `winreg` that shell_integration uses."""
HKEY_CURRENT_USER = "HKCU"
KEY_READ, KEY_WRITE, REG_SZ = 1, 2, 1


class _Key:
    def __init__(self, reg, path):
        self.reg, self.path = reg, path

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class FakeWinreg:
    HKEY_CURRENT_USER, KEY_READ, KEY_WRITE, REG_SZ = HKEY_CURRENT_USER, KEY_READ, KEY_WRITE, REG_SZ

    def __init__(self):
        self.keys: dict[str, dict[str, str]] = {}      # lowercased path -> values
        self.names: dict[str, str] = {}

    def _p(self, p):
        return p.lower().rstrip("\\")

    def _ensure(self, path):
        parts = path.split("\\")
        for i in range(1, len(parts) + 1):
            sub = "\\".join(parts[:i])
            self.keys.setdefault(self._p(sub), {})
            self.names.setdefault(self._p(sub), sub)

    def CreateKeyEx(self, root, path, res, acc):
        self._ensure(path)
        return _Key(self, self._p(path))

    def OpenKey(self, root, path, res=0, acc=0):
        if self._p(path) not in self.keys:
            raise FileNotFoundError(path)
        return _Key(self, self._p(path))

    def SetValueEx(self, key, name, res, typ, value):
        self.keys[key.path][name] = value

    def QueryValueEx(self, key, name):
        if name not in self.keys[key.path]:
            raise FileNotFoundError(name)
        return self.keys[key.path][name], REG_SZ

    def _children(self, path):
        pre = path + "\\"
        return sorted({k[len(pre):].split("\\")[0] for k in self.keys if k.startswith(pre)})

    def EnumKey(self, key, i):
        c = self._children(key.path)
        if i >= len(c):
            raise OSError("no more")
        return c[i]

    def EnumValue(self, key, i):
        v = list(self.keys[key.path].items())
        if i >= len(v):
            raise OSError("no more")
        return v[i][0], v[i][1], REG_SZ

    def DeleteKey(self, root, path):
        p = self._p(path)
        if p not in self.keys:
            raise FileNotFoundError(path)
        if self._children(p):
            raise OSError("key has subkeys")
        del self.keys[p]

    def DeleteValue(self, key, name):
        if name not in self.keys[key.path]:
            raise FileNotFoundError(name)
        del self.keys[key.path][name]

    def get(self, path, name=""):
        return self.keys.get(self._p(path), {}).get(name)
