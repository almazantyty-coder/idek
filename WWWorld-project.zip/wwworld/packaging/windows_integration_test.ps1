# Silent install -> verify EXE + registry -> repair -> silent uninstall -> verify cleanup.
# Run on a Windows machine (also used by CI).  Exits non-zero on the first failed check.
param([string]$Setup = (Get-ChildItem dist\WW-World-Setup-*.exe | Select-Object -First 1).FullName)
$ErrorActionPreference = "Stop"
function Check($ok, $msg) { if ($ok) { Write-Host "PASS  $msg" } else { Write-Host "FAIL  $msg"; $script:failed = $true } }
$script:failed = $false
$dir = Join-Path $env:TEMP "WW World Test Install"        # path WITH spaces on purpose
Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue

$p = Start-Process $Setup -ArgumentList "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /CURRENTUSER /DIR=`"$dir`" /TASKS=contextmenu,assoc" -Wait -PassThru
Check ($p.ExitCode -eq 0) "installer exit code 0"
$exe = Join-Path $dir "WW World.exe"
Check (Test-Path $exe) "WW World.exe installed"
Check (Test-Path (Join-Path $dir "icons\ww_world_archive.ico")) "archive icon installed"

$r = Join-Path $env:TEMP "inst-selftest.json"; Remove-Item $r -ErrorAction SilentlyContinue
$p = Start-Process $exe -ArgumentList "--selftest --report `"$r`"" -Wait -PassThru
Check ($p.ExitCode -eq 0) "installed exe self-test (no Python on PATH required)"

$cmd = (Get-ItemProperty "HKCU:\Software\Classes\*\shell\WWWorldFileManager\command")."(default)"
Check ($cmd -eq "`"$exe`" --open -- `"%1`"") "file context-menu command points at installed exe: $cmd"
Check (Test-Path "HKCU:\Software\Classes\Directory\shell\WWWorldFileManager\command") "folder context menu"
Check (Test-Path "HKCU:\Software\Classes\Directory\Background\shell\WWWorldFileManager\command") "folder background context menu"
Check ((Get-ItemProperty "HKCU:\Software\Classes\.world")."(default)" -eq "WWWorld.Archive") ".world association"
Check ((Get-ItemProperty "HKCU:\Software\Classes\WWWorld.Archive\DefaultIcon")."(default)" -like "*ww_world_archive.ico") ".world DefaultIcon"

# archive round trip through the installed exe
$work = Join-Path $env:TEMP "wwtest data"; New-Item $work -ItemType Directory -Force | Out-Null
"hello" | Set-Content (Join-Path $work "a b (1).txt")
Write-Host "NOTE: right-click -> Show more options -> WW World File Manager must be verified by hand (see docs/MANUAL_TESTS.md)"

# repair after simulated corruption
Remove-Item "HKCU:\Software\Classes\Directory\shell\WWWorldFileManager" -Recurse -Force
Start-Process $exe -ArgumentList "--repair-shell" -Wait
Check (Test-Path "HKCU:\Software\Classes\Directory\shell\WWWorldFileManager\command") "repair re-created the removed entry"

$unins = Get-ChildItem $dir -Filter "unins*.exe" | Select-Object -First 1
$p = Start-Process $unins.FullName -ArgumentList "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART" -Wait -PassThru
Start-Sleep 2
Check (-not (Test-Path "HKCU:\Software\Classes\*\shell\WWWorldFileManager")) "uninstall removed file context menu"
Check (-not (Test-Path "HKCU:\Software\Classes\Directory\shell\WWWorldFileManager")) "uninstall removed folder context menu"
Check (-not (Test-Path "HKCU:\Software\Classes\Directory\Background\shell\WWWorldFileManager")) "uninstall removed background menu"
Check (-not (Test-Path "HKCU:\Software\Classes\WWWorld.Archive")) "uninstall removed ProgID"
Check (-not (Test-Path "HKCU:\Software\Classes\.world")) "uninstall removed .world key"
Check (-not (Test-Path $exe)) "program files removed"
Check (Test-Path (Join-Path $work "a b (1).txt")) "user files untouched"
if ($script:failed) { exit 1 }
