"""Persistent user settings (JSON under %APPDATA%\\WW World)."""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass

from . import paths
from .archive import DEFAULT_PROFILE, PROFILES


@dataclass
class Settings:
    output_dir: str = ""                # "" -> Desktop/WWWorld/WW World Outputs
    profile: str = DEFAULT_PROFILE
    verify_after_create: bool = True

    def outputs(self) -> str:
        return self.output_dir or paths.default_outputs_dir()


def settings_file() -> str:
    return os.path.join(paths.config_dir(), "settings.json")


def load() -> Settings:
    s = Settings()
    try:
        with open(settings_file(), "r", encoding="utf-8") as f:
            raw = json.load(f)
        if isinstance(raw.get("output_dir"), str):
            s.output_dir = raw["output_dir"]
        if raw.get("profile") in PROFILES:
            s.profile = raw["profile"]
        if isinstance(raw.get("verify_after_create"), bool):
            s.verify_after_create = raw["verify_after_create"]
    except (OSError, ValueError, AttributeError):
        pass                              # missing/corrupt file -> defaults
    return s


def save(s: Settings) -> None:
    os.makedirs(paths.config_dir(), exist_ok=True)
    tmp = settings_file() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(asdict(s), f, indent=2)
    os.replace(tmp, settings_file())
