import json
import os
import subprocess
import sys
import time

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAIN = os.path.join(ROOT, "main.py")


def run(args, env_extra=None, timeout=60):
    env = dict(os.environ, QT_QPA_PLATFORM="offscreen", **(env_extra or {}))
    return subprocess.run([sys.executable, MAIN, *args], capture_output=True, text=True, env=env, timeout=timeout)


@pytest.fixture
def home(tmp_path):
    h = tmp_path / "home"
    (h / "Desktop").mkdir(parents=True)
    return {"HOME": str(h), "XDG_CONFIG_HOME": str(tmp_path / "cfg"), "XDG_STATE_HOME": str(tmp_path / "st")}


def test_version_and_selftest(home, tmp_path):
    r = run(["--version"], home)
    assert r.returncode == 0 and "WW World 3." in r.stdout
    rep = tmp_path / "self.json"
    r = run(["--selftest", "--report", str(rep)], home)
    data = json.loads(rep.read_text())
    assert r.returncode == 0 and data["result"] == "PASS" and data["qt gui"] == "main window constructed"


def test_cli_test_and_extract_exit_codes(home, tmp_path):
    from ww_world import archive as A
    f = tmp_path / "f.txt"
    f.write_text("cli")
    arc = str(tmp_path / "f.world")
    A.compress(str(f), arc, "Fast")
    assert run(["--test-archive", arc], home).returncode == 0
    bad = tmp_path / "bad.world"
    data = bytearray(open(arc, "rb").read())
    data[-5] ^= 0xFF
    bad.write_bytes(bytes(data))
    assert run(["--test-archive", str(bad)], home).returncode == 1
    dest = str(tmp_path / "o")
    assert run(["--extract", arc, "--dest", dest], home).returncode == 0
    assert (tmp_path / "o" / "f.txt").read_text() == "cli"
    assert run(["--extract", arc, "--dest", dest], home).returncode == 4      # conflict -> refuses


def test_shell_commands_refuse_gracefully_from_source(home):
    r = run(["--register-shell"], home)
    assert r.returncode == 2 and "installed WW World.exe" in r.stdout


@pytest.mark.skipif(sys.platform == "win32", reason="posix sockets path")
def test_second_launch_hands_over_to_running_instance(home, tmp_path):
    env = dict(os.environ, QT_QPA_PLATFORM="offscreen", **home)
    first = subprocess.Popen([sys.executable, MAIN], env=env, stderr=subprocess.DEVNULL)
    try:
        time.sleep(2.5)
        assert first.poll() is None
        target = tmp_path / "t.txt"
        target.write_text("x")
        t0 = time.time()
        r = subprocess.run([sys.executable, MAIN, "--open", "--", str(target)], env=env, timeout=20,
                           capture_output=True, text=True)
        assert r.returncode == 0 and time.time() - t0 < 10          # forwarded, did not start a 2nd GUI
        assert first.poll() is None                                  # first window still running
    finally:
        first.terminate()
        first.wait(10)
