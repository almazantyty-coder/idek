# Build WW World on Windows (PowerShell 5+/7).  Usage:  powershell -ExecutionPolicy Bypass -File packaging\build.ps1
$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)

python -m venv .venv
. .\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements-build.txt

python -m ww_world.icon assets                      # regenerates ww_world.ico / ww_world_archive.ico
$env:QT_QPA_PLATFORM = "offscreen"
python -m pytest tests -q                           # must pass before packaging
if ($LASTEXITCODE -ne 0) { throw "tests failed" }

pyinstaller packaging\ww_world.spec --noconfirm --clean
$exe = "dist\WW World\WW World.exe"
if (-not (Test-Path $exe)) { throw "EXE was not produced" }

# prove the FROZEN exe starts, finds its resources and round-trips an archive
$rep = Join-Path $env:TEMP "wwworld-frozen-selftest.json"
Remove-Item $rep -ErrorAction SilentlyContinue
$p = Start-Process -FilePath $exe -ArgumentList @("--selftest", "--report", "`"$rep`"") -Wait -PassThru
Get-Content $rep
if ($p.ExitCode -ne 0) { throw "frozen self-test failed" }

$iscc = (Get-Command ISCC.exe -ErrorAction SilentlyContinue).Source
if (-not $iscc) { $iscc = "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe" }
if (Test-Path $iscc) { & $iscc packaging\WWWorld.iss /DAppVersion=3.0.0 } else { Write-Warning "Inno Setup not found; installer not built" }
