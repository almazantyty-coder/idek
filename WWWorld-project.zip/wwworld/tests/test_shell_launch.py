import pytest

from fake_winreg import FakeWinreg
from ww_world import launch, shell_integration as SH

EXE = r"C:\Program Files\WW World\WW World.exe"
ICON = r"C:\Program Files\WW World\icons\ww_world_archive.ico"
C = r"Software\Classes"


def test_context_menu_registration_and_commands():
    w = FakeWinreg()
    SH.register_context_menu(EXE, w)
    assert w.get(rf"{C}\*\shell\WWWorldFileManager") == "WW World File Manager"
    assert w.get(rf"{C}\*\shell\WWWorldFileManager\command") == f'"{EXE}" --open -- "%1"'
    assert w.get(rf"{C}\Directory\shell\WWWorldFileManager\command") == f'"{EXE}" --open -- "%1"'
    assert w.get(rf"{C}\Directory\Background\shell\WWWorldFileManager\command") == f'"{EXE}" --open -- "%V"'
    assert w.get(rf"{C}\*\shell\WWWorldFileManager", "Icon") == f'"{EXE}",0'
    assert w.get(rf"{C}\*\shell\WWWorldFileManager", "MultiSelectModel") == "Document"
    assert not w.get(rf"{C}\.world")                      # association NOT touched by context-menu only


def test_association_and_icon():
    w = FakeWinreg()
    SH.register_association(EXE, ICON, w)
    assert w.get(rf"{C}\.world") == "WWWorld.Archive"
    assert w.get(rf"{C}\WWWorld.Archive\DefaultIcon") == ICON
    assert w.get(rf"{C}\WWWorld.Archive\shell\open\command") == f'"{EXE}" --open -- "%1"'
    assert w.get(rf"{C}\WWWorld.Archive") == "WW World Archive"


def test_unregister_removes_only_our_keys():
    w = FakeWinreg()
    # unrelated entries that must survive
    w.CreateKeyEx(None, rf"{C}\*\shell\OtherApp\command", 0, 0)
    w.SetValueEx(w.OpenKey(None, rf"{C}\*\shell\OtherApp\command"), "", 0, 1, "other.exe")
    w.CreateKeyEx(None, rf"{C}\.txt", 0, 0)
    w.SetValueEx(w.OpenKey(None, rf"{C}\.txt"), "", 0, 1, "txtfile")
    SH.register_context_menu(EXE, w)
    SH.register_association(EXE, ICON, w)
    SH.unregister_all(w)
    assert not [k for k in w.keys if "wwworld" in k or "ww world" in k]
    assert w.get(rf"{C}\*\shell\OtherApp\command") == "other.exe"
    assert w.get(rf"{C}\.txt") == "txtfile"
    assert rf"{C}\.world".lower() not in w.keys


def test_association_restores_previous_handler():
    w = FakeWinreg()
    w.CreateKeyEx(None, rf"{C}\.world", 0, 0)
    w.SetValueEx(w.OpenKey(None, rf"{C}\.world"), "", 0, 1, "SomeOther.World")
    SH.register_association(EXE, ICON, w)
    assert w.get(rf"{C}\.world") == "WWWorld.Archive"
    SH.unregister_association(w)
    assert w.get(rf"{C}\.world") == "SomeOther.World"


def test_status_and_repair_after_move():
    w = FakeWinreg()
    SH.register_context_menu(EXE, w)
    SH.register_association(EXE, ICON, w)
    new = r"D:\Apps\WW World\WW World.exe"
    st = SH.status(new, w)
    assert st["context_registered"] and len(st["stale"]) == 3 and not st["association_ok"]
    did = SH.repair(new, ICON, w)
    assert did == {"context": True, "association": True}
    st = SH.status(new, w)
    assert not st["stale"] and st["association_ok"]


def test_repair_with_nothing_registered_does_nothing():
    w = FakeWinreg()
    assert SH.repair(EXE, ICON, w) == {"context": False, "association": False}
    assert not w.keys


def test_non_windows_raises_clearly():
    import sys
    if sys.platform != "win32":
        with pytest.raises(SH.ShellError):
            SH.register_context_menu("/x")


# ---------------- launch routing
def test_shell_command_line_parses_paths_with_odd_characters():
    odd = r"C:\Users\Zoë\My Docs\a (1) & b [x] 日本.txt"
    req = launch.parse_args(["--open", "--", odd])
    assert req.action == "open" and req.paths == [odd]


def test_plain_path_is_open_not_compress():
    assert launch.parse_args([r"C:\x\file.txt"]).action == "open"
    assert launch.parse_args([]).action == "gui"


def test_drive_root_quoting_artifact_fixed():
    assert launch.parse_args(["--open", "--", 'C:"']).paths == ["C:\\"]
    assert launch.fix_mangled_arg("D:\\") == "D:\\"
    assert launch.fix_mangled_arg(r"C:\folder") == r"C:\folder"


def test_dash_prefixed_name_is_not_an_option():
    assert launch.parse_args(["--open", "--", "-evil.txt"]).paths == ["-evil.txt"]


def test_commands():
    assert launch.parse_args(["--register-shell"]).action == "register"
    r = launch.parse_args(["--register-shell", "--no-assoc"])
    assert r.context and not r.assoc
    assert launch.parse_args(["--unregister-shell"]).action == "unregister"
    assert launch.parse_args(["--repair-shell"]).action == "repair"
    assert launch.parse_args(["--selftest", "--report", "r.json"]).report == "r.json"


def test_classify(tmp_path):
    (tmp_path / "a.world").write_bytes(b"x")
    (tmp_path / "t.txt").write_text("x")
    assert launch.classify(str(tmp_path)) == "folder"
    assert launch.classify(str(tmp_path / "a.world")) == "archive"
    assert launch.classify(str(tmp_path / "t.txt")) == "file"
    assert launch.classify(str(tmp_path / "nope")) == "missing"
