# WW World

Free Windows archiver with its own `.world` format, a file-manager GUI and Explorer integration.

## Layout
```
main.py                     entry point / CLI / launch routing / single instance
ww_world/archive.py         format v2 reader, v3 reader+writer, compress / test / extract
ww_world/safety.py          path validation + containment
ww_world/shell_integration.py   HKCU context menu + .world association (injectable winreg)
ww_world/launch.py, instance.py command line, single-instance IPC
ww_world/gui/               Hub, File Manager, Outputs, Settings, main window
ww_world/icon.py            generates assets/*.ico (7 sizes each)
packaging/                  PyInstaller spec, Inno Setup script, build + integration scripts
docs/ARCHIVE_FORMAT.md      format spec      tests/   98 tests      legacy/  original script
```

## Build (Windows, Python 3.12)
```
powershell -ExecutionPolicy Bypass -File packaging\build.ps1
powershell -ExecutionPolicy Bypass -File packaging\windows_integration_test.ps1
```
Produces `dist\WW World\WW World.exe` and `dist\WW-World-Setup-3.0.0.exe` (needs Inno Setup 6).
No Windows PC? Push to GitHub: `.github/workflows/build-windows.yml` does all of it on a Windows runner.

Run from source: `pip install -r requirements.txt && python main.py`
Tests: `pip install -r requirements-build.txt && QT_QPA_PLATFORM=offscreen python -m pytest tests`

## Command line
`WW World.exe [--open --] PATH…` (open, never compress) · `--hub` · `--register-shell [--no-context|--no-assoc]` ·
`--unregister-shell` · `--repair-shell` · `--shell-status` · `--test-archive A` · `--extract A [--dest D]` ·
`--selftest [--report F]` · `--version`

## Known limitations
* Windows 11 **classic** menu verb only ("Show more options"); no modern-menu COM extension.
* No random access inside archives (solid LZMA); no encryption; no multi-volume; no .zip/.rar/.7z support.
* Legacy 2.x archives browse without sizes/dates and had no empty folders.
* Ratios depend on the data; already-compressed media will not shrink.
* The EXE is unsigned (SmartScreen will warn).
