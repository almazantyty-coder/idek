"""WW World - free Windows archiver with its own .world format."""
__version__ = "3.0.0"
APP_NAME = "WW World"
