import hashlib
import io
import json
import lzma
import os
import struct
import threading
import zipfile

import pytest

from ww_world import archive as A


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def tree(root):
    out = {}
    for cur, dirs, files in os.walk(root):
        for d in dirs:
            out[os.path.relpath(os.path.join(cur, d), root).replace(os.sep, "/") + "/"] = None
        for f in files:
            p = os.path.join(cur, f)
            out[os.path.relpath(p, root).replace(os.sep, "/")] = sha(p)
    return out


@pytest.fixture
def src(tmp_path):
    s = tmp_path / "src"
    (s / "a" / "b").mkdir(parents=True)
    (s / "emptydir").mkdir()
    (s / "a" / "b" / "one.txt").write_text("same content")
    (s / "two.txt").write_text("same content")
    (s / "a" / "three.txt").write_text("same content")
    (s / "empty.bin").write_bytes(b"")
    (s / "empty2.bin").write_bytes(b"")
    (s / "ünï cödé (1) & x.txt").write_text("unicode")
    (s / "with space" ).mkdir()
    (s / "with space" / "f g.txt").write_bytes(os.urandom(300_000))
    return s


def mk(src, tmp_path, profile="Fast"):
    out = str(tmp_path / "t.world")
    A.compress(str(src), out, profile)
    return out


def test_1_single_file_roundtrip(tmp_path):
    f = tmp_path / "doc.txt"
    f.write_bytes(os.urandom(1000) + b"hello" * 1000)
    arc = str(tmp_path / "doc.world")
    r = A.compress(str(f), arc, "Balanced")
    assert r.files == 1
    dest = tmp_path / "out"
    res = A.extract(arc, str(dest))
    assert res.verified and sha(dest / "doc.txt") == sha(f)


@pytest.mark.parametrize("profile", list(A.PROFILES))
def test_all_profiles_roundtrip(tmp_path, profile):
    f = tmp_path / "x.bin"
    f.write_bytes(b"abc" * 50000)
    arc = str(tmp_path / "x.world")
    A.compress(str(f), arc, profile)
    assert A.test_archive(arc).status == "ok"


def test_2_3_4_folder_nested_dedup_hashes_and_empty_dirs(src, tmp_path):
    arc = mk(src, tmp_path)
    info = A.read_archive(arc)
    m = info.manifest
    assert m.major == 3
    dups = [e for e in m.files if e.dup_of]
    assert len(dups) == 3                      # two same-content copies + one empty duplicate
    out = tmp_path / "out"
    A.extract(arc, str(out))
    assert tree(src) == tree(out)              # contents, hashes, nested + empty dirs identical


def test_5_test_archive_does_not_extract(src, tmp_path, monkeypatch):
    arc = mk(src, tmp_path)
    before = set(os.listdir(tmp_path))
    r = A.test_archive(arc)
    assert r.status == "ok" and r.files_checked == r.files_total == len(A.read_archive(arc).manifest.files)
    assert set(os.listdir(tmp_path)) == before


def test_6_corrupted_payload_detected(src, tmp_path):
    arc = mk(src, tmp_path)
    data = bytearray(open(arc, "rb").read())
    data[len(data) // 2] ^= 0xFF
    bad = tmp_path / "bad.world"
    bad.write_bytes(bytes(data))
    r = A.test_archive(str(bad))
    assert r.status == "failed" and r.errors
    with pytest.raises(A.ArchiveError):
        A.extract(str(bad), str(tmp_path / "o"))
    assert not (tmp_path / "o").exists()       # nothing left behind


def test_truncated_payload(src, tmp_path):
    arc = mk(src, tmp_path)
    bad = tmp_path / "t2.world"
    bad.write_bytes(open(arc, "rb").read()[:-30])
    assert A.test_archive(str(bad)).status == "failed"


def test_7_truncated_header(tmp_path):
    for blob in (b"", b"\x00\x00", b"\x00\x00\x01\x00{\"ver"):
        p = tmp_path / "h.world"
        p.write_bytes(blob)
        assert A.test_archive(str(p)).status == "failed"
        with pytest.raises(A.ArchiveFormatError):
            A.read_archive(str(p))


def test_giant_manifest_length_rejected_without_reading(tmp_path):
    p = tmp_path / "g.world"
    p.write_bytes(b"\xff\xff\xff\xff{")
    with pytest.raises(A.ArchiveFormatError):
        A.read_archive(str(p))


def write_raw(path, manifest, payload):
    mb = json.dumps(manifest).encode()
    with open(path, "wb") as f:
        f.write(len(mb).to_bytes(4, "big") + mb + lzma.compress(payload, format=lzma.FORMAT_XZ))


H = "0" * 64


@pytest.mark.parametrize("manifest", [
    [], {"version": "9.0", "is_folder": True, "original_name": "x", "files": {}},
    {"version": "2.0", "is_folder": "yes", "original_name": "x", "files": {}},
    {"version": "2.0", "is_folder": True, "original_name": "x", "files": {"a": "nothex"}},
    {"version": "2.0", "is_folder": True, "original_name": "x", "files": [1]},
    {"version": "2.0", "is_folder": True, "original_name": "x", "files": {"a": H}, "deduplicated_links": {"b": "zzz"}},
    {"version": "3.0", "is_folder": True, "original_name": "x", "entries": "no"},
    {"version": "3.0", "is_folder": True, "original_name": "x", "entries": [{"type": "file", "path": "a", "size": -1, "sha256": H}]},
    {"version": "3.0", "is_folder": True, "original_name": "x", "entries": [{"type": "weird", "path": "a"}]},
    {"version": "2.0", "is_folder": False, "original_name": "x", "files": {"a": H, "b": H}},
    {"version": "2.0", "is_folder": True, "original_name": "x", "files": {"a": H, "a/b": H}},
])
def test_8_malformed_manifests_rejected(tmp_path, manifest):
    p = str(tmp_path / "m.world")
    write_raw(p, manifest, b"")
    with pytest.raises(A.ArchiveError):
        A.read_archive(p)
    assert A.test_archive(p).status == "failed"


def test_non_json_manifest(tmp_path):
    p = tmp_path / "n.world"
    p.write_bytes((5).to_bytes(4, "big") + b"hello" + b"x")
    with pytest.raises(A.ArchiveFormatError):
        A.read_archive(str(p))


EVIL = ["../evil.txt", "..\\evil.txt", "a/../../evil.txt", "/abs.txt", "\\\\server\\share\\x", "C:\\win.txt",
        "C:evil", "a/./b", "con.txt", "a:stream", "x/", "trail.", "nul"]


@pytest.mark.parametrize("name", EVIL)
def test_9_path_traversal_manifest_rejected(tmp_path, name):
    for man in ({"version": "2.0", "is_folder": True, "original_name": "x", "files": {name: H}},
                {"version": "3.0", "is_folder": True, "original_name": "x",
                 "entries": [{"type": "file", "path": name, "size": 0, "sha256": H}]}):
        p = str(tmp_path / "e.world")
        write_raw(p, man, b"")
        if name == "x/":      # trailing slash on a file name is normalized, not an escape
            continue
        with pytest.raises(A.ArchiveError):
            A.read_archive(p)
    assert not (tmp_path.parent / "evil.txt").exists()


def test_9b_malicious_zip_member_names(tmp_path):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("../../escape.txt", "pwn")
    man = {"version": "2.0", "is_folder": True, "original_name": "x", "files": {"ok.txt": hashlib.sha256(b"pwn").hexdigest()}}
    p = str(tmp_path / "z.world")
    write_raw(p, man, buf.getvalue())
    dest = tmp_path / "dest"
    with pytest.raises(A.ArchiveError):
        A.extract(p, str(dest))
    assert not (tmp_path / "escape.txt").exists() and not dest.exists()
    assert A.test_archive(p).status == "failed"


def test_9c_zip_with_unexpected_extra_member(tmp_path):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("ok.txt", "pwn")
        z.writestr("extra.txt", "not in manifest")
    man = {"version": "2.0", "is_folder": True, "original_name": "x", "files": {"ok.txt": hashlib.sha256(b"pwn").hexdigest()}}
    p = str(tmp_path / "z.world")
    write_raw(p, man, buf.getvalue())
    assert A.test_archive(p).status == "failed"


def test_9d_case_collision_rejected(tmp_path):
    man = {"version": "2.0", "is_folder": True, "original_name": "x", "files": {"A.txt": H, "a.TXT": H}}
    p = str(tmp_path / "c.world")
    write_raw(p, man, b"")
    with pytest.raises(A.UnsafeArchiveError):
        A.read_archive(p)


def test_hash_mismatch_detected(tmp_path):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("ok.txt", "real")
    man = {"version": "2.0", "is_folder": True, "original_name": "x", "files": {"ok.txt": H}}
    p = str(tmp_path / "h.world")
    write_raw(p, man, buf.getvalue())
    r = A.test_archive(p)
    assert r.status == "failed" and any("SHA-256" in e for e in r.errors)
    with pytest.raises(A.ArchiveCorruptError):
        A.extract(p, str(tmp_path / "o"))
    assert not (tmp_path / "o").exists()


def test_missing_file_in_payload_detected(tmp_path):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("a.txt", "x")
    man = {"version": "2.0", "is_folder": True, "original_name": "x",
           "files": {"a.txt": hashlib.sha256(b"x").hexdigest(), "gone.txt": H}}
    p = str(tmp_path / "m.world")
    write_raw(p, man, buf.getvalue())
    r = A.test_archive(p)
    assert r.status == "failed" and any("missing" in e for e in r.errors)


def test_decompression_bomb_limit(tmp_path):
    big = tmp_path / "big.bin"
    big.write_bytes(b"\0" * (6 * 1024 * 1024))
    arc = str(tmp_path / "big.world")
    A.compress(str(big), arc, "Fast")
    # lie about the size in the manifest: payload is larger than declared -> must stop
    info = A.read_archive(arc)
    raw = open(arc, "rb").read()
    mlen = int.from_bytes(raw[:4], "big")
    man = json.loads(raw[4:4 + mlen])
    man["entries"][0]["size"] = 10
    nm = json.dumps(man).encode()
    forged = tmp_path / "forged.world"
    forged.write_bytes(len(nm).to_bytes(4, "big") + nm + raw[4 + mlen:])
    r = A.test_archive(str(forged))
    assert r.status == "failed"
    lim = A.Limits(max_payload_bytes=1000)
    legacy_style = {"version": "2.0", "is_folder": False, "original_name": "big.bin", "files": {"big.bin": H}}
    p = str(tmp_path / "l.world")
    write_raw(p, legacy_style, b"\0" * 100000)
    with pytest.raises(A.ArchiveLimitError):
        A.extract(p, str(tmp_path / "o2"), limits=lim)


def test_entry_limit(tmp_path):
    man = {"version": "2.0", "is_folder": True, "original_name": "x",
           "files": {f"f{i}": H for i in range(10)}}
    p = str(tmp_path / "many.world")
    write_raw(p, man, b"")
    with pytest.raises(A.ArchiveLimitError):
        A.read_archive(p, A.Limits(max_entries=5))


def test_10_empty_file(tmp_path):
    f = tmp_path / "empty.dat"
    f.write_bytes(b"")
    arc = str(tmp_path / "e.world")
    A.compress(str(f), arc)
    assert A.test_archive(arc).status == "ok"
    A.extract(arc, str(tmp_path / "o"))
    assert (tmp_path / "o" / "empty.dat").read_bytes() == b""


def test_11_unicode_and_spaces(tmp_path):
    d = tmp_path / "Ünï folder (x) & y"
    d.mkdir()
    (d / "日本語 ファイル.txt").write_text("こんにちは")
    (d / "sp ace  name.txt").write_text("s")
    arc = str(tmp_path / "ü.world")
    A.compress(str(d), arc)
    out = tmp_path / "out dir"
    A.extract(arc, str(out))
    assert (out / "日本語 ファイル.txt").read_text() == "こんにちは"


def test_12_destination_conflict_never_overwrites_silently(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("new data")
    arc = str(tmp_path / "f.world")
    A.compress(str(f), arc)
    dest = tmp_path / "dest"
    dest.mkdir()
    victim = dest / "f.txt"
    victim.write_text("PRECIOUS")
    with pytest.raises(A.DestinationConflictError) as ei:
        A.extract(arc, str(dest))
    assert ei.value.conflicts == ["f.txt"] and victim.read_text() == "PRECIOUS"
    assert os.listdir(dest) == ["f.txt"]                    # no staging debris
    r = A.extract(arc, str(dest), conflict="skip")
    assert r.skipped == ["f.txt"] and victim.read_text() == "PRECIOUS"
    r = A.extract(arc, str(dest), conflict="rename")
    assert victim.read_text() == "PRECIOUS" and (dest / "f (2).txt").read_text() == "new data"
    A.extract(arc, str(dest), conflict="overwrite")
    assert victim.read_text() == "new data"


def test_12b_extract_into_existing_directory_name(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("x")
    arc = str(tmp_path / "f.world")
    A.compress(str(f), arc)
    dest = tmp_path / "dest"
    (dest / "f.txt").mkdir(parents=True)                      # directory in the way
    with pytest.raises(A.DestinationConflictError):
        A.extract(arc, str(dest))
    with pytest.raises(A.ArchiveError):
        A.extract(arc, str(dest), conflict="overwrite")
    assert (dest / "f.txt").is_dir()


def test_13_cancel_cleans_up(src, tmp_path):
    out = tmp_path / "c.world"
    calls = {"n": 0}

    def cancel():
        calls["n"] += 1
        return calls["n"] > 3
    with pytest.raises(A.OperationCancelled):
        A.compress(str(src), str(out), "Fast", cancel=cancel)
    assert not out.exists()
    assert not [n for n in os.listdir(tmp_path) if n.endswith(".part")]

    arc = mk(src, tmp_path)
    dest = tmp_path / "dest"
    c2 = {"n": 0}

    def cancel2():
        c2["n"] += 1
        return c2["n"] > 4
    with pytest.raises(A.OperationCancelled):
        A.extract(arc, str(dest), cancel=cancel2)
    assert not dest.exists()                                  # we created it -> we removed it

    dest.mkdir()
    (dest / "keep.txt").write_text("mine")
    c2["n"] = 0
    with pytest.raises(A.OperationCancelled):
        A.extract(arc, str(dest), cancel=cancel2)
    assert os.listdir(dest) == ["keep.txt"]                   # unrelated file untouched, staging gone


def test_failed_compress_leaves_no_part_file(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("x")
    out = tmp_path / "o" / "f.world"
    A.compress(str(f), str(out))
    with pytest.raises(FileExistsError):
        A.compress(str(f), str(out))                          # refuses to overwrite by default
    assert not [n for n in os.listdir(out.parent) if n.endswith(".part")]
    with pytest.raises(A.ArchiveError):
        A.compress(str(f), str(f), overwrite=True)            # would clobber the input


def test_compress_never_modifies_inputs(src, tmp_path):
    before = tree(src)
    mk(src, tmp_path)
    assert tree(src) == before


def test_output_inside_source_folder_is_excluded(src):
    out = src / "self.world"
    A.compress(str(src), str(out), "Fast")
    m = A.read_archive(str(out)).manifest
    assert "self.world" not in m.entries


def test_multi_input_archive(tmp_path):
    (tmp_path / "d1").mkdir()
    (tmp_path / "d1" / "x.txt").write_text("1")
    (tmp_path / "f2.txt").write_text("2")
    arc = str(tmp_path / "multi.world")
    A.compress([str(tmp_path / "d1"), str(tmp_path / "f2.txt")], arc, name="Selection")
    m = A.read_archive(arc).manifest
    assert {"d1", "d1/x.txt", "f2.txt"} <= set(m.entries) and m.original_name == "Selection"
    A.extract(arc, str(tmp_path / "o"))
    assert (tmp_path / "o" / "d1" / "x.txt").read_text() == "1"


def test_symlinks_not_followed(tmp_path):
    d = tmp_path / "d"
    d.mkdir()
    (d / "real.txt").write_text("r")
    outside = tmp_path / "secret.txt"
    outside.write_text("secret")
    try:
        os.symlink(outside, d / "link.txt")
        os.symlink(tmp_path, d / "dirlink")
    except OSError:
        pytest.skip("symlinks unavailable")
    arc = str(tmp_path / "s.world")
    r = A.compress(str(d), arc)
    m = A.read_archive(arc).manifest
    assert set(m.entries) == {"real.txt"} and len(r.warnings) == 2


def test_extract_refuses_symlink_escape(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("x")
    arc = str(tmp_path / "f.world")
    A.compress(str(f), arc)
    outside = tmp_path / "outside"
    outside.mkdir()
    dest = tmp_path / "dest"
    dest.mkdir()
    try:
        os.symlink(outside, dest / "f.txt")                   # link pointing out of dest
    except OSError:
        pytest.skip("symlinks unavailable")
    with pytest.raises((A.DestinationConflictError, ValueError)):
        A.extract(arc, str(dest))
    assert os.listdir(outside) == []


def test_selective_extract_and_strip(src, tmp_path):
    arc = mk(src, tmp_path)
    out = tmp_path / "sel"
    A.extract(arc, str(out), members=["a/b"], strip="a")
    assert (out / "b" / "one.txt").read_text() == "same content"
    assert not (out / "two.txt").exists()
    out2 = tmp_path / "sel2"
    A.extract(arc, str(out2), members=["a/three.txt"], strip="a")      # a duplicate entry alone
    assert (out2 / "three.txt").read_text() == "same content"
    with pytest.raises(A.ArchiveError):
        A.extract(arc, str(tmp_path / "x"), members=["nope"])


def test_browse_hierarchy(src, tmp_path):
    m = A.read_archive(mk(src, tmp_path)).manifest
    top = [e.name for e in m.list_dir("")]
    assert top[0] in ("a", "emptydir", "with space") and "two.txt" in top
    assert [e.name for e in m.list_dir("a")] == ["b", "three.txt"]
    assert m.dir_size("a") == len("same content") * 2


def test_insufficient_space(src, tmp_path, monkeypatch):
    arc = mk(src, tmp_path)
    import shutil
    monkeypatch.setattr(shutil, "disk_usage", lambda p: shutil._ntuple_diskusage(100, 99, 1))
    with pytest.raises(A.InsufficientSpaceError):
        A.extract(arc, str(tmp_path / "o"))
    assert not (tmp_path / "o").exists()


def test_trailing_garbage_warns(tmp_path):
    f = tmp_path / "f.txt"
    f.write_text("x")
    arc = tmp_path / "f.world"
    A.compress(str(f), str(arc))
    with open(arc, "ab") as fh:
        fh.write(b"JUNKJUNK")
    r = A.test_archive(str(arc))
    assert r.status == "warning" and "unexpected" in r.warnings[0]


def test_files_before_1980_and_mtime(tmp_path):
    d = tmp_path / "d"
    d.mkdir()
    f = d / "old.txt"
    f.write_text("old")
    os.utime(f, (100000, 100000))
    arc = str(tmp_path / "old.world")
    A.compress(str(d), arc)
    A.extract(arc, str(tmp_path / "o"))
    assert int(os.path.getmtime(tmp_path / "o" / "old.txt")) == 100000
