"""Command-line parsing and launch routing.

Shell verbs call:  "WW World.exe" --open -- "<path>"   (one process per selected item;
the single-instance server merges a burst of them into one multi-selection view).
A path on the command line is NEVER compressed automatically.
"""
from __future__ import annotations

import argparse
import os
import re
from dataclasses import dataclass, field


@dataclass
class LaunchRequest:
    action: str = "gui"          # gui | open | register | unregister | repair | shell-status
    #                              | selftest | test-archive | extract | version
    paths: list[str] = field(default_factory=list)
    hub: bool = False
    context: bool = True
    assoc: bool = True
    report: str = ""
    dest: str = ""


def fix_mangled_arg(arg: str) -> str:
    """Repair the classic '"C:\\"' quoting artefact ('C:"') for drive roots."""
    m = re.fullmatch(r'([A-Za-z]:)\\?"?', arg)
    return m.group(1) + "\\" if m else arg


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="WW World", add_help=True, allow_abbrev=False)
    p.add_argument("paths", nargs="*", help="files/folders/.world archives to open (never auto-compressed)")
    p.add_argument("--open", dest="open_flag", action="store_true", help="open paths in the file manager")
    p.add_argument("--hub", action="store_true", help="start on the Archive Hub")
    p.add_argument("--register-shell", action="store_true", help="register Explorer integration (current user)")
    p.add_argument("--unregister-shell", action="store_true", help="remove WW World's own registrations")
    p.add_argument("--repair-shell", action="store_true", help="re-register pointing at this executable")
    p.add_argument("--shell-status", action="store_true")
    p.add_argument("--no-context", action="store_true", help="with --register-shell: skip context menu")
    p.add_argument("--no-assoc", action="store_true", help="with --register-shell: skip .world association")
    p.add_argument("--selftest", action="store_true", help="headless startup/engine self-check")
    p.add_argument("--test-archive", metavar="ARCHIVE")
    p.add_argument("--extract", metavar="ARCHIVE")
    p.add_argument("--dest", default="")
    p.add_argument("--report", default="", help="write CLI output to this file")
    p.add_argument("--version", action="store_true")
    return p


def parse_args(argv: list[str]) -> LaunchRequest:
    ns = build_parser().parse_args(argv)
    paths = [fix_mangled_arg(x) for x in ns.paths]
    req = LaunchRequest(paths=paths, hub=ns.hub, context=not ns.no_context,
                        assoc=not ns.no_assoc, report=ns.report, dest=ns.dest)
    if ns.version:
        req.action = "version"
    elif ns.selftest:
        req.action = "selftest"
    elif ns.test_archive:
        req.action, req.paths = "test-archive", [ns.test_archive]
    elif ns.extract:
        req.action, req.paths = "extract", [ns.extract]
    elif ns.register_shell:
        req.action = "register"
    elif ns.unregister_shell:
        req.action = "unregister"
    elif ns.repair_shell:
        req.action = "repair"
    elif ns.shell_status:
        req.action = "shell-status"
    elif paths:
        req.action = "open"
    return req


def classify(path: str) -> str:
    """'archive' | 'folder' | 'file' | 'missing'"""
    if not os.path.exists(path):
        return "missing"
    if os.path.isdir(path):
        return "folder"
    return "archive" if path.lower().endswith(".world") else "file"
