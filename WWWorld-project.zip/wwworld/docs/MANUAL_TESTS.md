# Manual Windows test checklist (NOT TESTED in the authoring environment - no Windows available)

Install with `dist\WW-World-Setup-3.0.0.exe` (tick both Windows-integration tasks), then:

| # | Step | Expected | Result |
|---|---|---|---|
| 1 | Launch from Start menu | WW World opens, window + taskbar icon is the blue "W" | ☐ |
| 2 | Right-click a `.txt` → **Show more options** → **WW World File Manager** | File Manager tab opens on that folder with the file selected; details shown; nothing compressed | ☐ |
| 3 | Same with a `.png` | same | ☐ |
| 4 | Right-click a folder → Show more options → WW World File Manager | folder contents listed | ☐ |
| 5 | Right-click empty folder background → same | that folder listed | ☐ |
| 6 | Select 3 files + folder → same verb | one window, "selection" view with all 4 | ☐ |
| 7 | Double-click a `.world` | archive view with folders/files/SHA-256; correct archive icon in Explorer | ☐ |
| 8 | Path `C:\Test Dir\a (1) & b é.txt` | opens correctly | ☐ |
| 9 | Settings → untick context menu → Apply; right-click | entry gone; re-tick → back | ☐ |
| 10 | Move/rename install folder; Settings → Repair (or Start menu "Repair…") | entries point at new path | ☐ |
| 11 | Uninstall | registry keys removed (`reg query HKCU\Software\Classes\.world`), Desktop\WWWorld untouched | ☐ |
| 12 | If `.world` icon is stale | sign out/in or `ie4uinit.exe -show` (Windows caches icons) | ☐ |

`packaging\windows_integration_test.ps1` automates the install / registry / repair / uninstall parts of
1, 9-11; it cannot drive the Explorer context menu itself.
