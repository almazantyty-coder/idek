"""WW World archive format (v2 legacy reader, v3 reader/writer) and engine.

Container (unchanged from the original app, so old archives stay readable):
    [4-byte big-endian manifest length][UTF-8 JSON manifest][xz/LZMA2 stream payload]
Payload: the raw file (single-file archives) or an uncompressed (STORED) ZIP of the
unique files, compressed as ONE solid xz stream. See docs/ARCHIVE_FORMAT.md.
"""
from __future__ import annotations

import hashlib
import json
import lzma
import os
import re
import shutil
import tempfile
import time
import zipfile
from dataclasses import dataclass, field
from typing import Callable, Iterator, Optional

from . import __version__
from .safety import (UnsafePathError, casefold_key, is_reparse, normalize_member_path,
                     resolve_inside, safe_filename)

MiB = 1024 * 1024
CHUNK = 1 * MiB
HEX64 = re.compile(r"^[0-9a-f]{64}$")

ProgressCb = Optional[Callable[[str, int], None]]
CancelCb = Optional[Callable[[], bool]]

# profile -> (xz preset, maximum dictionary size).  Compression memory is roughly
# 10x the dictionary for presets 7-9 (64 MiB ~ 0.7 GiB, 128 MiB ~ 1.4 GiB);
# decompression needs about one dictionary.  The dictionary is shrunk for small inputs.
PROFILES: dict[str, tuple[int, int]] = {
    "Fast": (2, 4 * MiB),
    "Balanced": (6, 8 * MiB),
    "Maximum": (9 | lzma.PRESET_EXTREME, 64 * MiB),
    "Extreme Search": (9 | lzma.PRESET_EXTREME, 128 * MiB),
}
DEFAULT_PROFILE = "Maximum"


class ArchiveError(Exception):
    """Base class for archive problems."""


class ArchiveFormatError(ArchiveError):
    """Not a valid WW World archive (bad header/manifest/version)."""


class ArchiveCorruptError(ArchiveError):
    """Archive structure is valid but data is corrupt or truncated."""


class ArchiveLimitError(ArchiveError):
    """A configured safety limit was exceeded."""


class UnsafeArchiveError(ArchiveError):
    """Archive contains unsafe member names."""


class InsufficientSpaceError(ArchiveError):
    pass


class OperationCancelled(Exception):
    pass


class DestinationConflictError(ArchiveError):
    def __init__(self, conflicts: list[str]):
        self.conflicts = conflicts
        super().__init__(f"{len(conflicts)} item(s) already exist in the destination")


@dataclass
class Limits:
    max_manifest_bytes: int = 64 * MiB
    max_entries: int = 1_000_000
    max_total_bytes: int = 16 * 1024 ** 4        # declared uncompressed size (v3)
    max_payload_bytes: int = 256 * 1024 ** 3     # undeclared payloads (v2)
    xz_memlimit: int = 2 * 1024 ** 3


DEFAULT_LIMITS = Limits()


# --------------------------------------------------------------------------- manifest
@dataclass
class Entry:
    path: str
    kind: str                       # "file" | "dir"
    size: Optional[int] = None
    mtime: Optional[int] = None
    sha256: Optional[str] = None
    dup_of: Optional[str] = None    # file whose stored bytes this entry shares

    @property
    def name(self) -> str:
        return self.path.rsplit("/", 1)[-1]


@dataclass
class Manifest:
    version: str
    is_folder: bool
    original_name: str
    entries: dict[str, Entry]
    extra: dict = field(default_factory=dict)
    _children: Optional[dict[str, list[Entry]]] = field(default=None, repr=False)

    @property
    def major(self) -> int:
        return int(self.version.split(".")[0])

    @property
    def files(self) -> list[Entry]:
        return [e for e in self.entries.values() if e.kind == "file"]

    @property
    def stored_files(self) -> list[Entry]:
        return [e for e in self.files if e.dup_of is None]

    @property
    def total_size(self) -> Optional[int]:
        sizes = [e.size for e in self.files]
        return None if any(s is None for s in sizes) else sum(sizes)

    @property
    def stored_size(self) -> Optional[int]:
        sizes = [e.size for e in self.stored_files]
        return None if any(s is None for s in sizes) else sum(sizes)

    def _build_index(self) -> dict[str, list[Entry]]:
        kids: dict[str, dict[str, Entry]] = {"": {}}
        for e in self.entries.values():
            parts = e.path.split("/")
            for i in range(1, len(parts)):          # synthesize implied parent dirs
                parent, p = "/".join(parts[:i - 1]), "/".join(parts[:i])
                kids.setdefault(parent, {})
                kids.setdefault(p, {})
                kids[parent].setdefault(p, self.entries.get(p) or Entry(p, "dir"))
            parent = "/".join(parts[:-1])
            kids.setdefault(parent, {})[e.path] = e
            if e.kind == "dir":
                kids.setdefault(e.path, {})
        return {k: sorted(v.values(), key=lambda x: (x.kind != "dir", x.name.casefold()))
                for k, v in kids.items()}

    def list_dir(self, inner: str = "") -> list[Entry]:
        if self._children is None:
            self._children = self._build_index()
        if inner not in self._children:
            raise KeyError(inner)
        return self._children[inner]

    def has_dir(self, inner: str) -> bool:
        if self._children is None:
            self._children = self._build_index()
        return inner in self._children

    def dir_size(self, inner: str) -> Optional[int]:
        total = 0
        pre = inner + "/" if inner else ""
        for e in self.files:
            if e.path.startswith(pre):
                if e.size is None:
                    return None
                total += e.size
        return total


def _check_hash(h, where: str) -> str:
    if not isinstance(h, str) or not HEX64.match(h.lower()):
        raise ArchiveFormatError(f"invalid SHA-256 value in manifest ({where})")
    return h.lower()


def _norm(p, where: str) -> str:
    try:
        return normalize_member_path(p)
    except UnsafePathError as exc:
        raise UnsafeArchiveError(f"unsafe path in manifest ({where}): {exc}") from exc


def parse_manifest(raw, limits: Limits = DEFAULT_LIMITS) -> Manifest:
    """Validate a decoded manifest dict. Never trusts names, sizes or hashes."""
    if not isinstance(raw, dict):
        raise ArchiveFormatError("manifest is not a JSON object")
    version = raw.get("version")
    if not isinstance(version, str) or not re.fullmatch(r"\d+\.\d+", version):
        raise ArchiveFormatError("manifest has no valid version")
    major = int(version.split(".")[0])
    if major not in (2, 3):
        raise ArchiveFormatError(f"unsupported archive version {version} "
                                 f"(this WW World reads 2.x and 3.x)")
    is_folder = raw.get("is_folder")
    if not isinstance(is_folder, bool):
        raise ArchiveFormatError("manifest 'is_folder' must be true/false")
    oname = raw.get("original_name")
    if not isinstance(oname, str):
        raise ArchiveFormatError("manifest 'original_name' missing")
    try:
        oname = normalize_member_path(oname)
        if "/" in oname:
            raise UnsafePathError("original_name must be a single name")
    except UnsafePathError:
        oname = safe_filename(oname.replace("\\", "/").rsplit("/", 1)[-1], "archive")

    entries: dict[str, Entry] = {}
    seen_fold: dict[str, str] = {}

    def add(e: Entry):
        key = casefold_key(e.path)
        if key in seen_fold:
            raise UnsafeArchiveError(f"duplicate / case-colliding path: {e.path!r}")
        seen_fold[key] = e.path
        entries[e.path] = e
        if len(entries) > limits.max_entries:
            raise ArchiveLimitError(f"archive has more than {limits.max_entries} entries")

    if major == 2:
        files, links = raw.get("files"), raw.get("deduplicated_links", {})
        if not isinstance(files, dict) or not isinstance(links, dict):
            raise ArchiveFormatError("manifest 'files'/'deduplicated_links' must be objects")
        hashes: dict[str, str] = {}
        for p, h in files.items():
            np = _norm(p, "files")
            hashes[np] = _check_hash(h, p)
            add(Entry(np, "file", sha256=hashes[np]))
        for dup, orig in links.items():
            nd, no = _norm(dup, "link"), _norm(orig, "link target")
            if no not in hashes:
                raise ArchiveFormatError(f"duplicate link {dup!r} points to unknown file {orig!r}")
            add(Entry(nd, "file", sha256=hashes[no], dup_of=no))
        if not is_folder and (len(entries) != 1 or links):
            raise ArchiveFormatError("single-file archive must contain exactly one file")
    else:
        lst = raw.get("entries")
        if not isinstance(lst, list):
            raise ArchiveFormatError("v3 manifest has no 'entries' list")
        total = 0
        for item in lst:
            if not isinstance(item, dict):
                raise ArchiveFormatError("manifest entry is not an object")
            p, kind = _norm(item.get("path"), "entries"), item.get("type")
            mt = item.get("mtime")
            if mt is not None and (not isinstance(mt, int) or isinstance(mt, bool) or mt < 0):
                raise ArchiveFormatError(f"bad mtime for {p!r}")
            if kind == "dir":
                add(Entry(p, "dir", mtime=mt))
            elif kind == "file":
                size = item.get("size")
                if not isinstance(size, int) or isinstance(size, bool) or size < 0:
                    raise ArchiveFormatError(f"bad size for {p!r}")
                total += size
                if total > limits.max_total_bytes:
                    raise ArchiveLimitError("declared uncompressed size exceeds the configured limit")
                dup = item.get("dup_of")
                add(Entry(p, "file", size, mt, _check_hash(item.get("sha256"), p),
                          _norm(dup, "dup_of") if dup is not None else None))
            else:
                raise ArchiveFormatError(f"unknown entry type {kind!r}")
        for e in entries.values():
            if e.dup_of is not None:
                t = entries.get(e.dup_of)
                if t is None or t.kind != "file" or t.dup_of is not None:
                    raise ArchiveFormatError(f"{e.path!r}: dup_of must name a stored file")
                if t.sha256 != e.sha256 or t.size != e.size:
                    raise ArchiveFormatError(f"{e.path!r} does not match its original")
        if not is_folder and not (len(entries) == 1 and next(iter(entries.values())).kind == "file"):
            raise ArchiveFormatError("single-file archive must contain exactly one file")

    # a path may not be both a file and a parent directory
    for e in list(entries.values()):
        parts = e.path.split("/")
        for i in range(1, len(parts)):
            par = entries.get("/".join(parts[:i]))
            if par is not None and par.kind == "file":
                raise ArchiveFormatError(f"{e.path!r} lies below file {par.path!r}")
    return Manifest(version, is_folder, oname, entries, {k: raw.get(k) for k in ("generator", "created")})


@dataclass
class ArchiveInfo:
    path: str
    manifest: Manifest
    payload_offset: int
    archive_size: int


def read_archive(path: str, limits: Limits = DEFAULT_LIMITS) -> ArchiveInfo:
    """Read + validate only the header and manifest (no payload decompression)."""
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as f:
            hdr = f.read(4)
            if len(hdr) < 4:
                raise ArchiveFormatError("file too small to be a WW World archive (truncated header)")
            mlen = int.from_bytes(hdr, "big")
            if mlen == 0 or mlen > limits.max_manifest_bytes:
                raise ArchiveFormatError(f"implausible manifest length ({mlen} bytes); not a WW World archive")
            if 4 + mlen > size:
                raise ArchiveFormatError("archive is truncated inside the manifest")
            blob = f.read(mlen)
    except OSError as exc:
        raise ArchiveError(f"cannot read archive: {exc}") from exc
    try:
        raw = json.loads(blob.decode("utf-8"))
    except (UnicodeDecodeError, ValueError, RecursionError) as exc:
        raise ArchiveFormatError(f"manifest is not valid JSON: {exc}") from exc
    return ArchiveInfo(path, parse_manifest(raw, limits), 4 + mlen, size)


# --------------------------------------------------------------------------- payload
class _Payload:
    """Iterate decompressed payload chunks with size/memory limits and cancellation."""

    def __init__(self, f, max_bytes: int, memlimit: int, cancel: CancelCb):
        self.f, self.max_bytes, self.memlimit, self.cancel = f, max_bytes, memlimit, cancel
        self.total = 0
        self.trailing = 0

    def __iter__(self) -> Iterator[bytes]:
        dec = lzma.LZMADecompressor(format=lzma.FORMAT_XZ, memlimit=self.memlimit)
        try:
            while not dec.eof:
                if self.cancel and self.cancel():
                    raise OperationCancelled()
                if dec.needs_input:
                    data = self.f.read(CHUNK)
                    if not data:
                        raise ArchiveCorruptError("payload is truncated (compressed stream ended early)")
                else:
                    data = b""
                out = dec.decompress(data, max_length=CHUNK)
                if out:
                    self.total += len(out)
                    if self.total > self.max_bytes:
                        raise ArchiveLimitError("decompressed data exceeds the expected/allowed size")
                    yield out
        except lzma.LZMAError as exc:
            raise ArchiveCorruptError(f"payload is corrupt or unsupported: {exc}") from exc
        pos = self.f.tell()
        self.trailing = len(dec.unused_data) + (self.f.seek(0, os.SEEK_END) - pos)


def _payload_limit(m: Manifest, limits: Limits) -> int:
    stored = m.stored_size
    if stored is None:
        return limits.max_payload_bytes
    if not m.is_folder:
        return stored
    n = len(m.entries)
    return stored + MiB + 512 * n + 4 * sum(len(p) for p in m.entries)  # zip headers allowance


def _open_payload(info: ArchiveInfo, limits: Limits, cancel: CancelCb):
    f = open(info.path, "rb")
    f.seek(info.payload_offset)
    return f, _Payload(f, _payload_limit(info.manifest, limits), limits.xz_memlimit, cancel)


# --------------------------------------------------------------------------- helpers
def human_size(n: Optional[int]) -> str:
    if n is None:
        return "—"
    v = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if v < 1024 or unit == "TB":
            return f"{int(v)} B" if unit == "B" else f"{v:.1f} {unit}"
        v /= 1024
    return str(n)


def sha256_file(path: str, cancel: CancelCb = None) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(CHUNK):
            if cancel and cancel():
                raise OperationCancelled()
            h.update(chunk)
    return h.hexdigest()


def _report(cb: ProgressCb, msg: str, pct: float):
    if cb:
        cb(msg, max(0, min(100, int(pct))))


def _zip_time(mtime: Optional[int]):
    t = time.localtime(max(mtime or 0, 315532800))   # ZIP cannot store < 1980
    return (min(t.tm_year, 2107), t.tm_mon, t.tm_mday, t.tm_hour, t.tm_min, t.tm_sec & ~1)


def _pow2_at_least(n: int) -> int:
    return 1 << max(16, (max(n, 1) - 1).bit_length())


# --------------------------------------------------------------------------- compress
@dataclass
class CompressResult:
    output: str
    files: int
    dirs: int
    input_bytes: int
    archive_bytes: int
    deduplicated: int
    warnings: list[str]


def _scan(inputs: list[str], excluded: set[str], warnings: list[str]):
    """Return (is_folder, original_name, items). Item = (rel, abs, kind, size, mtime)."""
    items: list[tuple] = []
    if len(inputs) == 1 and os.path.isfile(inputs[0]):
        p = inputs[0]
        st = os.stat(p)
        name = _norm(os.path.basename(p), "file name")
        return False, name, [(name, p, "file", st.st_size, int(st.st_mtime))]

    def walk(base: str, prefix: str):
        for cur, dirs, files in os.walk(base):
            rel_dir = os.path.relpath(cur, base).replace(os.sep, "/")
            rel_dir = "" if rel_dir == "." else rel_dir
            keep = []
            for d in sorted(dirs):
                full = os.path.join(cur, d)
                if is_reparse(full):
                    warnings.append(f"skipped link/junction (not followed): {full}")
                    continue
                keep.append(d)
                rel = "/".join(x for x in (prefix, rel_dir, d) if x)
                items.append((rel, full, "dir", None, int(os.stat(full).st_mtime)))
            dirs[:] = keep
            for fn in sorted(files):
                full = os.path.join(cur, fn)
                if os.path.realpath(full) in excluded:
                    continue
                if is_reparse(full):
                    warnings.append(f"skipped symbolic link (not followed): {full}")
                    continue
                st = os.stat(full)
                items.append(("/".join(x for x in (prefix, rel_dir, fn) if x), full, "file",
                              st.st_size, int(st.st_mtime)))

    if len(inputs) == 1:
        walk(inputs[0], "")
        return True, _norm(os.path.basename(os.path.normpath(inputs[0])) or "archive", "folder name"), items
    used: set[str] = set()
    for p in inputs:
        base = os.path.basename(os.path.normpath(p))
        name, n = base, 1
        while casefold_key(name) in used:
            n += 1
            name = f"{base} ({n})"
            warnings.append(f"two inputs named {base!r}; second stored as {name!r}")
        used.add(casefold_key(name))
        if os.path.isdir(p):
            if is_reparse(p):
                warnings.append(f"skipped link/junction: {p}")
                continue
            items.append((name, p, "dir", None, int(os.stat(p).st_mtime)))
            walk(p, name)
        else:
            st = os.stat(p)
            items.append((name, p, "file", st.st_size, int(st.st_mtime)))
    return True, "Archive", items


def _norm(p: str, where: str) -> str:
    try:
        return normalize_member_path(p)
    except UnsafePathError as exc:
        raise ArchiveError(f"cannot archive {where}: {exc}") from exc


def compress(inputs: list[str] | str, output_path: str, profile: str = DEFAULT_PROFILE, *,
             name: Optional[str] = None, overwrite: bool = False,
             progress: ProgressCb = None, cancel: CancelCb = None,
             limits: Limits = DEFAULT_LIMITS) -> CompressResult:
    """Create a v3 archive. Never modifies inputs; writes to a temp file then renames."""
    if isinstance(inputs, str):
        inputs = [inputs]
    inputs = [os.path.abspath(p) for p in inputs]
    if not inputs:
        raise ArchiveError("nothing to archive")
    if profile not in PROFILES:
        raise ArchiveError(f"unknown compression profile {profile!r}")
    for p in inputs:
        if not os.path.exists(p):
            raise ArchiveError(f"input not found: {p}")
    output_path = os.path.abspath(output_path)
    out_real = os.path.realpath(output_path)
    for p in inputs:
        if os.path.realpath(p) == out_real:
            raise ArchiveError("output archive would overwrite one of the inputs")
    if os.path.lexists(output_path) and not overwrite:
        raise FileExistsError(output_path)
    if os.path.isdir(output_path):
        raise ArchiveError("output path is a directory")
    outdir = os.path.dirname(output_path)
    os.makedirs(outdir, exist_ok=True)

    warnings: list[str] = []
    _report(progress, "Scanning files...", 2)
    excluded = {out_real}
    is_folder, oname, items = _scan(inputs, excluded, warnings)
    if name and is_folder:
        oname = safe_filename(name)
    if len(items) > limits.max_entries:
        raise ArchiveLimitError(f"too many files (limit {limits.max_entries})")
    seen: dict[str, str] = {}
    for rel, *_ in items:
        _norm(rel, rel)
        k = casefold_key(rel)
        if k in seen:
            raise ArchiveError(f"names differ only by case ({seen[k]!r} / {rel!r}); not restorable on Windows")
        seen[k] = rel

    files = [i for i in items if i[2] == "file"]
    total_in = sum(i[3] for i in files)

    # pass 1: hash + deduplicate
    hashes: dict[str, str] = {}
    first_by_key: dict[tuple, str] = {}
    dup_of: dict[str, str] = {}
    done = 0
    for rel, full, _k, size, _m in files:
        try:
            h = sha256_file(full, cancel)
        except PermissionError as exc:
            raise ArchiveError(f"cannot read {full}: permission denied") from exc
        hashes[rel] = h
        key = (h, size)
        if key in first_by_key:
            dup_of[rel] = first_by_key[key]
        else:
            first_by_key[key] = rel
        done += size
        _report(progress, f"Analyzing: {rel}", 3 + 22 * done / max(total_in, 1))

    entries = []
    for rel, _full, kind, size, mt in items:
        if kind == "dir":
            entries.append({"type": "dir", "path": rel, "mtime": mt})
        else:
            e = {"type": "file", "path": rel, "size": size, "mtime": mt, "sha256": hashes[rel]}
            if rel in dup_of:
                e["dup_of"] = dup_of[rel]
            entries.append(e)
    stored = [i for i in files if i[0] not in dup_of]
    stored_bytes = sum(i[3] for i in stored)
    manifest = {
        "version": "3.0", "generator": f"WW World {__version__}", "created": int(time.time()),
        "is_folder": is_folder, "original_name": oname, "entries": entries,
        # legacy keys keep the 2.x reader semantics available to older tools
        "files": {i[0]: hashes[i[0]] for i in stored},
        "deduplicated_links": dup_of,
    }
    mbytes = json.dumps(manifest, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(mbytes) > limits.max_manifest_bytes:
        raise ArchiveLimitError("manifest would exceed the size limit")

    preset, dmax = PROFILES[profile]
    dict_size = min(dmax, _pow2_at_least(stored_bytes + 64 * 1024))
    filters = [{"id": lzma.FILTER_LZMA2, "preset": preset, "dict_size": dict_size}]

    fd, part = tempfile.mkstemp(prefix=".wwworld-", suffix=".part", dir=outdir)
    written = 0

    def feed(src: str, rel: str, sink, expect_size: int):
        nonlocal written
        h = hashlib.sha256()
        n = 0
        with open(src, "rb") as fin:
            while chunk := fin.read(CHUNK):
                if cancel and cancel():
                    raise OperationCancelled()
                h.update(chunk)
                n += len(chunk)
                sink.write(chunk)
                written += len(chunk)
                _report(progress, f"Compressing: {rel}", 25 + 72 * written / max(stored_bytes, 1))
        if n != expect_size or h.hexdigest() != hashes[rel]:
            raise ArchiveError(f"file changed while archiving: {src}")

    try:
        with os.fdopen(fd, "wb") as out:
            out.write(len(mbytes).to_bytes(4, "big"))
            out.write(mbytes)
            with lzma.LZMAFile(out, "wb", format=lzma.FORMAT_XZ, filters=filters) as xz:
                if not is_folder:
                    rel, full, _k, size, _m = files[0]
                    feed(full, rel, xz, size)
                else:
                    with zipfile.ZipFile(xz, "w", zipfile.ZIP_STORED, allowZip64=True) as zf:
                        for rel, full, _k, size, mt in stored:
                            zi = zipfile.ZipInfo(rel, _zip_time(mt))
                            zi.compress_type = zipfile.ZIP_STORED
                            zi.file_size = size
                            zi.external_attr = 0o644 << 16
                            with zf.open(zi, "w") as zsink:
                                feed(full, rel, zsink, size)
        os.chmod(part, 0o644)
        if os.path.lexists(output_path) and not overwrite:
            raise FileExistsError(output_path)
        os.replace(part, output_path)
    except BaseException:
        try:
            os.remove(part)           # only the temp file this call created
        except OSError:
            pass
        raise
    _report(progress, "Archive created.", 100)
    return CompressResult(output_path, len(files), len(items) - len(files), total_in,
                          os.path.getsize(output_path), len(dup_of), warnings)


# --------------------------------------------------------------------------- test
@dataclass
class TestResult:
    __test__ = False
    status: str = "ok"                       # ok | warning | failed
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    files_checked: int = 0
    files_total: int = 0
    bytes_checked: int = 0

    def finish(self) -> "TestResult":
        self.status = "failed" if self.errors else ("warning" if self.warnings else "ok")
        return self

    def summary(self) -> str:
        head = {"ok": "PASSED", "warning": "PASSED WITH WARNINGS", "failed": "FAILED"}[self.status]
        lines = [f"Archive test {head}: {self.files_checked}/{self.files_total} file(s) "
                 f"hash-verified ({human_size(self.bytes_checked)})."]
        lines += [f"ERROR: {e}" for e in self.errors] + [f"WARNING: {w}" for w in self.warnings]
        lines += [f"Note: {n}" for n in self.notes]
        return "\n".join(lines)


def _stream_zip_member(zf: zipfile.ZipFile, zinfo, cancel: CancelCb):
    with zf.open(zinfo) as zin:
        while chunk := zin.read(CHUNK):
            if cancel and cancel():
                raise OperationCancelled()
            yield chunk


def _map_zip(zf: zipfile.ZipFile, m: Manifest) -> dict[str, zipfile.ZipInfo]:
    zmap: dict[str, zipfile.ZipInfo] = {}
    for zi in zf.infolist():
        if zi.is_dir():
            continue
        try:
            n = normalize_member_path(zi.filename)
        except UnsafePathError as exc:
            raise UnsafeArchiveError(f"unsafe member name inside payload: {exc}") from exc
        if n in zmap:
            raise ArchiveCorruptError(f"payload contains {n!r} twice")
        zmap[n] = zi
    stored = {e.path: e for e in m.stored_files}
    extra = set(zmap) - set(stored)
    if extra:
        raise ArchiveCorruptError(f"payload contains unexpected path(s): {sorted(extra)[:3]}")
    missing = set(stored) - set(zmap)
    if missing:
        raise ArchiveCorruptError(f"payload is missing file(s): {sorted(missing)[:3]}")
    for p, zi in zmap.items():
        if stored[p].size is not None and zi.file_size != stored[p].size:
            raise ArchiveCorruptError(f"size mismatch for {p!r}")
    return zmap


def test_archive(path: str, progress: ProgressCb = None, cancel: CancelCb = None,
                 limits: Limits = DEFAULT_LIMITS) -> TestResult:
    """Full integrity test: header, manifest, whole payload, structure, sizes, SHA-256.

    Nothing is written to a user directory; a scratch file in the system temp folder
    (folder archives only) is always removed.
    """
    res = TestResult()
    try:
        info = read_archive(path, limits)
    except ArchiveError as exc:
        res.errors.append(str(exc))
        return res.finish()
    m = info.manifest
    res.files_total = len(m.files)
    res.notes.append(f"format version {m.version}, {len(m.files)} file(s), "
                     f"{len(m.entries) - len(m.files)} folder(s)")
    if m.major == 2:
        res.notes.append("legacy 2.x archive: no sizes recorded, empty folders were not stored; "
                         "duplicate files are verified through the original they link to")
    scratch = None
    f = None
    try:
        f, payload = _open_payload(info, limits, cancel)
        _report(progress, "Decompressing payload...", 5)
        est = max(_payload_limit(m, limits), 1) if m.stored_size is not None else None

        def tick(label):
            if est:
                _report(progress, label, 5 + 85 * min(payload.total / est, 1))

        verified: dict[str, str] = {}   # stored path -> sha256 actually computed
        if not m.is_folder:
            e = m.files[0]
            h, n = hashlib.sha256(), 0
            for chunk in payload:
                h.update(chunk)
                n += len(chunk)
                tick("Verifying...")
            if e.size is not None and n != e.size:
                res.errors.append(f"size mismatch: manifest {e.size}, payload {n}")
            if h.hexdigest() != e.sha256:
                res.errors.append(f"SHA-256 mismatch for {e.path!r}")
            else:
                verified[e.path] = e.sha256
        else:
            fd, scratch = tempfile.mkstemp(prefix="wwworld-test-", suffix=".tmp")
            with os.fdopen(fd, "wb") as tmp:
                for chunk in payload:
                    tmp.write(chunk)
                    tick("Decompressing...")
            try:
                zf = zipfile.ZipFile(scratch)
            except zipfile.BadZipFile as exc:
                raise ArchiveCorruptError(f"payload is not a valid file container: {exc}") from exc
            with zf:
                zmap = _map_zip(zf, m)
                total = max(m.stored_size or 1, 1)
                done = 0
                for p, zi in zmap.items():
                    h = hashlib.sha256()
                    try:
                        for chunk in _stream_zip_member(zf, zi, cancel):
                            h.update(chunk)
                            done += len(chunk)
                            _report(progress, f"Verifying: {p}", 90 + 9 * done / total)
                    except zipfile.BadZipFile as exc:
                        res.errors.append(f"data error in {p!r}: {exc}")
                        continue
                    if h.hexdigest() != m.entries[p].sha256:
                        res.errors.append(f"SHA-256 mismatch for {p!r}")
                    else:
                        verified[p] = h.hexdigest()
        if payload.trailing:
            res.warnings.append(f"{payload.trailing} unexpected byte(s) after the compressed payload")
        for e in m.files:
            src = e.dup_of or e.path
            if src in verified:
                res.files_checked += 1
                res.bytes_checked += e.size or 0
        if not res.errors and res.files_checked != res.files_total:
            res.errors.append("not every file could be verified")
    except OperationCancelled:
        raise
    except ArchiveError as exc:
        res.errors.append(str(exc))
    except OSError as exc:
        res.errors.append(f"I/O error: {exc}")
    finally:
        if f:
            f.close()
        if scratch and os.path.exists(scratch):
            try:
                os.remove(scratch)
            except OSError:
                pass
    _report(progress, "Test finished.", 100)
    return res.finish()


# --------------------------------------------------------------------------- extract
@dataclass
class ExtractionPlan:
    targets: list[tuple[Entry, str]]      # (entry, relative output path)
    dirs: list[str]
    conflicts: list[str]
    total_bytes: Optional[int]


@dataclass
class ExtractResult:
    dest: str
    files_written: int
    skipped: list[str]
    renamed: dict[str, str]
    bytes_written: int
    verified: bool


def _select(m: Manifest, members: Optional[list[str]]) -> list[Entry]:
    if members is None:
        return list(m.entries.values())
    chosen: dict[str, Entry] = {}
    for raw in members:
        p = _norm_member(raw)
        e = m.entries.get(p)
        if e is None and not m.has_dir(p):
            raise ArchiveError(f"not found in archive: {raw!r}")
        if e is not None and e.kind == "file":
            chosen[p] = e
            continue
        pre = p + "/"
        for q, x in m.entries.items():
            if q == p or q.startswith(pre):
                chosen[q] = x
        if p not in chosen:
            chosen[p] = Entry(p, "dir")
    return list(chosen.values())


def _norm_member(p: str) -> str:
    try:
        return normalize_member_path(p)
    except UnsafePathError as exc:
        raise UnsafeArchiveError(str(exc)) from exc


def plan_extraction(info: ArchiveInfo, dest: str, members: Optional[list[str]] = None,
                    strip: str = "") -> ExtractionPlan:
    """Work out targets and conflicts without writing anything."""
    m = info.manifest
    sel = _select(m, members)
    strip = _norm_member(strip) if strip else ""
    targets, dirs = [], []
    for e in sel:
        rel = e.path
        if strip:
            if e.path == strip:
                continue
            if e.path.startswith(strip + "/"):
                rel = e.path[len(strip) + 1:]
        if e.kind == "dir":
            dirs.append(rel)
        else:
            targets.append((e, rel))
    seen: dict[str, str] = {}
    for rel in [t[1] for t in targets] + dirs:
        k = casefold_key(rel)
        if seen.get(k, rel) != rel:
            raise UnsafeArchiveError(f"extraction would collide on {rel!r}")
        seen[k] = rel
    conflicts = []
    for _e, rel in targets:
        tgt = resolve_inside(dest, rel)       # raises UnsafePathError if it escapes
        if os.path.lexists(tgt):
            conflicts.append(rel)
        else:
            parts = rel.split("/")
            for i in range(1, len(parts)):    # a file where a folder is needed
                pp = os.path.join(os.path.realpath(dest), *parts[:i])
                if os.path.lexists(pp) and not os.path.isdir(pp):
                    conflicts.append("/".join(parts[:i]))
                    break
    for rel in dirs:
        tgt = resolve_inside(dest, rel)
        if os.path.lexists(tgt) and not os.path.isdir(tgt):
            conflicts.append(rel)
    sizes = [e.size for e, _ in targets]
    total = None if any(s is None for s in sizes) else sum(sizes)
    return ExtractionPlan(targets, dirs, sorted(set(conflicts)), total)


def _free_name(path: str) -> str:
    stem, ext = os.path.splitext(path)
    n = 2
    while os.path.lexists(f"{stem} ({n}){ext}"):
        n += 1
    return f"{stem} ({n}){ext}"


def _nearest_existing(p: str) -> str:
    p = os.path.abspath(p)
    while not os.path.exists(p):
        parent = os.path.dirname(p)
        if parent == p:
            break
        p = parent
    return p


def extract(archive: str, dest: str, *, members: Optional[list[str]] = None, strip: str = "",
            conflict: str = "error", progress: ProgressCb = None, cancel: CancelCb = None,
            limits: Limits = DEFAULT_LIMITS) -> ExtractResult:
    """Safely extract (optionally a selection) into `dest`.

    conflict: 'error' (default; nothing written), 'skip', 'rename', 'overwrite'.
    Data is staged and hash-verified in a private temp folder inside `dest` first;
    only then are files moved into place. Only that staging folder is ever cleaned up.
    """
    if conflict not in ("error", "skip", "rename", "overwrite"):
        raise ValueError("conflict must be error|skip|rename|overwrite")
    info = read_archive(archive, limits)
    m = info.manifest
    dest = os.path.abspath(dest)
    plan = plan_extraction(info, dest, members, strip)
    if plan.conflicts and conflict == "error":
        raise DestinationConflictError(plan.conflicts)
    blocking = [c for c in plan.conflicts if os.path.isdir(resolve_inside(dest, c)) and conflict == "overwrite"]
    if blocking:
        raise ArchiveError(f"cannot overwrite folder with file: {blocking[0]!r}")
    needed = (plan.total_bytes or 0) * 2
    if plan.total_bytes is not None:
        free = shutil.disk_usage(_nearest_existing(dest)).free
        if needed > free:
            raise InsufficientSpaceError(
                f"need about {human_size(needed)} free space, only {human_size(free)} available")

    created_dest = not os.path.isdir(dest)
    os.makedirs(dest, exist_ok=True)
    staging = tempfile.mkdtemp(prefix=".wwworld-extract-", dir=dest)
    staged: list[tuple[str, str, Entry]] = []       # (staged file, rel, entry)
    f = None
    try:
        f, payload = _open_payload(info, limits, cancel)
        total = max(plan.total_bytes or 1, 1)
        done = 0
        _report(progress, "Reading archive...", 3)

        def stage(rel: str, e: Entry, chunks) -> None:
            nonlocal done
            sp = os.path.join(staging, f"f{len(staged):06d}")
            h, n = hashlib.sha256(), 0
            with open(sp, "wb") as out:
                for c in chunks:
                    h.update(c)
                    n += len(c)
                    out.write(c)
                    done += len(c)
                    _report(progress, f"Extracting: {rel}", 5 + 85 * min(done / total, 1))
            if h.hexdigest() != e.sha256 or (e.size is not None and n != e.size):
                raise ArchiveCorruptError(f"hash/size verification failed for {e.path!r}")
            if e.mtime:
                try:
                    os.utime(sp, (e.mtime, e.mtime))
                except OSError:
                    pass
            staged.append((sp, rel, e))

        if not m.is_folder:
            if plan.targets:
                e, rel = plan.targets[0]
                stage(rel, e, payload)
                if payload.trailing:
                    raise ArchiveCorruptError("unexpected data after compressed payload")
        else:
            scratch = os.path.join(staging, "payload.tmp")
            with open(scratch, "wb") as tmp:
                for c in payload:
                    tmp.write(c)
                    _report(progress, "Decompressing...", 5 + 40 * min(payload.total / max(_payload_limit(m, limits), 1), 1))
            try:
                zf = zipfile.ZipFile(scratch)
            except zipfile.BadZipFile as exc:
                raise ArchiveCorruptError(f"payload is not a valid file container: {exc}") from exc
            with zf:
                zmap = _map_zip(zf, m)
                for e, rel in plan.targets:
                    zi = zmap[e.dup_of or e.path]
                    try:
                        stage(rel, e, _stream_zip_member(zf, zi, cancel))
                    except zipfile.BadZipFile as exc:
                        raise ArchiveCorruptError(f"data error in {e.path!r}: {exc}") from exc
            os.remove(scratch)

        # ---- finalize: everything verified; now move into place
        _report(progress, "Finalizing...", 93)
        for rel in plan.dirs:
            os.makedirs(resolve_inside(dest, rel), exist_ok=True)
        skipped, renamed, count, nbytes = [], {}, 0, 0
        for sp, rel, e in staged:
            if cancel and cancel():
                raise OperationCancelled()
            tgt = resolve_inside(dest, rel)
            if os.path.lexists(tgt):
                if conflict == "skip":
                    skipped.append(rel)
                    continue
                if conflict == "rename":
                    tgt = _free_name(tgt)
                    renamed[rel] = os.path.relpath(tgt, dest).replace(os.sep, "/")
                elif conflict == "error":
                    raise DestinationConflictError([rel])
            os.makedirs(os.path.dirname(tgt), exist_ok=True)
            resolve_inside(dest, os.path.relpath(tgt, dest).replace(os.sep, "/"))
            os.replace(sp, tgt)
            count += 1
            nbytes += e.size or 0
        _report(progress, "Extraction complete.", 100)
        return ExtractResult(dest, count, skipped, renamed, nbytes, True)
    except BaseException:
        if created_dest:
            pass  # removed in finally if empty
        raise
    finally:
        if f:
            f.close()
        shutil.rmtree(staging, ignore_errors=True)     # only our own staging folder
        if created_dest:
            try:
                os.rmdir(dest)                          # succeeds only if still empty
            except OSError:
                pass
