# Test report (actual results)

Environment: Linux x86-64 sandbox, Python 3.12.3, PyQt6 (offscreen platform), pytest.
Command: `QT_QPA_PLATFORM=offscreen python -m pytest tests -q` → **98 passed in ~7 s**.

| File | Tests | Covers |
|---|---|---|
| tests/test_engine.py | 59 | single file; nested folders; duplicates; empty files/dirs; Unicode+spaces; all 4 profiles; test-without-extract; corrupt payload; truncated payload/header; giant header length; 10 malformed manifests; 13 traversal/absolute/drive/UNC/reserved names; malicious ZIP members; extra/missing payload members; case collisions; hash mismatch; decompression-bomb limit; entry limit; destination conflicts (error/skip/rename/overwrite, dir-in-the-way, symlink escape); cancel/failure cleanup for compress and extract; input never modified; output excluded from own source folder; multi-input; symlinks not followed; selective extract + strip; browse hierarchy; low disk space; trailing garbage; pre-1980 mtimes |
| tests/test_legacy_compat.py | 4 | archives produced by the **original engine** (extracted verbatim from the uploaded file): folder+dedup, single file, Windows-style backslash manifests, and the old engine reading new archives |
| tests/test_shell_launch.py | 13 | registry layout/commands/icon/uninstall/restore-previous-handler/repair/stale detection against an in-memory fake `winreg`; argument parsing (odd characters, `--`, drive-root quoting artefact, never auto-compress) |
| tests/test_gui.py | 18 | window+tabs; folder browse/back/up/forward; file open selects file and compresses nothing; multi-selection; missing path; archive hierarchy navigation + SHA-256 column; invalid archive error; real drag-and-drop events; create→verify→extract→test through the GUI with progress and report file; conflict dialog; failure never sticks GUI; real cancel; busy refusal; Outputs refresh + error; settings persistence; single-instance burst merge; risky-file confirmation |
| tests/test_cli_e2e.py | 4 | real subprocesses: `--version`, `--selftest`, `--test-archive` / `--extract` exit codes, second launch handing over to a running first instance |

Additional manual runs: PyInstaller built a **Linux** one-folder app from `packaging/ww_world.spec`; run from a
directory with spaces and an empty `PATH`, `--selftest` returned PASS with `frozen: True` (resources found,
engine round-trip, main window constructed).

## NOT TESTED (needs Windows)
* `WW World.exe` (not built - PyInstaller cannot cross-compile; use `packaging\build.ps1` or the GitHub workflow)
* embedded EXE icon, version resource
* Inno Setup installer (`WWWorld.iss`), shortcuts, repair, uninstall
* real `winreg` writes, Explorer context menu / "Show more options", `.world` icon & association, `SHChangeNotify`
* Windows known-folder Desktop lookup, Explorer launching several processes for a multi-selection
* Windows Defender/SmartScreen behaviour of an unsigned EXE (expect a SmartScreen prompt until signed)
