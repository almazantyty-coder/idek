"""Main window: tabs, shared progress bar, operation orchestration."""
from __future__ import annotations

import os
import time

from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QAction, QIcon
from PyQt6.QtWidgets import (QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMainWindow,
                             QMessageBox, QProgressBar, QPushButton, QTabWidget, QVBoxLayout, QWidget)

from .. import APP_NAME, __version__, paths, settings as S
from .. import archive as A
from ..safety import safe_filename
from .filemanager import FileManagerWidget
from .pages import HubPage, OutputsPage, SettingsPage
from .theme import STYLE
from .workers import OperationWorker


class DestDialog(QDialog):
    def __init__(self, parent, title: str, default: str):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(560)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Extract to this folder:"))
        row = QHBoxLayout()
        self.edit = QLineEdit(default)
        b = QPushButton("Browse…")
        b.setObjectName("secondary")
        b.clicked.connect(self._browse)
        row.addWidget(self.edit, 1)
        row.addWidget(b)
        lay.addLayout(row)
        row2 = QHBoxLayout()
        row2.addStretch(1)
        ok, cancel = QPushButton("Extract"), QPushButton("Cancel")
        cancel.setObjectName("secondary")
        ok.clicked.connect(self.accept)
        cancel.clicked.connect(self.reject)
        row2.addWidget(cancel)
        row2.addWidget(ok)
        lay.addLayout(row2)

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Choose destination", self.edit.text())
        if d:
            self.edit.setText(d)

    def path(self) -> str:
        return self.edit.text().strip()


def unique_dir(base: str) -> str:
    cand, n = base, 2
    while os.path.exists(cand):
        cand = f"{base} ({n})"
        n += 1
    return cand


class WWWorldMainWindow(QMainWindow):
    def __init__(self, request=None):
        super().__init__()
        self.settings = S.load()
        self.worker: OperationWorker | None = None
        self.setWindowTitle(f"{APP_NAME} - Archive Suite {__version__}")
        icon = paths.resource_path(os.path.join("assets", "ww_world.ico"))
        if os.path.isfile(icon):
            self.setWindowIcon(QIcon(icon))
        self.resize(1180, 720)
        self.setStyleSheet(STYLE)
        try:
            paths.ensure_workspace(self.settings.outputs())
        except OSError as exc:
            QMessageBox.warning(self, APP_NAME, f"Could not create the workspace folders:\n{exc}")

        self.tabs = QTabWidget()
        self.hub = HubPage(self)
        self.fm = FileManagerWidget(self)
        self.outputs = OutputsPage(self)
        self.settings_page = SettingsPage(self)
        for w, n in ((self.hub, "Archive Hub"), (self.fm, "WW World File Manager"),
                     (self.outputs, "Outputs Manager"), (self.settings_page, "Settings")):
            self.tabs.addTab(w, n)
        self.setCentralWidget(self.tabs)

        sb = self.statusBar()
        self.status_label = QLabel("Ready")
        self.progress = QProgressBar()
        self.progress.setMaximumWidth(320)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.setObjectName("danger")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self._cancel)
        sb.addWidget(self.status_label, 1)
        sb.addPermanentWidget(self.progress)
        sb.addPermanentWidget(self.btn_cancel)

        m = self.menuBar().addMenu("&File")
        a = QAction("Open Folder or Archive in File Manager…", self)
        a.triggered.connect(self._menu_open)
        m.addAction(a)
        q = QAction("Exit", self)
        q.triggered.connect(self.close)
        m.addAction(q)
        h = self.menuBar().addMenu("&Help")
        ab = QAction("About", self)
        ab.triggered.connect(lambda: QMessageBox.about(
            self, APP_NAME, f"{APP_NAME} {__version__}\nFree archiver with the .world format.\n"
                            f"Logs: {paths.log_dir()}"))
        h.addAction(ab)

        self._pending: list[str] = []
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._flush_open)

        if request is not None:
            if request.action == "open" and request.paths:
                self.open_in_manager(request.paths)
            elif request.hub:
                self.tabs.setCurrentWidget(self.hub)

    # ---------------------------------------------------------------- helpers
    def outputs_dir(self) -> str:
        return self.settings.outputs()

    def log(self, msg: str):
        self.hub.append_log(f"[{time.strftime('%H:%M:%S')}] {msg}")

    def open_in_manager(self, ps: list[str]):
        self.tabs.setCurrentWidget(self.fm)
        self.fm.open_paths(ps)

    def handle_external_open(self, paths_: list[str]):
        """From another WW World process; bursts (multi-select) are merged."""
        self._pending.extend(paths_)
        self._timer.start(400)

    def _flush_open(self):
        ps, self._pending = list(dict.fromkeys(self._pending)), []
        if ps:
            self.open_in_manager(ps)
        self.setWindowState(self.windowState() & ~Qt.WindowState.WindowMinimized)
        self.show()
        self.raise_()
        self.activateWindow()

    def _menu_open(self):
        d = QFileDialog.getExistingDirectory(self, "Open folder in File Manager", self.outputs_dir())
        if d:
            self.open_in_manager([d])

    # ---------------------------------------------------------------- operations
    def run_operation(self, title: str, fn, on_ok=None, show_result: bool = False):
        if self.worker is not None:
            QMessageBox.information(self, APP_NAME, "Another operation is still running. "
                                                    "Wait for it to finish or press Cancel.")
            return
        self.log(f"{title}...")
        self.status_label.setText(title)
        self.progress.setValue(0)
        self.btn_cancel.setEnabled(True)
        w = OperationWorker(fn, self)
        w.progress.connect(self._on_progress)
        w.result_ready.connect(lambda res, w=w: self._on_done(w, title, res, on_ok))
        self.worker = w
        w.start()

    def _on_progress(self, msg: str, pct: int):
        self.status_label.setText(msg)
        self.progress.setValue(pct)

    def _cancel(self):
        if self.worker:
            self.worker.cancel()
            self.status_label.setText("Cancelling...")
            self.btn_cancel.setEnabled(False)

    def _on_done(self, w: OperationWorker, title: str, res: dict, on_ok):
        w.wait()
        self.worker = None
        self.btn_cancel.setEnabled(False)
        w.deleteLater()
        try:
            if res["cancelled"]:
                self.status_label.setText("Cancelled")
                self.progress.setValue(0)
                self.log(f"{title}: cancelled; temporary files removed.")
            elif not res["ok"]:
                self.status_label.setText("Failed")
                self.progress.setValue(0)
                self.log(f"{title}: FAILED - {res['error']}")
                QMessageBox.critical(self, APP_NAME, f"{title} failed:\n\n{res['error']}")
            else:
                self.status_label.setText("Done")
                if on_ok:
                    on_ok(res["value"])
        finally:
            self.outputs.refresh()

    # --- create
    def create_archive(self, inputs: list[str], profile: str | None = None):
        profile = profile or self.settings.profile
        if len(inputs) == 1:
            base = safe_filename(os.path.basename(os.path.normpath(inputs[0])) or "archive")
            if os.path.isfile(inputs[0]):
                base = os.path.splitext(base)[0] or base
        else:
            base = "Archive"
        default = os.path.join(self.outputs_dir(), base + ".world")
        out, _ = QFileDialog.getSaveFileName(self, "Create WW World archive", default, "WW World Archive (*.world)")
        if not out:
            return
        if not out.lower().endswith(".world"):
            out += ".world"
        verify = self.settings.verify_after_create

        def job(progress, cancel):
            res = A.compress(inputs, out, profile, name=base if len(inputs) > 1 else None,
                             overwrite=True, progress=lambda m, p: progress(m, p * (0.8 if verify else 1)),
                             cancel=cancel)
            test = None
            if verify:
                test = A.test_archive(out, lambda m, p: progress("Verifying: " + m, 80 + p * 0.2), cancel)
            return res, test

        def done(val):
            res, test = val
            lines = [f"Created {res.output}", f"{res.files} file(s), {res.dirs} folder(s); "
                     f"{A.human_size(res.input_bytes)} -> {A.human_size(res.archive_bytes)}"
                     + (f"; {res.deduplicated} duplicate(s) stored once" if res.deduplicated else "")]
            lines += [f"Warning: {w}" for w in res.warnings]
            if test:
                lines.append("Verification: " + test.summary().splitlines()[0])
            for ln in lines:
                self.log(ln)
            if test and test.status == "failed":
                QMessageBox.critical(self, APP_NAME, "Archive was created but FAILED verification:\n\n" + test.summary())
            else:
                QMessageBox.information(self, APP_NAME, "\n".join(lines))

        self.run_operation("Creating archive", job, done)

    # --- extract
    def extract_archive(self, archive: str, members: list[str] | None = None, strip: str = ""):
        try:
            info = A.read_archive(archive)
        except A.ArchiveError as exc:
            QMessageBox.critical(self, APP_NAME, f"Cannot read archive:\n\n{exc}")
            return
        m = info.manifest
        stem = safe_filename(os.path.splitext(os.path.basename(archive))[0])
        if members is None and m.is_folder:
            default = unique_dir(os.path.join(self.outputs_dir(), safe_filename(m.original_name)))
        elif members is None:
            default = self.outputs_dir()
        else:
            default = unique_dir(os.path.join(self.outputs_dir(), stem))
        dlg = DestDialog(self, "Extract", default)
        if dlg.exec() != QDialog.DialogCode.Accepted or not dlg.path():
            return
        dest = os.path.abspath(dlg.path())
        try:
            plan = A.plan_extraction(info, dest, members, strip)
        except (A.ArchiveError, ValueError, OSError) as exc:
            QMessageBox.critical(self, APP_NAME, f"Cannot extract:\n\n{exc}")
            return
        policy = "error"
        if plan.conflicts:
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Icon.Warning)
            box.setWindowTitle("Files already exist")
            box.setText(f"{len(plan.conflicts)} item(s) already exist in the destination, e.g.\n"
                        + "\n".join(plan.conflicts[:5]) + "\n\nWhat should WW World do?")
            keep = box.addButton("Keep both (rename)", QMessageBox.ButtonRole.AcceptRole)
            over = box.addButton("Overwrite", QMessageBox.ButtonRole.DestructiveRole)
            skip = box.addButton("Skip existing", QMessageBox.ButtonRole.ActionRole)
            box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            c = box.clickedButton()
            policy = {keep: "rename", over: "overwrite", skip: "skip"}.get(c)
            if policy is None:
                return
        self.run_operation(
            "Extracting archive",
            lambda progress, cancel: A.extract(archive, dest, members=members, strip=strip, conflict=policy,
                                               progress=progress, cancel=cancel),
            lambda r: (self.log(f"Extracted {r.files_written} file(s) to {r.dest}; all hashes verified"
                                + (f"; {len(r.skipped)} skipped" if r.skipped else "")
                                + (f"; {len(r.renamed)} renamed" if r.renamed else "")),
                       QMessageBox.information(self, APP_NAME, f"Extracted {r.files_written} file(s) to:\n{r.dest}\n"
                                                               "SHA-256 verified for every extracted file.")))

    # --- test
    def test_archive(self, archive: str):
        def done(res: A.TestResult):
            text = res.summary()
            self.log(text.replace("\n", " | "))
            report = ""
            try:
                _, rep = paths.ensure_workspace(self.settings.outputs())
                report = os.path.join(rep, f"{safe_filename(os.path.basename(archive))}-test-{time.strftime('%Y%m%d-%H%M%S')}.txt")
                with open(report, "w", encoding="utf-8") as f:
                    f.write(f"Archive: {archive}\n{text}\n")
                text += f"\n\nReport saved: {report}"
            except OSError:
                pass
            (QMessageBox.information if res.status == "ok" else
             QMessageBox.warning if res.status == "warning" else QMessageBox.critical)(self, "Archive test", text)

        self.run_operation("Testing archive",
                           lambda progress, cancel: A.test_archive(archive, progress, cancel), done)

    def closeEvent(self, e):
        if self.worker is not None:
            self.worker.cancel()
            self.worker.wait(5000)
        try:
            S.save(self.settings)
        except OSError:
            pass
        super().closeEvent(e)
