"""WW World entry point (source runs and the PyInstaller 'WW World.exe')."""
from __future__ import annotations

import json
import logging
import logging.handlers
import os
import sys
import tempfile
import traceback


def _fix_streams():
    # windowed (no console) builds have sys.stdout/stderr = None
    for name in ("stdout", "stderr"):
        if getattr(sys, name) is None:
            setattr(sys, name, open(os.devnull, "w"))


def _fatal(title: str, text: str):
    try:
        if sys.platform == "win32":
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, text[:2000], title, 0x10)
        else:
            sys.__stderr__.write(f"{title}: {text}\n")
    except Exception:
        pass


def _setup_logging():
    from ww_world import paths
    try:
        os.makedirs(paths.log_dir(), exist_ok=True)
        h = logging.handlers.RotatingFileHandler(os.path.join(paths.log_dir(), "ww-world.log"),
                                                 maxBytes=512_000, backupCount=2, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        lg = logging.getLogger("wwworld")
        lg.setLevel(logging.INFO)
        lg.addHandler(h)
    except OSError:
        pass


def _emit(text: str, report: str):
    if report:
        with open(report, "w", encoding="utf-8") as f:
            f.write(text + "\n")
    else:
        print(text)


def _selftest(report: str) -> int:
    from ww_world import __version__, archive as A, paths, shell_integration  # noqa: F401
    checks: dict[str, str] = {"version": __version__, "frozen": str(paths.is_frozen())}
    ok = True

    def check(name, fn):
        nonlocal ok
        try:
            checks[name] = fn() or "ok"
        except Exception as exc:
            ok = False
            checks[name] = f"FAIL: {type(exc).__name__}: {exc}"

    for res in ("assets/ww_world.ico", "assets/ww_world_archive.ico"):
        check(f"resource {res}", lambda r=res: "ok" if os.path.isfile(paths.resource_path(r)) else (_ for _ in ()).throw(FileNotFoundError(r)))

    def roundtrip():
        with tempfile.TemporaryDirectory() as d:
            src = os.path.join(d, "src")
            os.makedirs(os.path.join(src, "sub dir"))
            for n, c in (("a.txt", "same"), ("sub dir/b.txt", "same"), ("c.bin", "x" * 5000)):
                with open(os.path.join(src, n), "w") as f:
                    f.write(c)
            arc = os.path.join(d, "t.world")
            A.compress(src, arc, "Fast")
            t = A.test_archive(arc)
            if t.status != "ok":
                raise RuntimeError(t.summary())
            A.extract(arc, os.path.join(d, "out"))
            return "compress/test/extract ok"
    check("engine roundtrip", roundtrip)

    def qt():
        from PyQt6.QtWidgets import QApplication
        from ww_world.gui.main_window import WWWorldMainWindow
        app = QApplication.instance() or QApplication([])
        w = WWWorldMainWindow()          # constructed, never shown
        w.deleteLater()
        return "main window constructed"
    check("qt gui", qt)
    checks["result"] = "PASS" if ok else "FAIL"
    _emit(json.dumps(checks, indent=2), report)
    return 0 if ok else 1


def _cli(req) -> int | None:
    from ww_world import __version__, archive as A, paths, shell_integration as SH
    a = req.action
    try:
        if a == "version":
            _emit(f"WW World {__version__}", req.report)
            return 0
        if a == "selftest":
            return _selftest(req.report)
        if a == "test-archive":
            r = A.test_archive(req.paths[0])
            _emit(r.summary(), req.report)
            return {"ok": 0, "warning": 3, "failed": 1}[r.status]
        if a == "extract":
            dest = req.dest or os.path.join(paths.default_outputs_dir(), "extracted")
            r = A.extract(req.paths[0], dest)
            _emit(f"Extracted {r.files_written} file(s) to {r.dest} (SHA-256 verified)", req.report)
            return 0
        if a in ("register", "unregister", "repair", "shell-status"):
            exe = paths.app_executable()
            if a != "unregister" and a != "shell-status" and not exe:
                _emit("Run this from the installed WW World.exe.", req.report)
                return 2
            icon = None
            if exe:
                for c in (os.path.join(os.path.dirname(exe), "icons", "ww_world_archive.ico"),
                          paths.resource_path("assets/ww_world_archive.ico")):
                    if os.path.isfile(c):
                        icon = c
                        break
            if a == "register":
                if req.context:
                    SH.register_context_menu(exe)
                if req.assoc:
                    SH.register_association(exe, icon)
                _emit("Explorer integration registered.", req.report)
            elif a == "unregister":
                SH.unregister_all()
                _emit("WW World registrations removed.", req.report)
            elif a == "repair":
                _emit(f"Repaired: {SH.repair(exe, icon)}", req.report)
            else:
                _emit(json.dumps(SH.status(exe), indent=2), req.report)
            return 0
    except A.DestinationConflictError as exc:
        _emit(f"Destination already contains: {', '.join(exc.conflicts[:5])}", req.report)
        return 4
    except Exception as exc:
        _emit(f"ERROR: {exc}", req.report)
        return 1
    return None


def main(argv: list[str] | None = None) -> int:
    _fix_streams()
    argv = sys.argv[1:] if argv is None else argv
    try:
        from ww_world.launch import parse_args
        req = parse_args(argv)
    except SystemExit as e:
        return int(e.code or 0)
    _setup_logging()
    code = _cli(req)
    if code is not None:
        return code

    from PyQt6.QtWidgets import QApplication, QMessageBox
    from ww_world import APP_NAME
    from ww_world.instance import InstanceServer, instance_name, send_request, send_with_retry
    app = QApplication(sys.argv[:1])
    app.setApplicationName(APP_NAME)
    app.setQuitOnLastWindowClosed(True)

    def hook(et, ev, tb):
        logging.getLogger("wwworld").error("unhandled", exc_info=(et, ev, tb))
        try:
            QMessageBox.critical(None, APP_NAME, f"Unexpected error:\n{ev}\n\nDetails were written to the log.")
        except Exception:
            _fatal(APP_NAME, "".join(traceback.format_exception(et, ev, tb)))
    sys.excepthook = hook

    name = instance_name()
    payload = {"action": req.action, "paths": [os.path.abspath(p) for p in req.paths], "hub": req.hub}
    server = InstanceServer(name)
    if send_request(name, payload):
        return 0                                   # handed over to the running window
    if not server.listen():
        if send_with_retry(name, payload):
            return 0
        server = None                              # run standalone

    from ww_world.gui.main_window import WWWorldMainWindow
    win = WWWorldMainWindow(req)
    if server:
        def on_req(d):
            if d.get("action") == "open" and d.get("paths"):
                win.handle_external_open([str(p) for p in d["paths"]])
            else:
                win._flush_open()
        server.request_received.connect(on_req)
    win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
