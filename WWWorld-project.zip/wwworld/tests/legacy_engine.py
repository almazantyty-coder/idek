# Unmodified WW_WORLD_ENGINE_CODE extracted from the original gemini-code-1791831396096.py;
# used only to create genuine v2.0 archives for backward-compatibility tests.
import os
import lzma
import json
import zipfile
import shutil
import hashlib
import tempfile

class WWWorldEngine:
    @staticmethod
    def calculate_sha256(filepath):
        sha256_hash = hashlib.sha256()
        with open(filepath, "rb") as f:
            for byte_block in iter(lambda: f.read(65536), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    @staticmethod
    def compress(input_path, output_path, is_folder, profile="Maximum", progress_callback=None):
        temp_zip_path = None
        try:
            if progress_callback: progress_callback("Analyzing assets & deduplicating...", 5)
            target_to_compress = input_path
            manifest = {
                "version": "2.0",
                "is_folder": is_folder,
                "original_name": os.path.basename(input_path),
                "files": {},
                "deduplicated_links": {}
            }

            if is_folder:
                if progress_callback: progress_callback("Scanning directory tree...", 15)
                fd, temp_zip_path = tempfile.mkstemp(suffix='.zip')
                os.close(fd)

                files_list = []
                for root, _, files in os.walk(input_path):
                    for file in files:
                        files_list.append(os.path.join(root, file))

                hash_registry = {}
                total_files = len(files_list)
                processed = 0

                with zipfile.ZipFile(temp_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for fpath in files_list:
                        arcname = os.path.relpath(fpath, input_path)
                        f_hash = WWWorldEngine.calculate_sha256(fpath)

                        if f_hash in hash_registry:
                            manifest["deduplicated_links"][arcname] = hash_registry[f_hash]
                            processed += 1
                            continue

                        hash_registry[f_hash] = arcname
                        zipf.write(fpath, arcname)
                        manifest["files"][arcname] = f_hash
                        processed += 1
                        if progress_callback and processed % 25 == 0:
                            pct = 15 + int((processed / max(total_files, 1)) * 30)
                            progress_callback(f"Adding asset: {arcname}", pct)

                target_to_compress = temp_zip_path
            else:
                f_hash = WWWorldEngine.calculate_sha256(input_path)
                manifest["files"][os.path.basename(input_path)] = f_hash

            orig_size = os.path.getsize(target_to_compress)
            if progress_callback: progress_callback("Writing .world container payload...", 50)

            preset = 9 | lzma.PRESET_EXTREME if profile in ["Maximum", "Extreme Search"] else 6
            dict_size = 128 * 1024 * 1024 if profile == "Extreme Search" else 64 * 1024 * 1024

            manifest_bytes = json.dumps(manifest).encode('utf-8')
            manifest_len = len(manifest_bytes)
            filters = [{'id': lzma.FILTER_LZMA2, 'preset': preset, 'dict_size': dict_size}]

            with open(output_path, 'wb') as f_out:
                f_out.write(manifest_len.to_bytes(4, byteorder='big'))
                f_out.write(manifest_bytes)

                with open(target_to_compress, 'rb') as f_in:
                    with lzma.open(f_out, 'wb', filters=filters) as f_lzma:
                        processed_bytes = 0
                        chunk_size = 4 * 1024 * 1024
                        while chunk := f_in.read(chunk_size):
                            f_lzma.write(chunk)
                            processed_bytes += len(chunk)
                            if progress_callback:
                                pct = 50 + int((processed_bytes / max(orig_size, 1)) * 45)
                                progress_callback("Crushing archive data...", pct)

            if progress_callback: progress_callback("Compression completed successfully.", 100)
            return True, None
        except Exception as e:
            return False, str(e)
        finally:
            if temp_zip_path and os.path.exists(temp_zip_path):
                try: os.remove(temp_zip_path)
                except: pass

    @staticmethod
    def read_manifest(input_path):
        try:
            with open(input_path, 'rb') as f_in:
                len_bytes = f_in.read(4)
                if len(len_bytes) < 4:
                    return None
                manifest_len = int.from_bytes(len_bytes, byteorder='big')
                manifest = json.loads(f_in.read(manifest_len).decode('utf-8'))
                return manifest
        except Exception:
            return None

    @staticmethod
    def decompress(input_path, output_dir, progress_callback=None):
        temp_extract_dir = None
        try:
            if progress_callback: progress_callback("Reading archive manifest...", 10)
            with open(input_path, 'rb') as f_in:
                len_bytes = f_in.read(4)
                if len(len_bytes) < 4:
                    raise ValueError("Invalid archive header.")
                manifest_len = int.from_bytes(len_bytes, byteorder='big')
                manifest = json.loads(f_in.read(manifest_len).decode('utf-8'))

                temp_extract_dir = tempfile.mkdtemp()
                temp_payload = os.path.join(temp_extract_dir, "payload.tmp")

                orig_size = os.path.getsize(input_path)
                with open(temp_payload, 'wb') as f_out:
                    with lzma.open(f_in, 'rb') as f_lzma:
                        processed = 0
                        chunk_size = 4 * 1024 * 1024
                        while chunk := f_lzma.read(chunk_size):
                            f_out.write(chunk)
                            processed += len(chunk)
                            if progress_callback:
                                pct = 20 + int((processed / max(orig_size, 1)) * 50)
                                progress_callback("Unpacking payload...", pct)

            is_folder = manifest.get("is_folder", True)
            dedup_links = manifest.get("deduplicated_links", {})
            verification_passed = True

            if is_folder and zipfile.is_zipfile(temp_payload):
                if progress_callback: progress_callback("Extracting and verifying integrity...", 80)
                os.makedirs(output_dir, exist_ok=True)

                with zipfile.ZipFile(temp_payload, 'r') as zip_ref:
                    for member in zip_ref.namelist():
                        target_path = os.path.normpath(os.path.join(output_dir, member))
                        if not target_path.startswith(os.path.abspath(output_dir)):
                            raise PermissionError(f"Security violation: Path traversal detected ({member})")
                        zip_ref.extract(member, output_dir)

                for dup_path, orig_path in dedup_links.items():
                    target_dup = os.path.normpath(os.path.join(output_dir, dup_path))
                    source_orig = os.path.normpath(os.path.join(output_dir, orig_path))
                    os.makedirs(os.path.dirname(target_dup), exist_ok=True)
                    if os.path.exists(source_orig):
                        shutil.copy2(source_orig, target_dup)

                for member, expected_hash in manifest.get("files", {}).items():
                    f_path = os.path.join(output_dir, member)
                    if os.path.exists(f_path):
                        if WWWorldEngine.calculate_sha256(f_path) != expected_hash:
                            verification_passed = False
            else:
                if os.path.exists(output_dir):
                    os.remove(output_dir)
                shutil.move(temp_payload, output_dir)

            if progress_callback: progress_callback("Restoration completed successfully.", 100)
            return True, verification_passed, None
        except Exception as e:
            return False, False, str(e)
        finally:
            if temp_extract_dir and os.path.exists(temp_extract_dir):
                try: shutil.rmtree(temp_extract_dir)
                except: pass
