# WW World archive format (`.world`)

## Container (identical for 2.x and 3.x)

| Offset | Size | Content |
|---|---|---|
| 0 | 4 | manifest length *N*, big-endian unsigned |
| 4 | N | UTF-8 JSON manifest |
| 4+N | … | one xz (LZMA2) stream = the payload |

There is no magic number (kept for compatibility with archives made by the original app), so
validation is: sane length (1 … 64 MiB, and ≤ file size) → valid JSON → valid manifest → valid xz stream.

## Payload
* `is_folder = false` — the raw bytes of the single file.
* `is_folder = true` — a **ZIP** holding one member per *stored* file. 2.x wrote it `DEFLATED`;
  3.x writes it `STORED` and streams it straight into the xz stream (solid compression, no temp file,
  better ratio than deflate-inside-LZMA).

## Manifest 2.x (legacy, read-only)
```json
{"version":"2.0","is_folder":true,"original_name":"proj",
 "files":{"a/b.txt":"<sha256>"}, "deduplicated_links":{"copy.txt":"a/b.txt"}}
```
Keys use the OS separator of the creator (Windows: backslashes) — the reader normalises `\` to `/`.
No sizes, timestamps or empty folders are recorded. Duplicates are not in the ZIP; they are restored from
the original they link to.

## Manifest 3.0 (written by this version)
```json
{"version":"3.0","generator":"WW World 3.0.0","created":1760000000,
 "is_folder":true,"original_name":"proj",
 "entries":[{"type":"dir","path":"a","mtime":1}, 
            {"type":"file","path":"a/b.txt","size":12,"mtime":1,"sha256":"…"},
            {"type":"file","path":"copy.txt","size":12,"mtime":1,"sha256":"…","dup_of":"a/b.txt"}],
 "files":{…}, "deduplicated_links":{…}}
```
`files`/`deduplicated_links` are still written so the *original* engine can read new archives
(verified by a test); 3.x readers use only `entries`. Paths are `/`-separated, relative, normalised.
Single-file archives have exactly one `file` entry. A folder archive of one folder stores paths relative to that
folder (`original_name` = folder name); several inputs store each top-level item by name.

## Validation performed on every open
Version (2.x/3.x only) · types · `is_folder` consistency · SHA-256 syntax · every path (no absolute, UNC,
drive, `..`, `.`, empty, control chars, `:`, reserved device names, trailing dot/space, > 255 chars) ·
case-insensitive collisions · file-below-file conflicts · `dup_of` must reference a stored file with identical
size/hash · entry count (default 1 000 000) · declared total size (default 16 TiB).

## Limits (`archive.Limits`, all configurable in code)
manifest 64 MiB · 1 000 000 entries · xz memory 2 GiB · decompressed payload ≤ declared size (+ ZIP header
allowance) for 3.x, ≤ 256 GiB for 2.x (sizes undeclared).

## Integrity test (`test_archive`)
Header → manifest → **entire** xz stream (CRC64 checked by xz) → ZIP structure → payload names equal manifest
names (no missing, no extra) → member sizes → SHA-256 of every stored file → every duplicate resolves to a verified
original → trailing bytes after the stream produce a *warning*. Status is `ok` only if every file was hash-verified.

## Random access
xz is a single solid stream, so there is no random access into the payload. **Browsing uses only the manifest
(no decompression)**. Extracting a subset still decompresses the whole stream once (to a scratch file inside the
destination's private staging folder) but writes only the selected files.

## Memory
Dictionary = min(profile maximum, next power of two ≥ stored bytes). Compression needs ≈ 10× the dictionary
(Maximum 64 MiB ≈ 0.7 GiB, Extreme Search 128 MiB ≈ 1.4 GiB); decompression ≈ 1× dictionary. Data is streamed in
1 MiB chunks; large archives are never read into RAM.
