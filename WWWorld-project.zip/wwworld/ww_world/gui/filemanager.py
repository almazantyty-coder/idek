"""WW World File Manager: browse folders, selections and .world archives."""
from __future__ import annotations

import os
import time
from datetime import datetime

from PyQt6.QtCore import QFileInfo, Qt, QUrl
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import (QAbstractItemView, QFileIconProvider, QHBoxLayout, QLabel, QLineEdit,
                             QMessageBox, QPlainTextEdit, QPushButton, QStyle, QTreeWidget,
                             QTreeWidgetItem, QVBoxLayout, QWidget, QFileDialog)

from .. import archive as A
from ..launch import classify

RISKY = {".exe", ".bat", ".cmd", ".com", ".msi", ".ps1", ".vbs", ".vbe", ".js", ".jse", ".wsf",
         ".scr", ".lnk", ".reg", ".jar", ".hta", ".cpl", ".msc", ".dll"}


class _Item(QTreeWidgetItem):
    """Sortable row: folders first, numeric size/date ordering."""

    def __lt__(self, other):
        col = self.treeWidget().sortColumn()
        a, b = self.data(col, Qt.ItemDataRole.UserRole + 1), other.data(col, Qt.ItemDataRole.UserRole + 1)
        da, db = self.data(0, Qt.ItemDataRole.UserRole + 2), other.data(0, Qt.ItemDataRole.UserRole + 2)
        if da != db:                                  # directories first regardless of order
            asc = self.treeWidget().header().sortIndicatorOrder() == Qt.SortOrder.AscendingOrder
            return da > db if asc else da < db
        try:
            return (a if a is not None else -1) < (b if b is not None else -1)
        except TypeError:
            return str(a) < str(b)


def fmt_time(ts) -> str:
    try:
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M") if ts else ""
    except (OSError, OverflowError, ValueError):
        return ""


class FileManagerWidget(QWidget):
    """Locations: ('fs', dir) | ('arc', archive, inner) | ('sel', (paths...))."""

    def __init__(self, host):
        super().__init__()
        self.host = host
        self.loc: tuple | None = None
        self.back_stack: list[tuple] = []
        self.fwd_stack: list[tuple] = []
        self.info: A.ArchiveInfo | None = None
        self.icons = QFileIconProvider()
        self._build()
        self._update_actions()

    # ------------------------------------------------------------------ UI
    def _build(self):
        lay = QVBoxLayout(self)
        bar = QHBoxLayout()
        self.btn_back = self._btn("◀ Back", self.go_back, bar, "secondary")
        self.btn_fwd = self._btn("Forward ▶", self.go_forward, bar, "secondary")
        self.btn_up = self._btn("▲ Up", self.go_up, bar, "secondary")
        self.btn_refresh = self._btn("⟳ Refresh", self.refresh, bar, "secondary")
        self.address = QLineEdit()
        self.address.setPlaceholderText("Folder path or .world archive")
        self.address.returnPressed.connect(self._address_entered)
        bar.addWidget(self.address, 1)
        lay.addLayout(bar)

        bar2 = QHBoxLayout()
        self.btn_open = self._btn("Open", self.open_selected, bar2)
        self.btn_create = self._btn("Create .world Archive…", self.create_archive, bar2)
        self.btn_extract = self._btn("Extract…", self.extract_selected, bar2)
        self.btn_test = self._btn("Test Archive", self.test_archive, bar2)
        self.btn_props = self._btn("Properties", self.show_properties, bar2, "secondary")
        self.btn_openarc = self._btn("Open Archive…", self.browse_archive, bar2, "secondary")
        bar2.addStretch(1)
        lay.addLayout(bar2)

        self.tree = QTreeWidget()
        self.tree.setAlternatingRowColors(True)
        self.tree.setRootIsDecorated(False)
        self.tree.setSortingEnabled(True)
        self.tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tree.itemDoubleClicked.connect(lambda *_: self.open_selected())
        self.tree.itemSelectionChanged.connect(self._selection_changed)
        lay.addWidget(self.tree, 1)

        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setMaximumHeight(120)
        lay.addWidget(self.details)
        row = QHBoxLayout()
        self.status = QLabel("")
        self.status.setObjectName("muted")
        self.btn_hash = self._btn("Compute SHA-256", self.compute_hash, row, "secondary")
        row.insertWidget(0, self.status, 1)
        lay.addLayout(row)

    def _btn(self, text, slot, layout, name=None):
        b = QPushButton(text)
        if name:
            b.setObjectName(name)
        b.clicked.connect(lambda _=False: slot())
        layout.addWidget(b)
        return b

    # ------------------------------------------------------------------ routing
    def open_paths(self, paths: list[str]) -> None:
        """Entry point for Explorer / drag-drop launches."""
        paths = [os.path.abspath(p) for p in paths]
        bad = [p for p in paths if classify(p) == "missing"]
        if bad:
            QMessageBox.warning(self, "WW World", "These items do not exist or are not accessible:\n\n" + "\n".join(bad))
        paths = [p for p in paths if p not in bad]
        if not paths:
            return
        if len(paths) > 1:
            self.navigate(("sel", tuple(paths)))
            return
        p = paths[0]
        kind = classify(p)
        if kind == "folder":
            self.navigate(("fs", p))
        elif kind == "archive":
            self.navigate(("arc", p, ""))
        else:                                    # ordinary file: show its folder with the file selected
            self.navigate(("fs", os.path.dirname(p)))
            for i in range(self.tree.topLevelItemCount()):
                it = self.tree.topLevelItem(i)
                if it.data(0, Qt.ItemDataRole.UserRole) == p:
                    self.tree.setCurrentItem(it)
                    it.setSelected(True)
                    self.tree.scrollToItem(it)
                    break

    def navigate(self, loc: tuple, push: bool = True) -> bool:
        if loc[0] == "arc":
            if not self._load_archive(loc[1]):
                return False
        if loc[0] == "fs" and not os.path.isdir(loc[1]):
            QMessageBox.warning(self, "WW World", f"Folder not found or not accessible:\n{loc[1]}")
            return False
        if push and self.loc is not None and self.loc != loc:
            self.back_stack.append(self.loc)
            self.fwd_stack.clear()
        self.loc = loc
        self.refresh()
        return True

    def _load_archive(self, path: str) -> bool:
        if self.info and self.info.path == path and os.path.getmtime(path) == getattr(self, "_arc_mtime", None):
            return True
        try:
            self.info = A.read_archive(path)
            self._arc_mtime = os.path.getmtime(path)
        except (A.ArchiveError, OSError) as exc:
            QMessageBox.critical(self, "Cannot open archive", f"{os.path.basename(path)}\n\n{exc}")
            self.host.log(f"Failed to open archive {path}: {exc}")
            return False
        self.host.log(f"Opened archive {path} (format {self.info.manifest.version})")
        return True

    def go_back(self):
        if self.back_stack:
            self.fwd_stack.append(self.loc)
            self.navigate(self.back_stack.pop(), push=False)

    def go_forward(self):
        if self.fwd_stack:
            self.back_stack.append(self.loc)
            self.navigate(self.fwd_stack.pop(), push=False)

    def go_up(self):
        if not self.loc:
            return
        k = self.loc[0]
        if k == "fs":
            parent = os.path.dirname(self.loc[1].rstrip("\\/"))
            if parent and parent != self.loc[1]:
                self.navigate(("fs", parent))
        elif k == "arc":
            inner = self.loc[2]
            if inner:
                self.navigate(("arc", self.loc[1], inner.rpartition("/")[0]))
            else:
                self.navigate(("fs", os.path.dirname(self.loc[1])))

    def _address_entered(self):
        t = self.address.text().strip().strip('"')
        if "::" in t:
            arc, _, inner = t.partition("::")
            self.navigate(("arc", arc.strip(), inner.strip().strip("/")))
        elif t:
            self.open_paths([t])

    def browse_archive(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open .world Archive", self.host.outputs_dir(),
                                              "WW World Archives (*.world);;All files (*)")
        if path:
            self.open_paths([path])

    # ------------------------------------------------------------------ listing
    def refresh(self):
        self.tree.setSortingEnabled(False)
        self.tree.clear()
        self.details.clear()
        try:
            if self.loc is None:
                self.tree.setHeaderLabels(["Name", "Type", "Size", "Modified"])
                self.address.clear()
            elif self.loc[0] == "arc":
                self._list_archive()
            elif self.loc[0] == "sel":
                self._list_sel()
            else:
                self._list_fs()
        finally:
            self.tree.setSortingEnabled(True)
            self.tree.sortByColumn(0, Qt.SortOrder.AscendingOrder)
            for c in range(self.tree.columnCount()):
                self.tree.resizeColumnToContents(c)
            self._update_actions()
            self._selection_changed()

    def _row(self, name, typ, size, mtime, is_dir, key, icon, extra=None):
        cols = [name, typ, A.human_size(size) if not is_dir or size is not None else "", fmt_time(mtime)]
        if extra is not None:
            cols.append(extra)
        it = _Item(cols)
        it.setIcon(0, icon)
        it.setData(0, Qt.ItemDataRole.UserRole, key)
        it.setData(0, Qt.ItemDataRole.UserRole + 1, name.casefold())
        it.setData(0, Qt.ItemDataRole.UserRole + 2, 1 if is_dir else 0)
        it.setData(1, Qt.ItemDataRole.UserRole + 1, typ)
        it.setData(2, Qt.ItemDataRole.UserRole + 1, size)
        it.setData(3, Qt.ItemDataRole.UserRole + 1, mtime)
        it.setTextAlignment(2, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.tree.addTopLevelItem(it)

    @staticmethod
    def _type_of(path: str, is_dir: bool) -> str:
        if is_dir:
            return "Folder"
        ext = os.path.splitext(path)[1]
        if ext.lower() == ".world":
            return "WW World Archive"
        return f"{ext[1:].upper()} File" if ext else "File"

    def _fs_entry(self, p: str):
        try:
            st = os.stat(p)
        except OSError:
            return
        is_dir = os.path.isdir(p)
        self._row(os.path.basename(p) or p, self._type_of(p, is_dir), None if is_dir else st.st_size,
                  st.st_mtime, is_dir, p, self.icons.icon(QFileInfo(p)))

    def _list_fs(self):
        self.tree.setHeaderLabels(["Name", "Type", "Size", "Modified"])
        path = self.loc[1]
        self.address.setText(path)
        try:
            names = os.listdir(path)
        except OSError as exc:
            self.status.setText(f"Cannot read folder: {exc}")
            QMessageBox.warning(self, "WW World", f"Cannot read this folder:\n{path}\n\n{exc}")
            return
        for n in names:
            self._fs_entry(os.path.join(path, n))
        self.status.setText(f"{self.tree.topLevelItemCount()} item(s)")

    def _list_sel(self):
        self.tree.setHeaderLabels(["Name", "Type", "Size", "Modified"])
        self.address.setText(f"{len(self.loc[1])} selected items")
        for p in self.loc[1]:
            self._fs_entry(p)
        self.status.setText(f"{self.tree.topLevelItemCount()} selected item(s) from Explorer")

    def _list_archive(self):
        m = self.info.manifest
        inner = self.loc[2]
        self.tree.setHeaderLabels(["Name", "Type", "Size", "Modified", "SHA-256"])
        self.address.setText(f"{self.loc[1]} :: /{inner}")
        style = self.style()
        for e in m.list_dir(inner):
            is_dir = e.kind == "dir"
            self._row(e.name, self._type_of(e.name, is_dir), m.dir_size(e.path) if is_dir else e.size,
                      e.mtime, is_dir, e.path,
                      style.standardIcon(QStyle.StandardPixmap.SP_DirIcon if is_dir else QStyle.StandardPixmap.SP_FileIcon),
                      "" if is_dir else (e.sha256 or ""))
        self.status.setText(f"{self.tree.topLevelItemCount()} item(s) in archive "
                            f"(format {m.version}, {A.human_size(self.info.archive_size)} on disk)")

    # ------------------------------------------------------------------ selection
    def selected_keys(self) -> list[str]:
        return [i.data(0, Qt.ItemDataRole.UserRole) for i in self.tree.selectedItems()]

    def _selection_changed(self):
        keys = self.selected_keys()
        if not keys:
            self.details.setPlainText(self._context_summary())
        elif len(keys) > 1:
            self.details.setPlainText(f"{len(keys)} items selected.")
        else:
            self.details.setPlainText(self._describe(keys[0]))
        self._update_actions()

    def _context_summary(self) -> str:
        if self.loc and self.loc[0] == "arc":
            m = self.info.manifest
            return (f"Archive: {self.loc[1]}\nFormat version: {m.version}\nOriginal name: {m.original_name}\n"
                    f"Files: {len(m.files)}  Folders: {len(m.entries) - len(m.files)}\n"
                    f"Uncompressed size: {A.human_size(m.total_size)}   On disk: {A.human_size(self.info.archive_size)}\n"
                    f"Stored without duplicates: {len(m.stored_files)} file(s)")
        return ""

    def _describe(self, key: str) -> str:
        if self.loc and self.loc[0] == "arc":
            e = self.info.manifest.entries.get(key)
            if e is None:
                return f"Folder: {key}"
            lines = [f"Path in archive: {e.path}", f"Type: {e.kind}", f"Size: {A.human_size(e.size)}",
                     f"Modified: {fmt_time(e.mtime) or '—'}"]
            if e.sha256:
                lines.append(f"SHA-256: {e.sha256}")
            if e.dup_of:
                lines.append(f"Identical to: {e.dup_of} (stored once)")
            return "\n".join(lines)
        try:
            st = os.stat(key)
        except OSError as exc:
            return f"{key}\nCannot read: {exc}"
        kind = "Folder" if os.path.isdir(key) else self._type_of(key, False)
        return (f"Path: {key}\nType: {kind}\n"
                f"Size: {A.human_size(st.st_size) if os.path.isfile(key) else '—'}\n"
                f"Modified: {fmt_time(st.st_mtime)}\nCreated: {fmt_time(st.st_ctime)}")

    def _update_actions(self):
        mode = self.loc[0] if self.loc else None
        keys = self.selected_keys() if self.loc else []
        has_arc_sel = mode == "fs" and any(k.lower().endswith(".world") for k in keys if os.path.isfile(k))
        self.btn_back.setEnabled(bool(self.back_stack))
        self.btn_fwd.setEnabled(bool(self.fwd_stack))
        self.btn_up.setEnabled(mode in ("fs", "arc"))
        self.btn_refresh.setEnabled(self.loc is not None)
        self.btn_open.setEnabled(bool(keys))
        self.btn_create.setEnabled(mode in ("fs", "sel"))
        self.btn_extract.setEnabled(mode == "arc" or has_arc_sel)
        self.btn_test.setEnabled(mode == "arc" or has_arc_sel)
        self.btn_props.setEnabled(self.loc is not None)
        self.btn_hash.setEnabled(mode in ("fs", "sel") and len(keys) == 1 and os.path.isfile(keys[0]))

    # ------------------------------------------------------------------ actions
    def open_selected(self):
        keys = self.selected_keys()
        if not keys or self.loc is None:
            return
        k = keys[0]
        if self.loc[0] == "arc":
            e = self.info.manifest.entries.get(k)
            if e is None or e.kind == "dir":
                self.navigate(("arc", self.loc[1], k))
            else:
                QMessageBox.information(self, "WW World",
                                        "Files inside an archive are not opened directly.\n"
                                        "Use Extract… to restore them, then open the extracted copy.")
            return
        if os.path.isdir(k):
            self.navigate(("fs", k))
        elif k.lower().endswith(".world"):
            self.navigate(("arc", k, ""))
        else:
            if os.path.splitext(k)[1].lower() in RISKY:
                r = QMessageBox.warning(self, "Open program/script?",
                                        f"'{os.path.basename(k)}' can run code.\nOpen it with Windows anyway?",
                                        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                        QMessageBox.StandardButton.No)
                if r != QMessageBox.StandardButton.Yes:
                    return
            QDesktopServices.openUrl(QUrl.fromLocalFile(k))

    def _fs_inputs(self) -> list[str]:
        keys = self.selected_keys()
        if keys:
            return keys
        if self.loc and self.loc[0] == "fs":
            return [self.loc[1]]
        return []

    def create_archive(self):
        inputs = self._fs_inputs()
        if inputs:
            self.host.create_archive(inputs)

    def _selected_archive_path(self) -> str | None:
        if self.loc and self.loc[0] == "arc":
            return self.loc[1]
        for k in self.selected_keys():
            if k.lower().endswith(".world") and os.path.isfile(k):
                return k
        return None

    def extract_selected(self):
        arc = self._selected_archive_path()
        if not arc:
            return
        if self.loc[0] == "arc":
            keys = self.selected_keys()
            self.host.extract_archive(arc, members=keys or None, strip=self.loc[2] if keys else "")
        else:
            self.host.extract_archive(arc)

    def test_archive(self):
        arc = self._selected_archive_path()
        if arc:
            self.host.test_archive(arc)

    def show_properties(self):
        keys = self.selected_keys()
        text = self._describe(keys[0]) if len(keys) == 1 else (self._context_summary() or self.address.text())
        QMessageBox.information(self, "Properties", text or "Nothing to show.")

    def compute_hash(self):
        keys = self.selected_keys()
        if len(keys) != 1:
            return
        p = keys[0]
        self.host.run_operation(f"Hashing {os.path.basename(p)}", lambda prog, cancel: A.sha256_file(p, cancel),
                                on_ok=lambda h: (self.details.appendPlainText(f"SHA-256: {h}"),
                                                 self.host.log(f"SHA-256 {os.path.basename(p)}: {h}")))
