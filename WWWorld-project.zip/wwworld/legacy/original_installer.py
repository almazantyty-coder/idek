import os
import sys
import shutil
import ctypes
import tkinter as tk
from tkinter import messagebox, ttk

def get_desktop_path():
    try:
        buf = ctypes.create_unicode_buffer(260)
        ctypes.windll.shell32.SHGetFolderPathW(None, 0, None, 0, buf)
        if buf.value and os.path.exists(buf.value):
            return buf.value
    except Exception:
        pass
    return os.path.join(os.path.expanduser("~"), "Desktop")

# ==========================================
# EMBEDDED APPLICATION PAYLOADS
# ==========================================

WW_WORLD_ENGINE_CODE = r'''import os
import lzma
import json
import zipfile
import shutil
import hashlib
import tempfile

class WWWorldEngine:
    @staticmethod
    def calculate_sha256(filepath):
        sha256_hash = hashlib.sha256()
        with open(filepath, "rb") as f:
            for byte_block in iter(lambda: f.read(65536), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    @staticmethod
    def compress(input_path, output_path, is_folder, profile="Maximum", progress_callback=None):
        temp_zip_path = None
        try:
            if progress_callback: progress_callback("Analyzing assets & deduplicating...", 5)
            target_to_compress = input_path
            manifest = {
                "version": "2.0",
                "is_folder": is_folder,
                "original_name": os.path.basename(input_path),
                "files": {},
                "deduplicated_links": {}
            }

            if is_folder:
                if progress_callback: progress_callback("Scanning directory tree...", 15)
                fd, temp_zip_path = tempfile.mkstemp(suffix='.zip')
                os.close(fd)

                files_list = []
                for root, _, files in os.walk(input_path):
                    for file in files:
                        files_list.append(os.path.join(root, file))

                hash_registry = {}
                total_files = len(files_list)
                processed = 0

                with zipfile.ZipFile(temp_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for fpath in files_list:
                        arcname = os.path.relpath(fpath, input_path)
                        f_hash = WWWorldEngine.calculate_sha256(fpath)

                        if f_hash in hash_registry:
                            manifest["deduplicated_links"][arcname] = hash_registry[f_hash]
                            processed += 1
                            continue

                        hash_registry[f_hash] = arcname
                        zipf.write(fpath, arcname)
                        manifest["files"][arcname] = f_hash
                        processed += 1
                        if progress_callback and processed % 25 == 0:
                            pct = 15 + int((processed / max(total_files, 1)) * 30)
                            progress_callback(f"Adding asset: {arcname}", pct)

                target_to_compress = temp_zip_path
            else:
                f_hash = WWWorldEngine.calculate_sha256(input_path)
                manifest["files"][os.path.basename(input_path)] = f_hash

            orig_size = os.path.getsize(target_to_compress)
            if progress_callback: progress_callback("Writing .world container payload...", 50)

            preset = 9 | lzma.PRESET_EXTREME if profile in ["Maximum", "Extreme Search"] else 6
            dict_size = 128 * 1024 * 1024 if profile == "Extreme Search" else 64 * 1024 * 1024

            manifest_bytes = json.dumps(manifest).encode('utf-8')
            manifest_len = len(manifest_bytes)
            filters = [{'id': lzma.FILTER_LZMA2, 'preset': preset, 'dict_size': dict_size}]

            with open(output_path, 'wb') as f_out:
                f_out.write(manifest_len.to_bytes(4, byteorder='big'))
                f_out.write(manifest_bytes)

                with open(target_to_compress, 'rb') as f_in:
                    with lzma.open(f_out, 'wb', filters=filters) as f_lzma:
                        processed_bytes = 0
                        chunk_size = 4 * 1024 * 1024
                        while chunk := f_in.read(chunk_size):
                            f_lzma.write(chunk)
                            processed_bytes += len(chunk)
                            if progress_callback:
                                pct = 50 + int((processed_bytes / max(orig_size, 1)) * 45)
                                progress_callback("Crushing archive data...", pct)

            if progress_callback: progress_callback("Compression completed successfully.", 100)
            return True, None
        except Exception as e:
            return False, str(e)
        finally:
            if temp_zip_path and os.path.exists(temp_zip_path):
                try: os.remove(temp_zip_path)
                except: pass

    @staticmethod
    def read_manifest(input_path):
        try:
            with open(input_path, 'rb') as f_in:
                len_bytes = f_in.read(4)
                if len(len_bytes) < 4:
                    return None
                manifest_len = int.from_bytes(len_bytes, byteorder='big')
                manifest = json.loads(f_in.read(manifest_len).decode('utf-8'))
                return manifest
        except Exception:
            return None

    @staticmethod
    def decompress(input_path, output_dir, progress_callback=None):
        temp_extract_dir = None
        try:
            if progress_callback: progress_callback("Reading archive manifest...", 10)
            with open(input_path, 'rb') as f_in:
                len_bytes = f_in.read(4)
                if len(len_bytes) < 4:
                    raise ValueError("Invalid archive header.")
                manifest_len = int.from_bytes(len_bytes, byteorder='big')
                manifest = json.loads(f_in.read(manifest_len).decode('utf-8'))

                temp_extract_dir = tempfile.mkdtemp()
                temp_payload = os.path.join(temp_extract_dir, "payload.tmp")

                orig_size = os.path.getsize(input_path)
                with open(temp_payload, 'wb') as f_out:
                    with lzma.open(f_in, 'rb') as f_lzma:
                        processed = 0
                        chunk_size = 4 * 1024 * 1024
                        while chunk := f_lzma.read(chunk_size):
                            f_out.write(chunk)
                            processed += len(chunk)
                            if progress_callback:
                                pct = 20 + int((processed / max(orig_size, 1)) * 50)
                                progress_callback("Unpacking payload...", pct)

            is_folder = manifest.get("is_folder", True)
            dedup_links = manifest.get("deduplicated_links", {})
            verification_passed = True

            if is_folder and zipfile.is_zipfile(temp_payload):
                if progress_callback: progress_callback("Extracting and verifying integrity...", 80)
                os.makedirs(output_dir, exist_ok=True)

                with zipfile.ZipFile(temp_payload, 'r') as zip_ref:
                    for member in zip_ref.namelist():
                        target_path = os.path.normpath(os.path.join(output_dir, member))
                        if not target_path.startswith(os.path.abspath(output_dir)):
                            raise PermissionError(f"Security violation: Path traversal detected ({member})")
                        zip_ref.extract(member, output_dir)

                for dup_path, orig_path in dedup_links.items():
                    target_dup = os.path.normpath(os.path.join(output_dir, dup_path))
                    source_orig = os.path.normpath(os.path.join(output_dir, orig_path))
                    os.makedirs(os.path.dirname(target_dup), exist_ok=True)
                    if os.path.exists(source_orig):
                        shutil.copy2(source_orig, target_dup)

                for member, expected_hash in manifest.get("files", {}).items():
                    f_path = os.path.join(output_dir, member)
                    if os.path.exists(f_path):
                        if WWWorldEngine.calculate_sha256(f_path) != expected_hash:
                            verification_passed = False
            else:
                if os.path.exists(output_dir):
                    os.remove(output_dir)
                shutil.move(temp_payload, output_dir)

            if progress_callback: progress_callback("Restoration completed successfully.", 100)
            return True, verification_passed, None
        except Exception as e:
            return False, False, str(e)
        finally:
            if temp_extract_dir and os.path.exists(temp_extract_dir):
                try: shutil.rmtree(temp_extract_dir)
                except: pass
'''

MAIN_APP_CODE = r'''import sys
import os
import ctypes
import json
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QLabel, QVBoxLayout, QHBoxLayout,
    QWidget, QFileDialog, QMessageBox, QProgressBar, QFrame,
    QPushButton, QTextEdit, QComboBox, QSplitter,
    QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView, QTreeWidget, QTreeWidgetItem
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal

from ww_world_engine import WWWorldEngine

def get_desktop_path():
    try:
        buf = ctypes.create_unicode_buffer(260)
        ctypes.windll.shell32.SHGetFolderPathW(None, 0, None, 0, buf)
        if buf.value and os.path.exists(buf.value):
            return buf.value
    except Exception:
        pass
    return os.path.join(os.path.expanduser("~"), "Desktop")

BASE_WORKSPACE = os.path.join(get_desktop_path(), "WWWorld")
OUTPUTS_DIR = os.path.join(BASE_WORKSPACE, "WW World Outputs")
REPORTS_DIR = os.path.join(BASE_WORKSPACE, "WW World Reports")
os.makedirs(OUTPUTS_DIR, exist_ok=True)
os.makedirs(REPORTS_DIR, exist_ok=True)

class WorkerThread(QThread):
    progress = pyqtSignal(str, int)
    finished = pyqtSignal(bool, str)

    def __init__(self, input_path, output_path, is_folder, compress, profile):
        super().__init__()
        self.input_path = input_path
        self.output_path = output_path
        self.is_folder = is_folder
        self.compress = compress
        self.profile = profile

    def run(self):
        if self.compress:
            success, err = WWWorldEngine.compress(
                self.input_path, self.output_path, self.is_folder, self.profile,
                progress_callback=lambda msg, pct: self.progress.emit(msg, pct)
            )
            self.finished.emit(success, err if err else "Compression successful")
        else:
            success, verified, err = WWWorldEngine.decompress(
                self.input_path, self.output_path,
                progress_callback=lambda msg, pct: self.progress.emit(msg, pct)
            )
            msg = "Restoration verified successfully." if verified else "Restored with hash warnings."
            self.finished.emit(success, err if err else msg)

class WWWorldMainWindow(QMainWindow):
    def __init__(self, target_path=None):
        super().__init__()
        self.setWindowTitle("WW World - Professional Archiving Suite")
        self.setGeometry(100, 100, 1150, 680)
        self.setStyleSheet("""
            QMainWindow { background-color: #0F172A; color: #F8FAFC; }
            QLabel { color: #E2E8F0; font-family: 'Segoe UI'; }
            QPushButton { background-color: #2563EB; color: white; border-radius: 6px; padding: 8px 16px; font-weight: bold; font-family: 'Segoe UI'; }
            QPushButton:hover { background-color: #1D4ED8; }
            QTabWidget::pane { border: 1px solid #334155; background: #1E293B; border-radius: 6px; }
            QTabBar::tab { background: #0F172A; color: #94A3B8; padding: 10px 20px; margin-right: 2px; }
            QTabBar::tab:selected { background: #2563EB; color: #FFFFFF; font-weight: bold; }
        """)

        self.init_ui()

        if target_path and os.path.exists(target_path):
            if target_path.endswith('.world'):
                self.tabs.setCurrentIndex(1)
                self.load_archive_in_manager(target_path)
            else:
                self.tabs.setCurrentIndex(0)
                self.process_path(target_path)

    def init_ui(self):
        self.tabs = QTabWidget()

        hub_widget = QWidget()
        hub_layout = QHBoxLayout(hub_widget)

        left_panel = QVBoxLayout()
        title_label = QLabel("WW World Archive Hub")
        title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #38BDF8;")

        self.profile_combo = QComboBox()
        self.profile_combo.addItems(["Fast", "Balanced", "Maximum", "Extreme Search"])
        self.profile_combo.setStyleSheet("background: #334155; color: white; padding: 6px; border-radius: 4px;")

        self.drop_frame = QFrame()
        self.drop_frame.setAcceptDrops(True)
        self.drop_frame.setCursor(Qt.CursorShape.PointingHandCursor)
        self.drop_frame.setStyleSheet("border: 2px dashed #22C55E; border-radius: 12px; background: #1E293B;")
        drop_layout = QVBoxLayout(self.drop_frame)
        self.drop_label = QLabel("Click or Drag & Drop File / Folder / .world Archive Here")
        self.drop_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        drop_layout.addWidget(self.drop_label)
        self.drop_frame.mousePressEvent = self.on_drop_clicked

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.status_label = QLabel("Ready")

        left_panel.addWidget(title_label)
        left_panel.addWidget(QLabel("Compression Profile:"))
        left_panel.addWidget(self.profile_combo)
        left_panel.addWidget(self.drop_frame)
        left_panel.addWidget(self.status_label)
        left_panel.addWidget(self.progress_bar)

        right_panel = QVBoxLayout()
        right_panel.addWidget(QLabel("Activity & Diagnostic Log"))
        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet("background: #0B0F19; color: #4ADE80; font-family: Consolas; font-size: 11px; border: 1px solid #334155;")
        right_panel.addWidget(self.log_area)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        w1 = QWidget(); w1.setLayout(left_panel)
        w2 = QWidget(); w2.setLayout(right_panel)
        splitter.addWidget(w1); splitter.addWidget(w2)
        splitter.setSizes([450, 650])
        hub_layout.addWidget(splitter)

        fm_widget = QWidget()
        fm_layout = QVBoxLayout(fm_widget)
        
        fm_top_layout = QHBoxLayout()
        self.fm_path_label = QLabel("No archive loaded. Open a .world archive to browse contents.")
        self.fm_path_label.setStyleSheet("color: #38BDF8; font-weight: bold;")
        open_archive_btn = QPushButton("Open Archive...")
        open_archive_btn.clicked.connect(self.browse_and_open_archive)
        fm_top_layout.addWidget(self.fm_path_label)
        fm_top_layout.addStretch()
        fm_top_layout.addWidget(open_archive_btn)

        self.fm_tree = QTreeWidget()
        self.fm_tree.setHeaderLabels(["Name", "Type", "SHA-256 Hash / Info"])
        self.fm_tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.fm_tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.fm_tree.header().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.fm_tree.setStyleSheet("background: #1E293B; color: #F8FAFC; border: 1px solid #334155;")

        fm_bottom_layout = QHBoxLayout()
        extract_selected_btn = QPushButton("Extract Selected to Outputs")
        extract_selected_btn.clicked.connect(self.extract_selected_archive)
        test_archive_btn = QPushButton("Test & Verify Archive")
        test_archive_btn.clicked.connect(self.test_loaded_archive)
        fm_bottom_layout.addWidget(extract_selected_btn)
        fm_bottom_layout.addWidget(test_archive_btn)
        fm_bottom_layout.addStretch()

        fm_layout.addLayout(fm_top_layout)
        fm_layout.addWidget(self.fm_tree)
        fm_layout.addLayout(fm_bottom_layout)

        outputs_widget = QWidget()
        outputs_layout = QVBoxLayout(outputs_widget)
        self.outputs_table = QTableWidget()
        self.outputs_table.setColumnCount(3)
        self.outputs_table.setHorizontalHeaderLabels(["Name", "Type", "Path"])
        self.outputs_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.outputs_table.setStyleSheet("background: #1E293B; color: white;")
        outputs_layout.addWidget(QLabel("WW World Outputs Workspace"))
        outputs_layout.addWidget(self.outputs_table)

        self.tabs.addTab(hub_widget, "Archive Hub")
        self.tabs.addTab(fm_widget, "WW World File Manager")
        self.tabs.addTab(outputs_widget, "Outputs Manager")
        self.setCentralWidget(self.tabs)
        self.populate_outputs()

    def log(self, msg):
        self.log_area.append(msg)

    def populate_outputs(self):
        self.outputs_table.setRowCount(0)
        if not os.path.exists(OUTPUTS_DIR): return
        for item in os.listdir(OUTPUTS_DIR):
            row = self.outputs_table.rowCount()
            self.outputs_table.insertRow(row)
            p = os.path.join(OUTPUTS_DIR, item)
            self.outputs_table.setItem(row, 0, QTableWidgetItem(item))
            self.outputs_table.setItem(row, 1, QTableWidgetItem("Folder" if os.path.isdir(p) else "File"))
            self.outputs_table.setItem(row, 2, QTableWidgetItem(p))

    def on_drop_clicked(self, event):
        path, _ = QFileDialog.getOpenFileName(self, "Select File or .world Archive")
        if not path:
            path = QFileDialog.getExistingDirectory(self, "Select Folder to Archive")
        if path:
            self.process_path(path)

    def process_path(self, path):
        profile = self.profile_combo.currentText()
        if path.endswith('.world'):
            out_path = os.path.join(OUTPUTS_DIR, os.path.splitext(os.path.basename(path))[0])
            self.run_worker(path, out_path, is_folder=False, compress=False, profile=profile)
        else:
            out_path = os.path.join(OUTPUTS_DIR, os.path.basename(path) + ".world")
            is_folder = os.path.isdir(path)
            self.run_worker(path, out_path, is_folder=is_folder, compress=True, profile=profile)

    def run_worker(self, i, o, is_folder, compress, profile):
        self.progress_bar.setValue(0)
        self.worker = WorkerThread(i, o, is_folder, compress, profile)
        self.worker.progress.connect(lambda m, p: (self.status_label.setText(m), self.progress_bar.setValue(p), self.log(m)))
        self.worker.finished.connect(lambda s, m: (QMessageBox.information(self, "Result", m), self.populate_outputs()))
        self.worker.start()

    def browse_and_open_archive(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open .world Archive", OUTPUTS_DIR, "WW World Archives (*.world)")
        if path:
            self.load_archive_in_manager(path)

    def load_archive_in_manager(self, path):
        self.current_loaded_archive = path
        self.fm_path_label.setText(f"Loaded Archive: {os.path.basename(path)}")
        self.fm_tree.clear()

        manifest = WWWorldEngine.read_manifest(path)
        if not manifest:
            QMessageBox.critical(self, "Error", "Could not read archive manifest or invalid format.")
            return

        files_dict = manifest.get("files", {})
        for filepath, fhash in files_dict.items():
            item = QTreeWidgetItem([filepath, "File", fhash])
            self.fm_tree.addTopLevelItem(item)
        self.log(f"Successfully loaded archive into File Manager: {path}")

    def extract_selected_archive(self):
        if not hasattr(self, 'current_loaded_archive') or not os.path.exists(self.current_loaded_archive):
            QMessageBox.warning(self, "Warning", "Please open a .world archive first.")
            return
        out_path = os.path.join(OUTPUTS_DIR, os.path.splitext(os.path.basename(self.current_loaded_archive))[0] + "_extracted")
        success, verified, err = WWWorldEngine.decompress(self.current_loaded_archive, out_path)
        if success:
            msg_text = "Archive extracted successfully to:\n" + out_path
            QMessageBox.information(self, "Success", msg_text)
            self.populate_outputs()
        else:
            QMessageBox.critical(self, "Error", f"Extraction failed: {err}")

    def test_loaded_archive(self):
        if not hasattr(self, 'current_loaded_archive') or not os.path.exists(self.current_loaded_archive):
            QMessageBox.warning(self, "Warning", "Please open a .world archive first.")
            return
        manifest = WWWorldEngine.read_manifest(self.current_loaded_archive)
        if manifest:
            QMessageBox.information(self, "Integrity Test", "Archive header and manifest validated successfully. Structure is intact.")
        else:
            QMessageBox.critical(self, "Integrity Test", "Archive validation failed. File may be corrupted.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    target_arg = sys.argv[1] if len(sys.argv) > 1 else None
    win = WWWorldMainWindow(target_arg)
    win.show()
    sys.exit(app.exec())
'''

SHELL_REG_CODE = r'''import sys
import os

def register_shell_extensions():
    try:
        import winreg
        app_path = os.path.abspath("main.py")
        
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\.world") as key:
            winreg.SetValue(key, "", winreg.REG_SZ, "WWWorld.Document")
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\WWWorld.Document\shell\open\command") as key:
            winreg.SetValue(key, "", winreg.REG_SZ, f'python "{app_path}" "%1"')

        file_shell = r"Software\Classes\*\shell\WWWorldFileManager"
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, file_shell) as key:
            winreg.SetValue(key, "", winreg.REG_SZ, "WW World File Manager")
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, file_shell + r"\command") as key:
            winreg.SetValue(key, "", winreg.REG_SZ, f'python "{app_path}" "%1"')

        dir_shell = r"Software\Classes\Directory\shell\WWWorldFileManager"
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, dir_shell) as key:
            winreg.SetValue(key, "", winreg.REG_SZ, "WW World File Manager")
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, dir_shell + r"\command") as key:
            winreg.SetValue(key, "", winreg.REG_SZ, f'python "{app_path}" "%1"')

        print("Windows Explorer integration registered successfully.")
    except Exception as e:
        print(f"Shell registration notice: {e}")

if __name__ == "__main__":
    register_shell_extensions()
'''

ICON_GEN_CODE = r'''import os
from PIL import Image, ImageDraw

def generate_icon(output_path="icons/ww_world.ico"):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    images = []

    for size in sizes:
        img = Image.new("RGBA", size, (15, 23, 42, 255))
        draw = ImageDraw.Draw(img)
        margin = max(1, size[0] // 8)
        draw.rectangle([margin, margin, size[0]-margin, size[1]-margin], outline="#38BDF8", width=max(1, size[0]//32))
        draw.rectangle([margin*2, margin*2, size[0]-(margin*2), size[1]-(margin*2)], fill="#2563EB", outline="#22C55E", width=max(1, size[0]//32))
        draw.text((size[0]//3.5, size[1]//4), "W", fill="#FFFFFF")
        images.append(img)

    images[0].save(output_path, format="ICO", append_images=images[1:])

if __name__ == "__main__":
    generate_icon()
'''

BATCH_LAUNCHER_CODE = r'''@echo off
TITLE WW World Launcher
cd /d "%~dp0"
echo ========================================
echo        Starting WW World...
echo ========================================

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not added to PATH.
    echo Please install Python 3.10+ from python.org to run WW World.
    pause
    exit /b 1
)

python -c "import PyQt6" >nul 2>&1
if errorlevel 1 (
    echo [WARNING] PyQt6 dependency missing. Installing automatically via pip...
    pip install -r requirements.txt
)

python ww_world_shell.py
echo Launching application...
python main.py %*
if errorlevel 1 (
    echo.
    echo [ERROR] Application encountered an error during execution.
    pause
)
'''

UNINSTALLER_CODE = r'''import os, shutil
from tkinter import Tk, messagebox

root = Tk()
root.withdraw()

reply = messagebox.askyesno("Uninstall WW World", "Are you sure you want to uninstall WW World?\n(User outputs and reports in Desktop/WWWorld will be preserved).")
if reply:
    target = os.path.dirname(os.path.abspath(__file__))
    try:
        shutil.rmtree(target)
        messagebox.showinfo("Uninstalled", "WW World has been successfully removed.")
    except Exception as e:
        messagebox.showerror("Error", f"Could not remove installation folder: {e}")
'''


# ==========================================
# INSTALLER WIZARD GUI
# ==========================================

class WWWorldInstallerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("WW World Setup Wizard")
        self.root.geometry("540x400")
        self.root.configure(bg="#0F172A")
        self.root.resizable(False, False)

        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        x = (screen_width // 2) - (540 // 2)
        y = (screen_height // 2) - (400 // 2)
        root.geometry(f"540x400+{x}+{y}")

        self.create_widgets()

    def create_widgets(self):
        header_frame = tk.Frame(self.root, bg="#0F172A")
        header_frame.pack(fill="x", padx=30, pady=25)

        title_lbl = tk.Label(header_frame, text="WW World Setup", font=("Segoe UI", 18, "bold"), fg="#38BDF8", bg="#0F172A")
        title_lbl.pack(anchor="w")

        sub_lbl = tk.Label(header_frame, text="Professional Windows Archiving Product Installer", font=("Segoe UI", 10), fg="#94A3B8", bg="#0F172A")
        sub_lbl.pack(anchor="w", pady=(5, 0))

        body_frame = tk.Frame(self.root, bg="#1E293B", bd=0, highlightbackground="#334155", highlightthickness=1)
        body_frame.pack(fill="both", expand=True, padx=30, pady=5)

        path_lbl = tk.Label(body_frame, text="Target Installation Directory:", font=("Segoe UI", 10, "bold"), fg="#F8FAFC", bg="#1E293B")
        path_lbl.pack(anchor="w", padx=20, pady=(20, 5))

        self.path_var = tk.StringVar(value=os.path.join(get_desktop_path(), "WW World"))
        path_entry = tk.Entry(body_frame, textvariable=self.path_var, font=("Segoe UI", 10), fg="#38BDF8", bg="#0F172A", insertbackground="white", relief="solid", bd=1)
        path_entry.pack(fill="x", padx=20, pady=(0, 15))

        self.progress = ttk.Progressbar(body_frame, orient="horizontal", length=460, mode="determinate")
        self.progress.pack(padx=20, pady=10)

        self.status_lbl = tk.Label(body_frame, text="Ready to install WW World.", font=("Segoe UI", 9), fg="#94A3B8", bg="#1E293B")
        self.status_lbl.pack(anchor="w", padx=20, pady=(0, 15))

        footer_frame = tk.Frame(self.root, bg="#0F172A")
        footer_frame.pack(fill="x", padx=30, pady=20)

        self.install_btn = tk.Button(footer_frame, text="Install WW World", font=("Segoe UI", 10, "bold"), fg="white", bg="#2563EB", activebackground="#1D4ED8", activeforeground="white", relief="flat", padx=20, pady=8, command=self.perform_installation)
        self.install_btn.pack(side="right")

        cancel_btn = tk.Button(footer_frame, text="Cancel", font=("Segoe UI", 10), fg="#CBD5E1", bg="#334155", activebackground="#475569", activeforeground="white", relief="flat", padx=15, pady=8, command=self.root.quit)
        cancel_btn.pack(side="right", padx=10)

    def perform_installation(self):
        install_dir = self.path_var.get().strip()
        if not install_dir:
            messagebox.showerror("Error", "Please specify a valid installation directory.")
            return

        try:
            self.install_btn.config(state="disabled")
            self.status_lbl.config(text="Creating installation directories...")
            self.progress["value"] = 20
            self.root.update()

            os.makedirs(install_dir, exist_ok=True)
            os.makedirs(os.path.join(install_dir, "resources"), exist_ok=True)
            os.makedirs(os.path.join(install_dir, "licenses"), exist_ok=True)
            os.makedirs(os.path.join(install_dir, "icons"), exist_ok=True)

            desktop = get_desktop_path()
            workspace_dir = os.path.join(desktop, "WWWorld")
            os.makedirs(os.path.join(workspace_dir, "WW World Outputs"), exist_ok=True)
            os.makedirs(os.path.join(workspace_dir, "WW World Reports"), exist_ok=True)

            self.status_lbl.config(text="Extracting application modules & generating icons...")
            self.progress["value"] = 50
            self.root.update()

            with open(os.path.join(install_dir, "ww_world_engine.py"), "w", encoding="utf-8") as f:
                f.write(WW_WORLD_ENGINE_CODE)

            with open(os.path.join(install_dir, "main.py"), "w", encoding="utf-8") as f:
                f.write(MAIN_APP_CODE)

            with open(os.path.join(install_dir, "ww_world_shell.py"), "w", encoding="utf-8") as f:
                f.write(SHELL_REG_CODE)

            with open(os.path.join(install_dir, "ww_world_icon.py"), "w", encoding="utf-8") as f:
                f.write(ICON_GEN_CODE)

            with open(os.path.join(install_dir, "requirements.txt"), "w", encoding="utf-8") as f:
                f.write("PyQt6>=6.0.0\nPillow>=9.0.0\n")

            with open(os.path.join(install_dir, "licenses", "LICENSE.txt"), "w", encoding="utf-8") as f:
                f.write("WW World License: Free for personal and commercial use.\nLossless Archiving & Extreme Compression Engine.")

            with open(os.path.join(install_dir, "Launch WW World.bat"), "w", encoding="utf-8") as f:
                f.write(BATCH_LAUNCHER_CODE)

            with open(os.path.join(install_dir, "Uninstall WW World.py"), "w", encoding="utf-8") as f:
                f.write(UNINSTALLER_CODE)

            # Generate icon asset
            sys.path.insert(0, install_dir)
            import ww_world_icon
            ww_world_icon.generate_icon(os.path.join(install_dir, "icons", "ww_world.ico"))

            self.status_lbl.config(text="Verifying installation integrity...")
            self.progress["value"] = 85
            self.root.update()

            required_files = ["main.py", "ww_world_engine.py", "ww_world_shell.py", "ww_world_icon.py", "Launch WW World.bat", "requirements.txt"]
            for rf in required_files:
                if not os.path.exists(os.path.join(install_dir, rf)):
                    raise FileNotFoundError(f"Verification failed: Missing required file '{rf}'.")

            self.progress["value"] = 100
            self.status_lbl.config(text="Installation completed successfully!")
            self.root.update()

            messagebox.showinfo("Success", f"WW World installed successfully!\n\nProgram Directory:\n{install_dir}\n\nWorkspace Directory:\n{workspace_dir}\n\nYou can now open 'WW World' on your Desktop and run 'Launch WW World.bat'.")
            self.root.quit()

        except Exception as e:
            self.install_btn.config(state="normal")
            self.status_lbl.config(text="Installation failed.")
            messagebox.showerror("Installation Error", f"An error occurred during installation:\n{e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = WWWorldInstallerApp(root)
    root.mainloop()