; Inno Setup 6 script. Compile (Windows):  ISCC.exe packaging\WWWorld.iss /DAppVersion=3.0.0
; Expects the PyInstaller output in dist\WW World\ and the icons in assets\.
#ifndef AppVersion
  #define AppVersion "3.0.0"
#endif

[Setup]
AppId={{6F1C7B52-7E0B-4D55-9A3E-5B0C0A77D1F4}
AppName=WW World
AppVersion={#AppVersion}
AppPublisher=WW World
DefaultDirName={autopf}\WW World
DefaultGroupName=WW World
DisableProgramGroupPage=yes
; per-user install by default (no administrator rights); the user may elevate via the dialog
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=..\dist
OutputBaseFilename=WW-World-Setup-{#AppVersion}
SetupIconFile=..\assets\ww_world.ico
UninstallDisplayIcon={app}\WW World.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ChangesAssociations=yes
CloseApplications=yes
RestartApplications=no
ArchitecturesInstallIn64BitMode=x64compatible

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Shortcuts:"; Flags: unchecked
Name: "contextmenu"; Description: "Add ""WW World File Manager"" to the Explorer right-click menu (""Show more options"" on Windows 11)"; GroupDescription: "Windows integration:"
Name: "assoc"; Description: "Associate .world archives with WW World (archive icon)"; GroupDescription: "Windows integration:"

[Files]
Source: "..\dist\WW World\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\assets\ww_world.ico"; DestDir: "{app}\icons"; Flags: ignoreversion
Source: "..\assets\ww_world_archive.ico"; DestDir: "{app}\icons"; Flags: ignoreversion

[Icons]
Name: "{group}\WW World"; Filename: "{app}\WW World.exe"; IconFilename: "{app}\WW World.exe"
Name: "{group}\Repair WW World Explorer integration"; Filename: "{app}\WW World.exe"; Parameters: "--repair-shell"
Name: "{autodesktop}\WW World"; Filename: "{app}\WW World.exe"; Tasks: desktopicon

[Run]
; Registration is done by the app itself (one implementation, HKCU only), as the original user.
Filename: "{app}\WW World.exe"; Parameters: "--register-shell --no-assoc"; Flags: runhidden waituntilterminated runasoriginaluser; Tasks: contextmenu
Filename: "{app}\WW World.exe"; Parameters: "--register-shell --no-context"; Flags: runhidden waituntilterminated runasoriginaluser; Tasks: assoc
Filename: "{app}\WW World.exe"; Description: "Launch WW World"; Flags: nowait postinstall skipifsilent

[UninstallRun]
; Removes ONLY WW World's own registry entries; user archives, outputs and settings are never touched.
Filename: "{app}\WW World.exe"; Parameters: "--unregister-shell"; Flags: runhidden waituntilterminated runasoriginaluser; RunOnceId: "WWWorldUnregShell"

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
var
  ResultCode: Integer;
  Report: String;
begin
  if CurStep = ssPostInstall then
  begin
    Report := ExpandConstant('{tmp}\wwworld-selftest.json');
    if (not Exec(ExpandConstant('{app}\WW World.exe'), '--selftest --report "' + Report + '"', '',
        SW_HIDE, ewWaitUntilTerminated, ResultCode)) or (ResultCode <> 0) then
      MsgBox('WW World was installed, but its startup self-test FAILED (exit code ' + IntToStr(ResultCode) +
             '). Please report this and keep ' + Report + '.', mbError, MB_OK);
  end;
end;
