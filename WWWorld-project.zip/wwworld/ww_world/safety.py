"""Path validation for untrusted archive member names and extraction targets."""
from __future__ import annotations

import os
import re
import unicodedata


class UnsafePathError(ValueError):
    """An archive path is absolute, escapes the destination, or is not portable."""


_RESERVED = {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$",
             *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))}
_ILLEGAL = set('<>:"|?*') | {chr(i) for i in range(32)}


def normalize_member_path(name: str, *, allow_trailing_slash: bool = True) -> str:
    """Return a canonical 'a/b/c' relative path or raise UnsafePathError.

    Rejects empty names, NUL/control chars, absolute paths (/x, \\x, \\\\server\\share),
    drive-qualified paths (C:x), '.'/'..'/empty components, Windows-illegal characters
    (incl. ':' which also blocks NTFS alternate data streams), reserved device names,
    trailing dots/spaces and over-long components. Backslashes are treated as
    separators (legacy archives written on Windows use them).
    """
    if not isinstance(name, str) or not name:
        raise UnsafePathError("empty path")
    if "\x00" in name:
        raise UnsafePathError(f"NUL character in path: {name!r}")
    n = name.replace("\\", "/")
    if n.startswith("/"):
        raise UnsafePathError(f"absolute or UNC path: {name!r}")
    if re.match(r"^[A-Za-z]:", n):
        raise UnsafePathError(f"drive-qualified path: {name!r}")
    parts = n.split("/")
    if parts and parts[-1] == "" and allow_trailing_slash and len(parts) > 1:
        parts = parts[:-1]
    for p in parts:
        if p in ("", ".", ".."):
            raise UnsafePathError(f"invalid component {p!r} in path: {name!r}")
        if len(p) > 255:
            raise UnsafePathError(f"path component too long: {name!r}")
        if any(c in _ILLEGAL for c in p):
            raise UnsafePathError(f"illegal character in path: {name!r}")
        if p.endswith((".", " ")):
            raise UnsafePathError(f"component ends with dot or space: {name!r}")
        if p.split(".")[0].rstrip(" ").upper() in _RESERVED:
            raise UnsafePathError(f"reserved device name in path: {name!r}")
    return "/".join(parts)


def casefold_key(path: str) -> str:
    """Key under which two paths collide on a case-insensitive Windows volume."""
    return unicodedata.normalize("NFC", path).casefold()


def safe_filename(name: str, fallback: str = "archive") -> str:
    """Make a single valid file-name component from arbitrary text."""
    cleaned = "".join("_" if (c in _ILLEGAL or c in "/\\") else c for c in name).strip(" .")
    if not cleaned or cleaned.split(".")[0].upper() in _RESERVED:
        cleaned = (fallback + "_" + cleaned) if cleaned else fallback
    return cleaned[:200]


def resolve_inside(base: str, rel: str) -> str:
    """Join base+rel and prove (after resolving existing links) the result stays in base.

    Uses commonpath on real paths, so '/out_evil' is NOT inside '/out' (the old
    startswith() check accepted it).
    """
    rel = normalize_member_path(rel)
    base_real = os.path.realpath(base)
    target = os.path.realpath(os.path.join(base_real, *rel.split("/")))
    try:
        common = os.path.commonpath([os.path.normcase(base_real), os.path.normcase(target)])
    except ValueError as exc:  # different drives
        raise UnsafePathError(f"path escapes destination: {rel!r}") from exc
    if common != os.path.normcase(base_real) or os.path.normcase(target) == os.path.normcase(base_real):
        raise UnsafePathError(f"path escapes destination: {rel!r}")
    return target


def is_reparse(path: str) -> bool:
    """True for symlinks and Windows junctions (never followed when archiving)."""
    try:
        return os.path.islink(path) or (hasattr(os.path, "isjunction") and os.path.isjunction(path))
    except OSError:
        return False
