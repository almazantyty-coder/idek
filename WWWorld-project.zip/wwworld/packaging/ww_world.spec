# PyInstaller spec - run from the project root:  pyinstaller packaging/ww_world.spec --noconfirm
# Produces dist/WW World/WW World.exe (one-folder build: starts fast, no per-launch unpacking).
import os
import sys

ROOT = os.path.abspath(os.path.join(SPECPATH, ".."))
WIN = sys.platform == "win32"
ICON = os.path.join(ROOT, "assets", "ww_world.ico")

a = Analysis(
    [os.path.join(ROOT, "main.py")],
    pathex=[ROOT],
    datas=[(os.path.join(ROOT, "assets"), "assets")],
    hiddenimports=["PyQt6.QtNetwork"],
    excludes=["tkinter", "PIL", "pytest", "unittest.mock"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [],
    exclude_binaries=True,
    name="WW World",
    console=False,                      # GUI app; CLI output goes to --report files
    icon=ICON if WIN else None,         # embeds the multi-size icon into the EXE
    version=os.path.join(ROOT, "packaging", "version_info.txt") if WIN else None,
    uac_admin=False,                    # runs as the normal user, never asks for elevation
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="WW World")
