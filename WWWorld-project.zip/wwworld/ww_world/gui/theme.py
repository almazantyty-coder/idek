STYLE = """
QMainWindow, QDialog { background-color: #0F172A; color: #F8FAFC; }
QWidget { color: #E2E8F0; font-family: 'Segoe UI', sans-serif; font-size: 13px; }
QLabel#title { font-size: 20px; font-weight: bold; color: #38BDF8; }
QLabel#muted { color: #94A3B8; }
QPushButton, QToolButton { background-color: #2563EB; color: white; border: none; border-radius: 6px;
    padding: 6px 14px; font-weight: 600; }
QPushButton:hover, QToolButton:hover { background-color: #1D4ED8; }
QPushButton:disabled, QToolButton:disabled { background-color: #334155; color: #64748B; }
QPushButton#secondary { background-color: #334155; }
QPushButton#danger { background-color: #B91C1C; }
QTabWidget::pane { border: 1px solid #334155; background: #1E293B; border-radius: 6px; }
QTabBar::tab { background: #0F172A; color: #94A3B8; padding: 9px 18px; margin-right: 2px; }
QTabBar::tab:selected { background: #2563EB; color: #FFFFFF; font-weight: bold; }
QLineEdit, QComboBox, QPlainTextEdit, QTextEdit, QListWidget { background: #0B1220; color: #F8FAFC;
    border: 1px solid #334155; border-radius: 4px; padding: 4px; }
QTreeWidget, QTableWidget { background: #1E293B; alternate-background-color: #172033; color: #F8FAFC;
    border: 1px solid #334155; gridline-color: #334155; }
QTreeWidget::item:selected, QTableWidget::item:selected, QListWidget::item:selected { background: #2563EB; }
QHeaderView::section { background: #0F172A; color: #38BDF8; padding: 5px; border: none; border-right: 1px solid #334155; }
QProgressBar { background: #0B1220; border: 1px solid #334155; border-radius: 4px; text-align: center; color: white; }
QProgressBar::chunk { background: #22C55E; border-radius: 3px; }
QFrame#drop { border: 2px dashed #22C55E; border-radius: 12px; background: #1E293B; }
QFrame#drop[hover="true"] { border-color: #38BDF8; background: #243247; }
QPlainTextEdit#log { color: #4ADE80; font-family: Consolas, monospace; font-size: 12px; }
QGroupBox { border: 1px solid #334155; border-radius: 6px; margin-top: 10px; padding-top: 10px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; color: #38BDF8; }
QStatusBar { background: #0B1220; }
QMenuBar { background: #0B1220; color: #E2E8F0; }
QMenuBar::item:selected, QMenu::item:selected { background: #2563EB; }
QMenu { background: #1E293B; color: #E2E8F0; border: 1px solid #334155; }
QPushButton#danger:disabled { background-color: #334155; color: #64748B; }
"""
