"""Single-instance support: later launches hand their paths to the running window."""
from __future__ import annotations

import getpass
import hashlib
import json
import time

from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtNetwork import QLocalServer, QLocalSocket


def instance_name() -> str:
    user = getpass.getuser() or "user"
    return "WWWorld-" + hashlib.sha1(user.encode("utf-8", "replace")).hexdigest()[:12]


def send_request(name: str, payload: dict, timeout_ms: int = 1500) -> bool:
    sock = QLocalSocket()
    sock.connectToServer(name)
    if not sock.waitForConnected(timeout_ms):
        return False
    sock.write(json.dumps(payload).encode("utf-8") + b"\n")
    ok = sock.waitForBytesWritten(timeout_ms)
    sock.disconnectFromServer()
    return bool(ok)


def send_with_retry(name: str, payload: dict, seconds: float = 3.0) -> bool:
    end = time.time() + seconds
    while time.time() < end:
        if send_request(name, payload, 500):
            return True
        time.sleep(0.15)
    return False


class InstanceServer(QObject):
    request_received = pyqtSignal(dict)

    def __init__(self, name: str, parent=None):
        super().__init__(parent)
        self.name = name
        self.server = QLocalServer(self)
        self.server.newConnection.connect(self._on_conn)

    def listen(self) -> bool:
        if self.server.listen(self.name):
            return True
        # Only reached after a failed connect: a stale socket may be left behind (Unix).
        QLocalServer.removeServer(self.name)
        return self.server.listen(self.name)

    def _on_conn(self):
        while self.server.hasPendingConnections():
            sock = self.server.nextPendingConnection()
            buf = bytearray()

            def on_ready(s=sock, b=buf):
                b.extend(bytes(s.readAll()))
                while b"\n" in b:
                    line, _, rest = bytes(b).partition(b"\n")
                    b[:] = rest
                    try:
                        data = json.loads(line.decode("utf-8"))
                        if isinstance(data, dict):
                            self.request_received.emit(data)
                    except ValueError:
                        pass

            sock.readyRead.connect(on_ready)
            sock.disconnected.connect(lambda s=sock, f=on_ready: (f(), s.deleteLater()))
            on_ready()          # bytes may already be buffered before we connected readyRead
