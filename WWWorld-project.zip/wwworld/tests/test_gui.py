import os
import time

import pytest
from PyQt6.QtCore import QMimeData, QPoint, QPointF, Qt, QUrl
from PyQt6.QtGui import QDragEnterEvent, QDropEvent
from PyQt6.QtWidgets import QApplication, QDialog, QFileDialog, QMessageBox

from ww_world import archive as A


@pytest.fixture(scope="session")
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def env(tmp_path, monkeypatch, qapp):
    home = tmp_path / "home"
    (home / "Desktop").mkdir(parents=True)
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "cfg"))
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))
    msgs = []
    for kind in ("information", "warning", "critical"):
        monkeypatch.setattr(QMessageBox, kind, staticmethod(lambda p, t, m, *a, _k=kind, **k: (msgs.append((_k, m)), QMessageBox.StandardButton.Ok)[1]))
    from ww_world.gui.main_window import WWWorldMainWindow
    win = WWWorldMainWindow()
    win.show()
    yield win, msgs, tmp_path
    win.worker and win.worker.wait(3000)
    win.close()


def wait_until(cond, timeout=15):
    end = time.time() + timeout
    while time.time() < end:
        QApplication.processEvents()
        if cond():
            return True
        time.sleep(0.01)
    return False


def idle(win):
    return wait_until(lambda: win.worker is None)


def make_tree(tmp_path):
    d = tmp_path / "data"
    (d / "sub").mkdir(parents=True)
    (d / "sub" / "deep.txt").write_text("deep")
    (d / "a.txt").write_text("alpha")
    (d / "pic with space.png").write_bytes(b"\x89PNG")
    return d


def names(fm):
    return [fm.tree.topLevelItem(i).text(0) for i in range(fm.tree.topLevelItemCount())]


def test_window_opens_with_all_tabs(env):
    win, _, _ = env
    assert [win.tabs.tabText(i) for i in range(win.tabs.count())] == \
        ["Archive Hub", "WW World File Manager", "Outputs Manager", "Settings"]
    assert os.path.isdir(win.outputs_dir())
    assert os.path.isdir(os.path.join(os.path.dirname(win.outputs_dir()), "WW World Reports"))


def test_open_folder_browse_back_up(env):
    win, _, tmp = env
    d = make_tree(tmp)
    win.open_in_manager([str(d)])
    fm = win.fm
    assert win.tabs.currentWidget() is fm
    assert names(fm) == ["sub", "a.txt", "pic with space.png"]            # folders first
    fm.tree.setCurrentItem(fm.tree.topLevelItem(0))
    fm.tree.topLevelItem(0).setSelected(True)
    fm.open_selected()
    assert names(fm) == ["deep.txt"] and fm.loc == ("fs", str(d / "sub"))
    fm.go_up()
    assert fm.loc == ("fs", str(d))
    fm.go_back()
    assert fm.loc == ("fs", str(d / "sub"))
    fm.go_forward()
    assert fm.loc == ("fs", str(d))


def test_open_ordinary_file_shows_it_selected_and_does_not_compress(env):
    win, msgs, tmp = env
    d = make_tree(tmp)
    win.open_in_manager([str(d / "a.txt")])
    fm = win.fm
    assert fm.loc == ("fs", str(d))
    assert [i.text(0) for i in fm.tree.selectedItems()] == ["a.txt"]
    assert "a.txt" in fm.details.toPlainText() and "Size" in fm.details.toPlainText()
    assert os.listdir(win.outputs_dir()) == []                             # nothing auto-compressed
    assert win.worker is None


def test_open_multiple_selection(env):
    win, _, tmp = env
    d = make_tree(tmp)
    win.open_in_manager([str(d / "a.txt"), str(d / "sub"), str(d / "pic with space.png")])
    assert win.fm.loc[0] == "sel" and sorted(names(win.fm)) == ["a.txt", "pic with space.png", "sub"]


def test_missing_path_reports_error(env):
    win, msgs, tmp = env
    win.open_in_manager([str(tmp / "ghost.txt")])
    assert msgs and msgs[-1][0] == "warning" and "ghost.txt" in msgs[-1][1]


def test_archive_browse_navigate_hierarchy(env):
    win, msgs, tmp = env
    d = make_tree(tmp)
    arc = str(tmp / "d.world")
    A.compress(str(d), arc, "Fast")
    win.open_in_manager([arc])
    fm = win.fm
    assert fm.loc == ("arc", arc, "") and names(fm) == ["sub", "a.txt", "pic with space.png"]
    assert fm.tree.columnCount() == 5
    fm.tree.topLevelItem(0).setSelected(True)
    fm.open_selected()
    assert fm.loc == ("arc", arc, "sub") and names(fm) == ["deep.txt"]
    sha = fm.tree.topLevelItem(0).text(4)
    assert len(sha) == 64
    fm.go_up()
    assert fm.loc == ("arc", arc, "")
    fm.go_up()
    assert fm.loc == ("fs", str(tmp))                                      # leaves archive to its folder
    assert os.listdir(win.outputs_dir()) == []


def test_invalid_archive_shows_error_and_does_not_crash(env):
    win, msgs, tmp = env
    bad = tmp / "bad.world"
    bad.write_bytes(b"this is not an archive at all")
    win.open_in_manager([str(bad)])
    assert msgs[-1][0] == "critical" and "bad.world" in msgs[-1][1]
    assert win.fm.loc is None


def test_drag_and_drop_queues_without_compressing(env):
    win, msgs, tmp = env
    d = make_tree(tmp)
    drop = win.hub.drop
    mime = QMimeData()
    mime.setUrls([QUrl.fromLocalFile(str(d)), QUrl.fromLocalFile(str(d / "a.txt")), QUrl.fromLocalFile(str(tmp / "nope"))])
    ev = QDragEnterEvent(QPoint(5, 5), Qt.DropAction.CopyAction, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    QApplication.sendEvent(drop, ev)
    assert ev.isAccepted()
    ev2 = QDropEvent(QPointF(5, 5), Qt.DropAction.CopyAction, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    QApplication.sendEvent(drop, ev2)
    q = win.hub
    assert [q.queue.item(i).text() for i in range(q.queue.count())] == [str(d), str(d / "a.txt")]
    assert win.worker is None and os.listdir(win.outputs_dir()) == []
    # a non-file drag is rejected
    m2 = QMimeData()
    m2.setText("hi")
    ev3 = QDragEnterEvent(QPoint(1, 1), Qt.DropAction.CopyAction, m2, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    QApplication.sendEvent(drop, ev3)
    assert not ev3.isAccepted()


def test_create_extract_test_end_to_end_through_gui(env, monkeypatch):
    win, msgs, tmp = env
    d = make_tree(tmp)
    out = str(tmp / "made.world")
    monkeypatch.setattr(QFileDialog, "getSaveFileName", staticmethod(lambda *a, **k: (out, "")))
    seen = []
    win.progress.valueChanged.connect(seen.append)
    win.create_archive([str(d)], profile="Fast")
    assert idle(win)
    assert os.path.isfile(out) and any("created" in m[1].lower() for m in msgs if m[0] == "information")
    assert max(seen) >= 80 and win.progress.value() == 100 or win.progress.value() >= 80
    assert A.test_archive(out).status == "ok"
    assert [m for m in msgs if "Verification: Archive test PASSED" in m[1]]

    dest = str(tmp / "restored")
    monkeypatch.setattr("ww_world.gui.main_window.DestDialog.exec", lambda self: QDialog.DialogCode.Accepted)
    monkeypatch.setattr("ww_world.gui.main_window.DestDialog.path", lambda self: dest)
    win.extract_archive(out)
    assert idle(win)
    assert (tmp / "restored" / "sub" / "deep.txt").read_text() == "deep"

    win.test_archive(out)
    assert idle(win)
    assert any("PASSED" in m[1] for m in msgs if m[0] == "information")
    reports = os.listdir(os.path.join(os.path.dirname(win.outputs_dir()), "WW World Reports"))
    assert len(reports) == 1 and reports[0].endswith(".txt")


def test_extract_conflict_dialog_keep_both(env, monkeypatch):
    win, msgs, tmp = env
    f = tmp / "one.txt"
    f.write_text("fresh")
    arc = str(tmp / "one.world")
    A.compress(str(f), arc, "Fast")
    dest = tmp / "dest"
    dest.mkdir()
    (dest / "one.txt").write_text("OLD")
    monkeypatch.setattr("ww_world.gui.main_window.DestDialog.exec", lambda self: QDialog.DialogCode.Accepted)
    monkeypatch.setattr("ww_world.gui.main_window.DestDialog.path", lambda self: str(dest))
    monkeypatch.setattr(QMessageBox, "exec", lambda self: 0)
    monkeypatch.setattr(QMessageBox, "clickedButton", lambda self: [b for b in self.buttons() if "Keep" in b.text()][0])
    win.extract_archive(arc)
    assert idle(win)
    assert (dest / "one.txt").read_text() == "OLD" and (dest / "one (2).txt").read_text() == "fresh"


def test_failed_operation_does_not_stick_gui(env):
    win, msgs, tmp = env

    def boom(progress, cancel):
        progress("working", 10)
        raise RuntimeError("disk exploded")
    win.run_operation("Exploding", boom)
    assert idle(win)
    assert win.worker is None and not win.btn_cancel.isEnabled()
    assert msgs[-1][0] == "critical" and "disk exploded" in msgs[-1][1]
    ran = []
    win.run_operation("Next", lambda p, c: ran.append(1))
    assert idle(win) and ran == [1]


def test_cancel_is_real(env):
    win, msgs, tmp = env
    started = []

    def slow(progress, cancel):
        started.append(1)
        for _ in range(2000):
            if cancel():
                from ww_world.archive import OperationCancelled
                raise OperationCancelled()
            time.sleep(0.005)
        return "finished normally"
    win.run_operation("Slow", slow)
    assert wait_until(lambda: started)
    assert win.btn_cancel.isEnabled()
    win._cancel()
    assert idle(win)
    assert win.status_label.text() == "Cancelled" and not msgs


def test_second_operation_while_busy_is_refused(env):
    win, msgs, tmp = env
    win.run_operation("Slow", lambda p, c: [time.sleep(0.01) for _ in range(30)])
    win.run_operation("Second", lambda p, c: None)
    assert msgs and "still running" in msgs[-1][1]
    assert idle(win)


def test_outputs_manager_lists_and_reports_errors(env):
    win, msgs, tmp = env
    out = win.outputs_dir()
    open(os.path.join(out, "x.world"), "wb").write(b"1234")
    os.makedirs(os.path.join(out, "folder1"))
    win.outputs.refresh()
    t = win.outputs.table
    rows = {t.item(r, 0).text(): t.item(r, 1).text() for r in range(t.rowCount())}
    assert rows == {"folder1": "Folder", "x.world": "WW World Archive"}
    win.settings.output_dir = str(tmp / "does-not-exist")
    win.outputs.refresh()
    assert "Cannot read" in win.outputs.error.text() and win.outputs.table.rowCount() == 0


def test_settings_persist(env):
    win, msgs, tmp = env
    win.settings_page.profile.setCurrentText("Balanced")
    win.settings_page.verify.setChecked(False)
    win.settings_page.out.setText(str(tmp / "myout"))
    win.settings_page.save()
    from ww_world import settings as S
    s = S.load()
    assert s.profile == "Balanced" and s.verify_after_create is False and s.output_dir == str(tmp / "myout")
    assert os.path.isdir(tmp / "myout")


def test_settings_shell_controls_disabled_off_windows(env):
    win, _, _ = env
    import sys
    if sys.platform != "win32":
        assert not win.settings_page.btn_apply.isEnabled()
        assert "only available on Windows" in win.settings_page.shell_status.text()


def test_single_instance_forwarding_merges_burst_into_one_selection(env):
    win, msgs, tmp = env
    from ww_world.instance import InstanceServer, send_request
    d = make_tree(tmp)
    name = f"WWWorldTest-{os.getpid()}"
    server = InstanceServer(name)
    assert server.listen()
    server.request_received.connect(lambda r: win.handle_external_open(r["paths"]))
    for p in (d / "a.txt", d / "sub", d / "pic with space.png"):      # three processes, one per selected item
        assert send_request(name, {"action": "open", "paths": [str(p)]})
    assert wait_until(lambda: win.fm.loc is not None and win.fm.loc[0] == "sel")
    assert sorted(names(win.fm)) == ["a.txt", "pic with space.png", "sub"]
    server.server.close()


def test_double_click_risky_file_asks_first(env, monkeypatch):
    win, msgs, tmp = env
    (tmp / "setup.exe").write_bytes(b"MZ")
    opened = []
    monkeypatch.setattr("ww_world.gui.filemanager.QDesktopServices.openUrl", staticmethod(lambda u: opened.append(u)))
    monkeypatch.setattr(QMessageBox, "warning", staticmethod(lambda *a, **k: QMessageBox.StandardButton.No))
    win.open_in_manager([str(tmp / "setup.exe")])
    win.fm.open_selected()
    assert opened == []
