"""Resource, workspace and settings locations (works from source and when frozen)."""
from __future__ import annotations

import os
import sys

from . import APP_NAME


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def resource_path(relative: str) -> str:
    """Locate a bundled resource. Never uses the current working directory."""
    if is_frozen():
        base = getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    else:
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, relative)


def app_executable() -> str | None:
    """Path of the installed 'WW World.exe' (None when running from source)."""
    return os.path.abspath(sys.executable) if is_frozen() else None


def get_desktop_path() -> str:
    """Real Desktop folder via the Windows known-folder API (handles redirected Desktops)."""
    if sys.platform == "win32":
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                            ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

            # FOLDERID_Desktop = {B4BFCC3A-DB2C-424C-B029-7FE99A87C641}
            fid = GUID(0xB4BFCC3A, 0xDB2C, 0x424C,
                       (ctypes.c_ubyte * 8)(0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41))
            out = ctypes.c_wchar_p()
            fn = ctypes.windll.shell32.SHGetKnownFolderPath
            fn.argtypes = [ctypes.POINTER(GUID), wintypes.DWORD, wintypes.HANDLE,
                           ctypes.POINTER(ctypes.c_wchar_p)]
            if fn(ctypes.byref(fid), 0, None, ctypes.byref(out)) == 0 and out.value:
                value = out.value
                ctypes.windll.ole32.CoTaskMemFree(out)
                return value
        except Exception:
            pass
    return os.path.join(os.path.expanduser("~"), "Desktop")


def workspace_root() -> str:
    return os.path.join(get_desktop_path(), "WWWorld")


def default_outputs_dir() -> str:
    return os.path.join(workspace_root(), "WW World Outputs")


def default_reports_dir() -> str:
    return os.path.join(workspace_root(), "WW World Reports")


def ensure_workspace(outputs: str | None = None) -> tuple[str, str]:
    """Create (lazily, never at import time) the outputs and reports folders."""
    out = outputs or default_outputs_dir()
    rep = default_reports_dir()
    os.makedirs(out, exist_ok=True)
    os.makedirs(rep, exist_ok=True)
    return out, rep


def config_dir() -> str:
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, APP_NAME)


def log_dir() -> str:
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    else:
        base = os.environ.get("XDG_STATE_HOME") or os.path.expanduser("~/.local/state")
    return os.path.join(base, APP_NAME, "logs")
