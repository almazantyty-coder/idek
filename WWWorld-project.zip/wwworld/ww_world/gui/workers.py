import logging
import threading

from PyQt6.QtCore import QThread, pyqtSignal

from ..archive import OperationCancelled

log = logging.getLogger("wwworld")


class OperationWorker(QThread):
    """Runs fn(progress_cb, cancel_cb) off the GUI thread.

    The result signal is deliberately NOT called `finished` (that would shadow
    QThread.finished, which the original code did).
    """
    progress = pyqtSignal(str, int)
    result_ready = pyqtSignal(object)      # dict: ok, cancelled, value, error

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self._fn = fn
        self._cancel = threading.Event()

    def cancel(self):
        self._cancel.set()

    def run(self):
        res = {"ok": False, "cancelled": False, "value": None, "error": ""}
        try:
            res["value"] = self._fn(lambda m, p: self.progress.emit(m, int(p)), self._cancel.is_set)
            res["ok"] = True
        except OperationCancelled:
            res["cancelled"] = True
        except Exception as exc:                     # never leave the GUI waiting
            log.exception("operation failed")
            res["error"] = str(exc) or type(exc).__name__
            res["exc"] = exc
        self.result_ready.emit(res)
