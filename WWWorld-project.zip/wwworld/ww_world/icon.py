"""Generate the WW World application icon and the .world archive icon (multi-size .ico).

Drawn at 1024px and down-sampled, so it stays crisp at 16px. No font dependency:
the double-V "W" is a polygon.
"""
from __future__ import annotations

import os

from PIL import Image, ImageDraw

SIZES = [16, 24, 32, 48, 64, 128, 256]
NAVY, BLUE, CYAN, GREEN, WHITE = "#0F172A", "#2563EB", "#38BDF8", "#22C55E", "#FFFFFF"


def _draw_w(d: ImageDraw.ImageDraw, box, color, t):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    # four strokes forming a W
    xs = [x0, x0 + w * 0.25, x0 + w * 0.5, x0 + w * 0.75, x1]
    ys = [y0, y1, y0 + h * 0.35, y1, y0]
    for i in range(4):
        d.line([(xs[i], ys[i]), (xs[i + 1], ys[i + 1])], fill=color, width=int(t), joint="curve")
    r = t / 2
    for x, y in zip(xs, ys):
        d.ellipse([x - r, y - r, x + r, y + r], fill=color)


def _base(big: int = 1024) -> Image.Image:
    return Image.new("RGBA", (big, big), (0, 0, 0, 0))


def app_icon_image(big: int = 1024) -> Image.Image:
    img = _base(big)
    d = ImageDraw.Draw(img)
    m = big * 0.04
    d.rounded_rectangle([m, m, big - m, big - m], radius=big * 0.22, fill=NAVY, outline=CYAN, width=int(big * 0.025))
    d.rounded_rectangle([big * 0.13, big * 0.13, big * 0.87, big * 0.87], radius=big * 0.16, fill=BLUE)
    _draw_w(d, (big * 0.2, big * 0.27, big * 0.8, big * 0.68), WHITE, big * 0.085)
    d.rounded_rectangle([big * 0.2, big * 0.76, big * 0.8, big * 0.81], radius=big * 0.025, fill=GREEN)
    return img


def archive_icon_image(big: int = 1024) -> Image.Image:
    """Document page with folded corner, W badge and a zipper strip."""
    img = _base(big)
    d = ImageDraw.Draw(img)
    l, t, r, b = big * 0.16, big * 0.05, big * 0.84, big * 0.95
    fold = big * 0.22
    d.polygon([(l, t), (r - fold, t), (r, t + fold), (r, b), (l, b)], fill="#E2E8F0", outline=NAVY)
    d.polygon([(r - fold, t), (r - fold, t + fold), (r, t + fold)], fill=CYAN, outline=NAVY)
    d.rectangle([l, big * 0.62, r, b], fill=BLUE)
    d.rectangle([l, big * 0.62, r, big * 0.655], fill=GREEN)
    _draw_w(d, (big * 0.28, big * 0.7, big * 0.72, big * 0.9), WHITE, big * 0.055)
    zx = (l + r) / 2 - big * 0.02
    for i in range(7):                       # zipper teeth
        y = t + big * 0.04 + i * big * 0.075
        d.rectangle([zx - big * 0.035 * (i % 2), y, zx + big * 0.035 * ((i + 1) % 2) + big * 0.02, y + big * 0.04], fill=NAVY)
    return img


def save_ico(img: Image.Image, path: str, sizes=SIZES) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    big = img.resize((256, 256), Image.LANCZOS)
    big.save(path, format="ICO", sizes=[(s, s) for s in sizes])


def generate_all(out_dir: str) -> dict[str, str]:
    out = {"app": os.path.join(out_dir, "ww_world.ico"), "archive": os.path.join(out_dir, "ww_world_archive.ico"),
           "app_png": os.path.join(out_dir, "ww_world.png")}
    app = app_icon_image()
    save_ico(app, out["app"])
    save_ico(archive_icon_image(), out["archive"])
    app.resize((256, 256), Image.LANCZOS).save(out["app_png"])
    return out


if __name__ == "__main__":
    import sys
    print(generate_all(sys.argv[1] if len(sys.argv) > 1 else "assets"))
