"""Archive Hub, Outputs Manager and Settings pages."""
from __future__ import annotations

import os
import sys

from PyQt6.QtCore import QUrl, Qt, pyqtSignal
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QFormLayout, QFrame, QGroupBox,
                             QHBoxLayout, QLabel, QLineEdit, QListWidget, QMenu, QMessageBox,
                             QPlainTextEdit, QPushButton, QTableWidget, QTableWidgetItem,
                             QHeaderView, QVBoxLayout, QWidget, QAbstractItemView, QSplitter)

from .. import archive as A
from .. import paths, settings as S, shell_integration as SH
from .filemanager import fmt_time


class DropFrame(QFrame):
    dropped = pyqtSignal(list)
    clicked = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setObjectName("drop")
        self.setAcceptDrops(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        lay = QVBoxLayout(self)
        lbl = QLabel("Drag && drop files, folders or .world archives here\n(or click to browse)")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(lbl)
        self.setMinimumHeight(150)

    def _set_hover(self, v: bool):
        self.setProperty("hover", v)
        self.style().unpolish(self)
        self.style().polish(self)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            self._set_hover(True)
        else:
            e.ignore()

    def dragLeaveEvent(self, e):
        self._set_hover(False)

    def dropEvent(self, e):
        self._set_hover(False)
        paths_ = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if paths_:
            e.acceptProposedAction()
            self.dropped.emit(paths_)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()


class HubPage(QWidget):
    def __init__(self, host):
        super().__init__()
        self.host = host
        lay = QHBoxLayout(self)
        split = QSplitter(Qt.Orientation.Horizontal)
        lay.addWidget(split)

        left = QWidget()
        l = QVBoxLayout(left)
        t = QLabel("WW World Archive Hub")
        t.setObjectName("title")
        l.addWidget(t)
        l.addWidget(QLabel("Compression profile:"))
        self.profile = QComboBox()
        self.profile.addItems(list(A.PROFILES))
        self.profile.setCurrentText(host.settings.profile)
        self.profile.setToolTip("Fast: quick. Balanced: good. Maximum: small, ~0.7 GB RAM to create. "
                                "Extreme Search: smallest, ~1.4 GB RAM to create, ~128 MB to extract.")
        l.addWidget(self.profile)
        self.drop = DropFrame()
        self.drop.dropped.connect(self.add_paths)
        self.drop.clicked.connect(self._browse_menu)
        l.addWidget(self.drop)
        l.addWidget(QLabel("Queued items (nothing is compressed until you click Create Archive):"))
        self.queue = QListWidget()
        self.queue.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        l.addWidget(self.queue, 1)
        row = QHBoxLayout()
        for text, slot, name in (("Create Archive", self.create, None), ("Extract…", self.extract, None),
                                 ("Test", self.test, "secondary"), ("Open in File Manager", self.manage, "secondary"),
                                 ("Remove", self.remove, "secondary"), ("Clear", self.queue_clear, "secondary")):
            b = QPushButton(text)
            if name:
                b.setObjectName(name)
            b.clicked.connect(lambda _=False, s=slot: s())
            row.addWidget(b)
        l.addLayout(row)

        right = QWidget()
        r = QVBoxLayout(right)
        r.addWidget(QLabel("Activity log"))
        self.log_area = QPlainTextEdit()
        self.log_area.setObjectName("log")
        self.log_area.setReadOnly(True)
        r.addWidget(self.log_area)
        split.addWidget(left)
        split.addWidget(right)
        split.setSizes([520, 560])

    def append_log(self, msg: str):
        self.log_area.appendPlainText(msg)

    def add_paths(self, ps: list[str]):
        have = {self.queue.item(i).text() for i in range(self.queue.count())}
        for p in ps:
            p = os.path.abspath(p)
            if os.path.exists(p) and p not in have:
                self.queue.addItem(p)
            elif not os.path.exists(p):
                self.host.log(f"Ignored (not found): {p}")

    def _browse_menu(self):
        m = QMenu(self)
        m.addAction("Add files…", self._add_files)
        m.addAction("Add folder…", self._add_folder)
        m.exec(self.cursor().pos())

    def _add_files(self):
        fs, _ = QFileDialog.getOpenFileNames(self, "Select files or .world archives")
        self.add_paths(fs)

    def _add_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Select folder")
        if d:
            self.add_paths([d])

    def _items(self, selected=False) -> list[str]:
        its = self.queue.selectedItems() if selected and self.queue.selectedItems() else \
            [self.queue.item(i) for i in range(self.queue.count())]
        return [i.text() for i in its]

    def remove(self):
        for i in self.queue.selectedItems():
            self.queue.takeItem(self.queue.row(i))

    def queue_clear(self):
        self.queue.clear()

    def _archives(self):
        return [p for p in self._items(True) if p.lower().endswith(".world") and os.path.isfile(p)]

    def create(self):
        ins = [p for p in self._items(True) if not (p.lower().endswith(".world") and os.path.isfile(p))]
        if not ins:
            QMessageBox.information(self, "WW World", "Add files or folders to archive first.")
            return
        self.host.settings.profile = self.profile.currentText()
        self.host.create_archive(ins, profile=self.profile.currentText())

    def extract(self):
        arcs = self._archives()
        if not arcs:
            QMessageBox.information(self, "WW World", "Add a .world archive to extract first.")
            return
        self.host.extract_archive(arcs[0])

    def test(self):
        arcs = self._archives()
        if not arcs:
            QMessageBox.information(self, "WW World", "Add a .world archive to test first.")
            return
        self.host.test_archive(arcs[0])

    def manage(self):
        items = self._items(True)
        if items:
            self.host.open_in_manager(items)


class OutputsPage(QWidget):
    def __init__(self, host):
        super().__init__()
        self.host = host
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        self.title = QLabel("")
        self.title.setObjectName("title")
        top.addWidget(self.title, 1)
        for text, slot in (("Refresh", self.refresh), ("Open folder", self.open_folder),
                           ("Show in File Manager", self.manage)):
            b = QPushButton(text)
            b.clicked.connect(lambda _=False, s=slot: s())
            top.addWidget(b)
        lay.addLayout(top)
        self.error = QLabel("")
        self.error.setStyleSheet("color:#F87171;")
        self.error.setWordWrap(True)
        lay.addWidget(self.error)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Name", "Type", "Size", "Modified"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.cellDoubleClicked.connect(lambda *_: self.manage())
        lay.addWidget(self.table, 1)
        self.refresh()

    def refresh(self):
        d = self.host.outputs_dir()
        self.title.setText(f"Outputs: {d}")
        self.table.setRowCount(0)
        self.error.setText("")
        try:
            names = sorted(os.listdir(d), key=str.casefold)
        except OSError as exc:
            self.error.setText(f"Cannot read the outputs folder: {exc}")
            return
        for n in names:
            p = os.path.join(d, n)
            try:
                st = os.stat(p)
            except OSError as exc:
                self.error.setText(f"Some items could not be read ({n}: {exc})")
                continue
            isdir = os.path.isdir(p)
            typ = "Folder" if isdir else ("WW World Archive" if n.lower().endswith(".world") else "File")
            row = self.table.rowCount()
            self.table.insertRow(row)
            for c, v in enumerate((n, typ, "" if isdir else A.human_size(st.st_size), fmt_time(st.st_mtime))):
                it = QTableWidgetItem(v)
                if c == 0:
                    it.setData(Qt.ItemDataRole.UserRole, p)
                self.table.setItem(row, c, it)

    def _selected(self):
        r = self.table.currentRow()
        return self.table.item(r, 0).data(Qt.ItemDataRole.UserRole) if r >= 0 else None

    def open_folder(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(self.host.outputs_dir()))

    def manage(self):
        p = self._selected()
        if p:
            self.host.open_in_manager([p])


class SettingsPage(QWidget):
    def __init__(self, host):
        super().__init__()
        self.host = host
        lay = QVBoxLayout(self)
        g = QGroupBox("General")
        f = QFormLayout(g)
        self.out = QLineEdit(host.settings.output_dir or paths.default_outputs_dir())
        b = QPushButton("Browse…")
        b.setObjectName("secondary")
        b.clicked.connect(self._browse)
        row = QHBoxLayout()
        row.addWidget(self.out, 1)
        row.addWidget(b)
        f.addRow("Default output location:", row)
        self.profile = QComboBox()
        self.profile.addItems(list(A.PROFILES))
        self.profile.setCurrentText(host.settings.profile)
        f.addRow("Default compression profile:", self.profile)
        self.verify = QCheckBox("Test every archive right after creating it")
        self.verify.setChecked(host.settings.verify_after_create)
        f.addRow("", self.verify)
        save = QPushButton("Save settings")
        save.clicked.connect(self.save)
        f.addRow("", save)
        lay.addWidget(g)

        sh = QGroupBox("Windows Explorer integration (current user, no administrator rights)")
        v = QVBoxLayout(sh)
        self.cb_context = QCheckBox('Right-click menu: "WW World File Manager" (files, folders, folder background)')
        self.cb_assoc = QCheckBox("Associate .world files with WW World (with archive icon)")
        self.shell_status = QLabel("")
        self.shell_status.setWordWrap(True)
        row2 = QHBoxLayout()
        self.btn_apply = QPushButton("Apply")
        self.btn_apply.clicked.connect(self.apply_shell)
        self.btn_repair = QPushButton("Repair / re-register")
        self.btn_repair.setObjectName("secondary")
        self.btn_repair.clicked.connect(self.repair_shell)
        row2.addWidget(self.btn_apply)
        row2.addWidget(self.btn_repair)
        row2.addStretch(1)
        for w in (self.cb_context, self.cb_assoc, self.shell_status):
            v.addWidget(w)
        v.addLayout(row2)
        lay.addWidget(sh)
        lay.addStretch(1)
        self.exe = paths.app_executable()
        self.reload_shell()

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Default output location", self.out.text())
        if d:
            self.out.setText(d)

    def save(self):
        s = self.host.settings
        s.output_dir = "" if os.path.normpath(self.out.text()) == os.path.normpath(paths.default_outputs_dir()) else self.out.text().strip()
        s.profile = self.profile.currentText()
        s.verify_after_create = self.verify.isChecked()
        try:
            os.makedirs(s.outputs(), exist_ok=True)
            S.save(s)
        except OSError as exc:
            QMessageBox.critical(self, "WW World", f"Could not save settings or create folder:\n{exc}")
            return
        self.host.hub.profile.setCurrentText(s.profile)
        self.host.outputs.refresh()
        self.host.log("Settings saved.")

    def _shell_available(self) -> str | None:
        if sys.platform != "win32":
            return "Explorer integration is only available on Windows."
        if not self.exe:
            return "Explorer integration is available from the installed 'WW World.exe' (not when running from source)."
        return None

    def archive_icon(self) -> str | None:
        for cand in (os.path.join(os.path.dirname(self.exe or ""), "icons", "ww_world_archive.ico"),
                     paths.resource_path(os.path.join("assets", "ww_world_archive.ico"))):
            if os.path.isfile(cand):
                return cand
        return None

    def reload_shell(self):
        why = self._shell_available()
        for w in (self.cb_context, self.cb_assoc, self.btn_apply, self.btn_repair):
            w.setEnabled(why is None)
        if why:
            self.shell_status.setText(why)
            return
        try:
            st = SH.status(self.exe)
        except SH.ShellError as exc:
            self.shell_status.setText(str(exc))
            return
        self.cb_context.setChecked(st["context_registered"])
        self.cb_assoc.setChecked(st["association"])
        stale = st["stale"] or (st["association"] and not st["association_ok"])
        self.shell_status.setText("Registered entries point to a different location - click Repair." if stale else
                                  "Registrations match this installation." if (st["context_registered"] or st["association"]) else
                                  "Nothing registered.")

    def apply_shell(self):
        try:
            if self.cb_context.isChecked():
                SH.register_context_menu(self.exe)
            else:
                SH.unregister_context_menu()
            if self.cb_assoc.isChecked():
                SH.register_association(self.exe, self.archive_icon())
            else:
                SH.unregister_association()
        except (SH.ShellError, OSError) as exc:
            QMessageBox.critical(self, "WW World", f"Could not update Explorer integration:\n{exc}")
        self.reload_shell()
        self.host.log("Explorer integration updated. Icon changes may need Explorer to refresh its icon cache.")

    def repair_shell(self):
        try:
            did = SH.repair(self.exe, self.archive_icon())
            if not any(did.values()):
                QMessageBox.information(self, "WW World", "Nothing is registered yet - tick the options and press Apply.")
        except (SH.ShellError, OSError) as exc:
            QMessageBox.critical(self, "WW World", f"Repair failed:\n{exc}")
        self.reload_shell()
