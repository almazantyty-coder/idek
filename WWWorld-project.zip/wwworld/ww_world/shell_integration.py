"""Per-user Windows Explorer integration (HKCU only - no administrator rights needed).

Registers (all under HKCU\\Software\\Classes):
  *\\shell\\WWWorldFileManager                  files
  Directory\\shell\\WWWorldFileManager          folders
  Directory\\Background\\shell\\WWWorldFileManager   folder background (%V)
  .world -> WWWorld.Archive (DefaultIcon + open command)       [optional association]
These are the classic ("Show more options") verbs. No Windows 11 modern-menu COM
extension is implemented. `winreg` is injectable so the logic is unit-testable.
"""
from __future__ import annotations

import os
import sys
from typing import Optional

VERB = "WWWorldFileManager"
VERB_TEXT = "WW World File Manager"
PROGID = "WWWorld.Archive"
STATE_KEY = r"Software\WW World\Shell"
CLASSES = r"Software\Classes"
CONTEXT_TARGETS = {
    r"*\shell": "%1",
    r"Directory\shell": "%1",
    r"Directory\Background\shell": "%V",
}


class ShellError(RuntimeError):
    pass


def _wr(winreg=None):
    if winreg is not None:
        return winreg
    if sys.platform != "win32":
        raise ShellError("Windows shell integration is only available on Windows.")
    import winreg as w
    return w


def open_command(exe: str, placeholder: str) -> str:
    # '--' stops option parsing; placeholder is quoted (file names cannot contain '"')
    return f'"{exe}" --open -- "{placeholder}"'


def _set(w, path: str, value: str, name: str = ""):
    with w.CreateKeyEx(w.HKEY_CURRENT_USER, path, 0, w.KEY_WRITE) as k:
        w.SetValueEx(k, name, 0, w.REG_SZ, value)


def _get(w, path: str, name: str = "") -> Optional[str]:
    try:
        with w.OpenKey(w.HKEY_CURRENT_USER, path, 0, w.KEY_READ) as k:
            return w.QueryValueEx(k, name)[0]
    except OSError:
        return None


def _delete_tree(w, path: str):
    try:
        with w.OpenKey(w.HKEY_CURRENT_USER, path, 0, w.KEY_READ | w.KEY_WRITE) as k:
            while True:
                try:
                    sub = w.EnumKey(k, 0)
                except OSError:
                    break
                _delete_tree(w, path + "\\" + sub)
        w.DeleteKey(w.HKEY_CURRENT_USER, path)
    except OSError:
        pass


def _key_empty(w, path: str) -> bool:
    try:
        with w.OpenKey(w.HKEY_CURRENT_USER, path, 0, w.KEY_READ) as k:
            try:
                w.EnumKey(k, 0)
                return False
            except OSError:
                pass
            try:
                w.EnumValue(k, 0)
                return False
            except OSError:
                return True
    except OSError:
        return False


def _notify():
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)  # SHCNE_ASSOCCHANGED
        except Exception:
            pass


def register_context_menu(exe: str, winreg=None) -> None:
    w = _wr(winreg)
    _require_exe(exe, winreg)
    for base, ph in CONTEXT_TARGETS.items():
        key = f"{CLASSES}\\{base}\\{VERB}"
        _set(w, key, VERB_TEXT)
        _set(w, key, f'"{exe}",0', "Icon")
        _set(w, key, "Document", "MultiSelectModel")
        _set(w, key + r"\command", open_command(exe, ph))
    _set(w, STATE_KEY, exe, "Executable")
    _notify()


def register_association(exe: str, icon: Optional[str] = None, winreg=None) -> None:
    w = _wr(winreg)
    _require_exe(exe, winreg)
    cur = _get(w, rf"{CLASSES}\.world")
    if cur and cur != PROGID and _get(w, STATE_KEY, "PreviousWorldProgId") is None:
        _set(w, STATE_KEY, cur, "PreviousWorldProgId")      # remember, never destroy
    _set(w, rf"{CLASSES}\.world", PROGID)
    _set(w, rf"{CLASSES}\.world", "application/x-ww-world", "Content Type")
    _set(w, rf"{CLASSES}\{PROGID}", "WW World Archive")
    _set(w, rf"{CLASSES}\{PROGID}\DefaultIcon", icon if icon else f'"{exe}",0')
    _set(w, rf"{CLASSES}\{PROGID}\shell", "open")
    _set(w, rf"{CLASSES}\{PROGID}\shell\open", "Open with WW World")
    _set(w, rf"{CLASSES}\{PROGID}\shell\open\command", open_command(exe, "%1"))
    _set(w, STATE_KEY, exe, "Executable")
    _notify()


def _require_exe(exe: str, winreg):
    if winreg is None and not os.path.isfile(exe):
        raise ShellError(f"executable not found: {exe}")


def unregister_context_menu(winreg=None) -> None:
    w = _wr(winreg)
    for base in CONTEXT_TARGETS:
        _delete_tree(w, f"{CLASSES}\\{base}\\{VERB}")
    _notify()


def unregister_association(winreg=None) -> None:
    """Remove only our ProgID; restore the previous .world handler if we displaced one."""
    w = _wr(winreg)
    _delete_tree(w, rf"{CLASSES}\{PROGID}")
    if _get(w, rf"{CLASSES}\.world") == PROGID:
        prev = _get(w, STATE_KEY, "PreviousWorldProgId")
        if prev:
            _set(w, rf"{CLASSES}\.world", prev)
        else:
            try:
                with w.OpenKey(w.HKEY_CURRENT_USER, rf"{CLASSES}\.world", 0, w.KEY_WRITE) as k:
                    w.DeleteValue(k, "")
                    try:
                        w.DeleteValue(k, "Content Type")
                    except OSError:
                        pass
            except OSError:
                pass
            if _key_empty(w, rf"{CLASSES}\.world"):
                try:
                    w.DeleteKey(w.HKEY_CURRENT_USER, rf"{CLASSES}\.world")
                except OSError:
                    pass
    _notify()


def unregister_all(winreg=None) -> None:
    w = _wr(winreg)
    unregister_context_menu(winreg)
    unregister_association(winreg)
    _delete_tree(w, STATE_KEY)
    if _key_empty(w, r"Software\WW World"):
        _delete_tree(w, r"Software\WW World")


def status(exe: Optional[str] = None, winreg=None) -> dict:
    """Report which registrations exist and whether they point at `exe`."""
    w = _wr(winreg)
    out = {"context": {}, "association": False, "association_ok": None, "stale": []}
    for base, ph in CONTEXT_TARGETS.items():
        cmd = _get(w, f"{CLASSES}\\{base}\\{VERB}\\command")
        out["context"][base] = cmd is not None
        if cmd is not None and exe and cmd != open_command(exe, ph):
            out["stale"].append(base)
    out["context_registered"] = all(out["context"].values())
    out["association"] = _get(w, rf"{CLASSES}\.world") == PROGID
    cmd = _get(w, rf"{CLASSES}\{PROGID}\shell\open\command")
    out["association_ok"] = bool(out["association"] and cmd and (not exe or cmd == open_command(exe, "%1")))
    return out


def repair(exe: str, icon: Optional[str] = None, winreg=None) -> dict:
    """Re-register whatever is currently registered (or stale) against `exe`."""
    st = status(None, winreg)
    did = {"context": False, "association": False}
    if any(st["context"].values()):
        register_context_menu(exe, winreg)
        did["context"] = True
    if st["association"] or _get(_wr(winreg), rf"{CLASSES}\{PROGID}") is not None:
        register_association(exe, icon, winreg)
        did["association"] = True
    return did
