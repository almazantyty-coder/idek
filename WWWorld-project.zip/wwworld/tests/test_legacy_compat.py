"""Archives made by the ORIGINAL engine (v2.0) must stay readable, browsable and testable."""
import json
import os

import pytest

from legacy_engine import WWWorldEngine as Old
from ww_world import archive as A


@pytest.fixture
def old_folder_archive(tmp_path):
    s = tmp_path / "proj"
    (s / "n1" / "n2").mkdir(parents=True)
    (s / "n1" / "n2" / "dup.txt").write_text("duplicate me")
    (s / "orig.txt").write_text("duplicate me")
    (s / "unique.bin").write_bytes(os.urandom(5000))
    (s / "empty").write_bytes(b"")
    arc = str(tmp_path / "old.world")
    ok, err = Old.compress(str(s), arc, True, "Fast")
    assert ok, err
    return s, arc


def test_old_folder_archive_reads_tests_extracts(old_folder_archive, tmp_path):
    src, arc = old_folder_archive
    m = A.read_archive(arc).manifest
    assert m.version == "2.0" and m.is_folder and m.total_size is None
    assert any(e.dup_of for e in m.files)
    r = A.test_archive(arc)
    assert r.status == "ok" and r.files_checked == 4
    out = tmp_path / "out"
    A.extract(arc, str(out))
    for rel in ("n1/n2/dup.txt", "orig.txt", "unique.bin", "empty"):
        assert (out / rel).read_bytes() == (src / rel).read_bytes()


def test_old_single_file_archive(tmp_path):
    f = tmp_path / "single.txt"
    f.write_text("legacy single")
    arc = str(tmp_path / "s.world")
    assert Old.compress(str(f), arc, False, "Fast")[0]
    assert A.test_archive(arc).status == "ok"
    A.extract(arc, str(tmp_path / "o"))
    assert (tmp_path / "o" / "single.txt").read_text() == "legacy single"


def test_old_archive_with_windows_backslash_paths(tmp_path):
    """Manifests written on Windows use backslashes; the reader must normalise them."""
    s = tmp_path / "p"
    (s / "sub").mkdir(parents=True)
    (s / "sub" / "a.txt").write_text("dup")
    (s / "b.txt").write_text("dup")
    arc = str(tmp_path / "w.world")
    assert Old.compress(str(s), arc, True, "Fast")[0]
    raw = open(arc, "rb").read()
    n = int.from_bytes(raw[:4], "big")
    man = json.loads(raw[4:4 + n])
    man["files"] = {k.replace("/", "\\"): v for k, v in man["files"].items()}
    man["deduplicated_links"] = {k.replace("/", "\\"): v.replace("/", "\\") for k, v in man["deduplicated_links"].items()}
    nb = json.dumps(man).encode()
    win = tmp_path / "win.world"
    win.write_bytes(len(nb).to_bytes(4, "big") + nb + raw[4 + n:])
    assert A.test_archive(str(win)).status == "ok"
    A.extract(str(win), str(tmp_path / "o"))
    assert (tmp_path / "o" / "sub" / "a.txt").read_text() == "dup"


def test_old_reader_can_still_read_new_single_and_folder(tmp_path):
    """Courtesy check: v3 keeps the legacy keys/payload shape so the old engine still works."""
    f = tmp_path / "f.txt"
    f.write_text("new")
    arc = str(tmp_path / "n.world")
    A.compress(str(f), arc)
    ok, verified, err = Old.decompress(arc, str(tmp_path / "restored.txt"))
    assert ok and (tmp_path / "restored.txt").read_text() == "new"
    d = tmp_path / "d"
    d.mkdir()
    (d / "a.txt").write_text("a")
    (d / "b.txt").write_text("a")
    arc2 = str(tmp_path / "n2.world")
    A.compress(str(d), arc2)
    ok, verified, err = Old.decompress(arc2, str(tmp_path / "rd"))
    assert ok and verified and (tmp_path / "rd" / "b.txt").read_text() == "a"
